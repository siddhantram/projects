"use client";
import { useState } from "react";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
export default function AppShell({children}:{children:React.ReactNode}) {
  const [open,setOpen]=useState(false);
  return <div className="flex min-h-screen bg-slate-50">
    <Sidebar open={open} onClose={()=>setOpen(false)}/>
    {open && <button className="fixed inset-0 z-30 bg-slate-950/30 lg:hidden" onClick={()=>setOpen(false)} aria-label="Close sidebar"/>}
    <div className="min-w-0 flex-1"><Topbar onMenu={()=>setOpen(true)}/><main className="p-4 sm:p-6 lg:p-8">{children}</main></div>
  </div>
}
