"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Users, Target, FolderKanban, CheckSquare, Receipt, BarChart3, Settings, Sparkles, X } from "lucide-react";

const items = [
  ["/dashboard","Dashboard",LayoutDashboard],
  ["/customers","Customers",Users],
  ["/leads","Leads",Target],
  ["/projects","Projects",FolderKanban],
  ["/tasks","Tasks",CheckSquare],
  ["/invoices","Invoices",Receipt],
  ["/reports","Reports",BarChart3],
  ["/settings","Settings",Settings],
] as const;

export default function Sidebar({open,onClose}:{open:boolean;onClose:()=>void}) {
  return <aside className={`fixed inset-y-0 left-0 z-40 w-64 border-r border-slate-200 bg-white transition-transform lg:static lg:translate-x-0 ${open?"translate-x-0":"-translate-x-full"}`}>
    <div className="flex h-full flex-col">
      <div className="flex h-20 items-center justify-between px-5">
        <Link href="/dashboard" className="flex items-center gap-3 font-bold">
          <span className="grid size-10 place-items-center rounded-xl bg-indigo-600 text-white"><Sparkles size={20}/></span>
          <span>Nexa<span className="text-indigo-600">Flow</span></span>
        </Link>
        <button className="rounded-lg p-2 lg:hidden" onClick={onClose} aria-label="Close menu"><X size={20}/></button>
      </div>
      <nav className="flex-1 space-y-1 px-3 py-4">
        {items.map(([href,label,Icon]) => {
          const active = usePathname()===href;
          return <Link key={href} href={href} onClick={onClose} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium ${active?"bg-indigo-50 text-indigo-700":"text-slate-600 hover:bg-slate-50"}`}>
            <Icon size={18}/>{label}
          </Link>
        })}
      </nav>
      <div className="m-3 rounded-2xl bg-slate-900 p-4 text-white">
        <Sparkles size={18}/>
        <p className="mt-3 text-sm font-semibold">AI Business Assistant</p>
        <p className="mt-1 text-xs leading-5 text-slate-300">Ask questions about leads, revenue and projects.</p>
        <Link href="/reports" className="mt-3 inline-block text-xs font-semibold text-indigo-300">Open insights →</Link>
      </div>
    </div>
  </aside>
}
