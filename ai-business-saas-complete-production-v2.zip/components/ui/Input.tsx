import type { InputHTMLAttributes } from "react";
export function Input({className="", ...props}: InputHTMLAttributes<HTMLInputElement>) {
  return <input className={`w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm outline-none transition focus:border-indigo-400 focus:ring-4 focus:ring-indigo-50 ${className}`} {...props}/>;
}
