import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";
const secret = new TextEncoder().encode(process.env.JWT_SECRET || "change-this-secret-in-production");
const COOKIE = "ai_business_session";
export async function middleware(req: NextRequest) {
  const path = req.nextUrl.pathname;
  const response = NextResponse.next();
  response.headers.set("X-Frame-Options","DENY"); response.headers.set("X-Content-Type-Options","nosniff"); response.headers.set("Referrer-Policy","strict-origin-when-cross-origin"); response.headers.set("Permissions-Policy","camera=(), microphone=(), geolocation=()"); response.headers.set("Content-Security-Policy","default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' https:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  if (!path.startsWith("/api/auth") && !req.cookies.get("ai_business_csrf") && !path.startsWith("/_next")) response.cookies.set("ai_business_csrf", crypto.randomUUID().replaceAll("-",""), { httpOnly:false, sameSite:"lax", secure:process.env.NODE_ENV === "production", path:"/" });
  if (path.startsWith("/_next") || path.startsWith("/favicon") || path.startsWith("/api/auth")) return response;
  const token = req.cookies.get(COOKIE)?.value;
  if (!token) return path.startsWith("/api/") ? NextResponse.json({success:false,error:"Unauthorized"},{status:401}) : NextResponse.redirect(new URL("/login", req.url));
  try { await jwtVerify(token, secret); } catch { return path.startsWith("/api/") ? NextResponse.json({success:false,error:"Unauthorized"},{status:401}) : NextResponse.redirect(new URL("/login", req.url)); }
  if (path.startsWith("/api/") && !["GET","HEAD","OPTIONS"].includes(req.method) && !path.startsWith("/api/auth/")) {
    const cookie = req.cookies.get("ai_business_csrf")?.value; const header = req.headers.get("x-csrf-token");
    if (!cookie || !header || cookie !== header) return NextResponse.json({success:false,error:"CSRF validation failed"},{status:403});
  }
  return response;
}
export const config = { matcher: ["/dashboard/:path*","/customers/:path*","/leads/:path*","/projects/:path*","/tasks/:path*","/invoices/:path*","/reports/:path*","/settings/:path*","/api/:path*"] };
