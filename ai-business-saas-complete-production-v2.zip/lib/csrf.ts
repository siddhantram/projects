import { cookies } from "next/headers";
import { randomBytes } from "crypto";
const NAME = "ai_business_csrf";
export async function ensureCsrf() {
  const store = await cookies();
  let value = store.get(NAME)?.value;
  if (!value) { value = randomBytes(24).toString("hex"); store.set(NAME, value, { httpOnly:false, sameSite:"lax", secure:process.env.NODE_ENV === "production", path:"/" }); }
  return value;
}
export async function verifyCsrf(req: Request) {
  const header = req.headers.get("x-csrf-token");
  const store = await cookies();
  return !!header && !!store.get(NAME)?.value && header === store.get(NAME)?.value;
}
