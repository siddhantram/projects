const url = process.env.UPSTASH_REDIS_REST_URL;
const token = process.env.UPSTASH_REDIS_REST_TOKEN;
export async function redisRateLimit(key: string, limit = 60, windowSeconds = 60) {
  if (!url || !token) return { success: true, remaining: limit };
  const headers = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };
  const encoded = encodeURIComponent(key);
  const incr = await fetch(`${url}/incr/${encoded}`, { headers, cache: "no-store" });
  if (!incr.ok) return { success: true, remaining: limit };
  const count = Number((await incr.json()).result ?? 0);
  if (count === 1) await fetch(`${url}/expire/${encoded}/${windowSeconds}`, { headers, cache: "no-store" });
  return { success: count <= limit, remaining: Math.max(0, limit - count) };
}
