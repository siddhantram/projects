export function pagination(url: URL) {
  const page = Math.max(1, Number(url.searchParams.get("page") || 1));
  const pageSize = Math.min(100, Math.max(5, Number(url.searchParams.get("pageSize") || 10)));
  return { page, pageSize, skip: (page - 1) * pageSize, take: pageSize, q: url.searchParams.get("q")?.trim() || "", status: url.searchParams.get("status") || "" };
}
export function paged<T>(items:T[], total:number, page:number, pageSize:number){return {items,total,page,pageSize,totalPages:Math.max(1,Math.ceil(total/pageSize))};}
