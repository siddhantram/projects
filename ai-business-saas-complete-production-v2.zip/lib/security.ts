import { NextResponse } from "next/server";
import { getSession } from "./auth";
import { db } from "./db";
import { can, PERMISSIONS, type Role } from "./rbac";

export async function requireRole(roles: Role[]) {
  const s = await getSession();
  if (!s) throw new Error("UNAUTHORIZED");
  const user = await db.user.findFirst({ where: { id: s.userId, organizationId: s.organizationId }, select: { role: true } });
  if (!user || !roles.includes(user.role as Role)) throw new Error("FORBIDDEN");
  return { ...s, role: user.role as Role };
}
export async function requirePermission(permission: keyof typeof PERMISSIONS) {
  const s = await getSession();
  if (!s) throw new Error("UNAUTHORIZED");
  const user = await db.user.findFirst({ where: { id: s.userId, organizationId: s.organizationId }, select: { role: true } });
  if (!user || !can(user.role, permission)) throw new Error("FORBIDDEN");
  return { ...s, role: user.role as Role };
}
export async function audit(s:any,action:any,entity:string,entityId?:string,metadata?:any){await db.activityLog.create({data:{organizationId:s.organizationId,userId:s.userId,action,entity,entityId,metadata}});}
export function safeError(e:any){if(e?.message==="UNAUTHORIZED")return NextResponse.json({success:false,error:"Unauthorized"},{status:401});if(e?.message==="FORBIDDEN")return NextResponse.json({success:false,error:"Forbidden"},{status:403});console.error(e);return NextResponse.json({success:false,error:"Internal server error"},{status:500});}
