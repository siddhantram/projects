const hits=new Map<string,{count:number,reset:number}>();
export function rateLimit(key:string,limit=60,windowMs=60_000){const now=Date.now();const x=hits.get(key);if(!x||now>x.reset){hits.set(key,{count:1,reset:now+windowMs});return true}x.count++;return x.count<=limit}
