export type Role = "SUPER_ADMIN" | "ADMIN" | "MANAGER" | "EMPLOYEE";
export const PERMISSIONS = {
  customerRead: ["SUPER_ADMIN","ADMIN","MANAGER","EMPLOYEE"],
  customerWrite: ["SUPER_ADMIN","ADMIN","MANAGER"],
  customerDelete: ["SUPER_ADMIN","ADMIN"],
  leadRead: ["SUPER_ADMIN","ADMIN","MANAGER","EMPLOYEE"],
  leadWrite: ["SUPER_ADMIN","ADMIN","MANAGER"],
  leadDelete: ["SUPER_ADMIN","ADMIN","MANAGER"],
  projectRead: ["SUPER_ADMIN","ADMIN","MANAGER","EMPLOYEE"],
  projectWrite: ["SUPER_ADMIN","ADMIN","MANAGER"],
  projectDelete: ["SUPER_ADMIN","ADMIN"],
  taskRead: ["SUPER_ADMIN","ADMIN","MANAGER","EMPLOYEE"],
  taskWrite: ["SUPER_ADMIN","ADMIN","MANAGER"],
  taskDelete: ["SUPER_ADMIN","ADMIN","MANAGER"],
  invoiceRead: ["SUPER_ADMIN","ADMIN","MANAGER","EMPLOYEE"],
  invoiceWrite: ["SUPER_ADMIN","ADMIN","MANAGER"],
  invoiceDelete: ["SUPER_ADMIN","ADMIN"],
  uploadWrite: ["SUPER_ADMIN","ADMIN","MANAGER","EMPLOYEE"],
  settingsWrite: ["SUPER_ADMIN","ADMIN"],
} as const;
export function can(role: string, permission: keyof typeof PERMISSIONS) {
  return (PERMISSIONS[permission] as readonly string[]).includes(role);
}
