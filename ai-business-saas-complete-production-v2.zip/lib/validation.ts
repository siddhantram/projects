
import { z } from "zod";

export const registerSchema = z.object({
  name: z.string().min(2).max(80),
  email: z.string().email().max(160),
  password: z.string().min(8).max(72),
  organization: z.string().min(2).max(100),
});

export const loginSchema = z.object({
  email: z.string().email().max(160),
  password: z.string().min(1).max(72),
});

export const customerSchema = z.object({
  name: z.string().min(2).max(120),
  email: z.string().email().max(160).optional().or(z.literal("")),
  phone: z.string().max(40).optional().or(z.literal("")),
  company: z.string().max(120).optional().or(z.literal("")),
  notes: z.string().max(2000).optional().or(z.literal("")),
});

export const leadSchema = z.object({
  name: z.string().min(2).max(120),
  email: z.string().email().max(160).optional().or(z.literal("")),
  company: z.string().max(120).optional().or(z.literal("")),
  value: z.coerce.number().min(0).max(999999999),
  status: z.enum(["NEW","CONTACTED","QUALIFIED","PROPOSAL","WON","LOST"]).default("NEW"),
  source: z.string().max(80).optional().or(z.literal("")),
  notes: z.string().max(2000).optional().or(z.literal("")),
});

export const projectSchema = z.object({
  name: z.string().min(2).max(160),
  description: z.string().max(3000).optional().or(z.literal("")),
  status: z.enum(["PLANNING","ACTIVE","ON_HOLD","COMPLETED","CANCELLED"]).default("PLANNING"),
  budget: z.coerce.number().min(0).max(999999999),
  customerId: z.string().optional().or(z.literal("")),
  startDate: z.string().optional().or(z.literal("")),
  dueDate: z.string().optional().or(z.literal("")),
});

export const taskSchema = z.object({
  title: z.string().min(2).max(200),
  description: z.string().max(3000).optional().or(z.literal("")),
  status: z.enum(["TODO","IN_PROGRESS","DONE"]).default("TODO"),
  priority: z.enum(["LOW","MEDIUM","HIGH","URGENT"]).default("MEDIUM"),
  projectId: z.string().optional().or(z.literal("")),
  assigneeId: z.string().optional().or(z.literal("")),
  dueDate: z.string().optional().or(z.literal("")),
});
