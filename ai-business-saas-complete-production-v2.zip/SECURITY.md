# Security checklist

- JWT is stored in an HttpOnly, Secure-in-production, SameSite=Lax cookie.
- Mutating authenticated API requests require the non-HttpOnly `ai_business_csrf` cookie value in `x-csrf-token`.
- Sensitive actions re-check the current database role, not only the JWT role claim.
- Every tenant-owned query scopes by `organizationId`.
- Login and registration use Upstash Redis rate limiting when configured.
- File uploads validate filename, MIME type and size before issuing a short-lived S3-compatible presigned PUT URL.
- Downloads use short-lived presigned GET URLs.
- Security headers and a restrictive CSP are set in middleware.

Before public launch: configure a strong JWT secret, production Redis, private S3/R2 bucket, DNS/TLS, database backups, monitoring, error tracking, and a secrets manager.
