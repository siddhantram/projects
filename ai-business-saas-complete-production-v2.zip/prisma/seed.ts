
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
const db=new PrismaClient();
async function main(){
 const email="demo@aibusiness.local";
 const passwordHash=await bcrypt.hash("Demo@12345",12);
 const org=await db.organization.upsert({where:{slug:"demo-business"},update:{},create:{name:"Demo Business",slug:"demo-business"}});
 const user=await db.user.upsert({where:{email},update:{passwordHash},create:{name:"Demo Admin",email,passwordHash,role:"ADMIN",organizationId:org.id}});
 const c=await db.customer.create({data:{organizationId:org.id,name:"Acme Corp",email:"hello@acme.test",company:"Acme Corp"}});
 await db.lead.create({data:{organizationId:org.id,name:"Acme Website Project",email:"hello@acme.test",company:"Acme Corp",value:85000,status:"PROPOSAL",source:"Website"}});
 const p=await db.project.create({data:{organizationId:org.id,name:"Acme Website Redesign",status:"ACTIVE",budget:85000,customerId:c.id,ownerId:user.id}});
 await db.task.create({data:{organizationId:org.id,projectId:p.id,title:"Create homepage design",status:"IN_PROGRESS",priority:"HIGH",assigneeId:user.id}});
 await db.invoice.create({data:{organizationId:org.id,customerId:c.id,projectId:p.id,number:"INV-1001",amount:45000,status:"SENT"}});
 console.log("Demo login:",email,"/ Demo@12345");
}
main().finally(()=>db.$disconnect());
