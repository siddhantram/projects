import assert from "node:assert/strict";
import {loginSchema,registerSchema} from "../lib/validation";
assert.equal(loginSchema.safeParse({email:"bad",password:"x"}).success,false);
assert.equal(registerSchema.safeParse({name:"Demo",email:"demo@test.com",password:"Demo@12345",organization:"Demo"}).success,true);
console.log("validation tests passed");
