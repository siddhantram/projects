import assert from 'node:assert/strict';
import { can } from '../lib/rbac';
assert.equal(can('EMPLOYEE','customerRead'),true);
assert.equal(can('EMPLOYEE','customerWrite'),false);
assert.equal(can('MANAGER','projectWrite'),true);
assert.equal(can('MANAGER','invoiceDelete'),false);
assert.equal(can('ADMIN','invoiceDelete'),true);
assert.equal(can('EMPLOYEE','settingsWrite'),false);
console.log('RBAC tests passed');
