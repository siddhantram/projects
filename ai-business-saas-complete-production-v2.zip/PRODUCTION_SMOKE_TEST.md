# Production Smoke Test

After Vercel deployment, verify:

1. `/login` loads over HTTPS.
2. Register creates a new organization.
3. Login creates an HTTP-only session cookie.
4. Logout invalidates the session.
5. User from Organization A cannot read Organization B data.
6. Employee cannot perform Admin/Manager-only API actions.
7. Customer CRUD works.
8. Lead CRUD + status filtering + pagination works.
9. Project CRUD works.
10. Task CRUD works.
11. Invoice CRUD works.
12. Dashboard data is organization-scoped.
13. File upload returns a short-lived presigned URL.
14. Private object cannot be fetched without a valid signed URL.
15. Invalid/oversized uploads are rejected.
16. Repeated login requests trigger Redis rate limiting.
17. Mutating requests without the CSRF token are rejected.
18. Audit logs record sensitive actions.
19. CI passes on the `main` branch.
20. Vercel deployment is healthy and has no runtime errors.

Do not mark the system production-ready until all checks pass.
