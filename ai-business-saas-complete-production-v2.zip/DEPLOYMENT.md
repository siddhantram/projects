# Production deployment

## Local verification

```bash
npm install
npx prisma generate
npx prisma migrate deploy
npm run typecheck
npm test
npm run build
npm run dev
```

Then open `/login` and test:
- login/logout
- customers create/edit/delete
- leads create/edit/delete + search/filter/pagination
- projects create/edit/delete
- tasks create/edit/delete
- invoices create/edit/delete
- protected routes with a second organization
- file upload and short-lived download URL

## Vercel

1. Create a PostgreSQL production database.
2. Create an Upstash Redis database.
3. Create a private AWS S3 or Cloudflare R2 bucket and CORS rules for browser PUTs from your Vercel domain.
4. Import the repository into Vercel.
5. Add all variables from `.env.example` to Vercel Production.
6. Deploy.
7. Run the migration from a trusted CI/terminal with the production `DATABASE_URL`:

```bash
npx prisma migrate deploy
```

8. Run the production smoke test against the Vercel URL.

### Storage CORS example

Allow your Vercel origin to use `PUT` and `GET` for the bucket. Keep the bucket private; the application issues short-lived presigned URLs.

### Important

This archive contains the application code, migration, CI workflow, security controls and E2E test suite. A real Vercel deployment cannot be performed from this archive without access to your Vercel/Postgres/Redis/storage accounts and production secrets.
