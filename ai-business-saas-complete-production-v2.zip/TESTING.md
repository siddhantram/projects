# Testing strategy

The project includes unit/security tests and a Playwright E2E suite skeleton. Run after dependencies and PostgreSQL are configured:

```bash
npm install
npx prisma generate
npx prisma migrate deploy
npm test
npm run test:e2e
npm run typecheck
npm run build
```

The E2E suite covers login, authenticated CRUD navigation, and tenant-bound API behavior. API tests exercise validation and RBAC helpers without depending on a production database.
