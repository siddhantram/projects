# AI Business SaaS — production-grade Next.js

A multi-tenant AI business management SaaS portfolio project built with Next.js App Router, React, TypeScript, PostgreSQL, Prisma and a real API layer.

## Included

- JWT authentication with HttpOnly session cookie
- Database-backed RBAC: Super Admin, Admin, Manager, Employee
- Tenant isolation on every business query
- Customers, Leads, Projects, Tasks and Invoices CRUD
- Search, filters, server-side pagination, loading/empty/error states
- Audit/activity logging
- Notifications
- AI insights with provider + deterministic fallback
- Secure S3-compatible uploads for AWS S3 / Cloudflare R2 / MinIO
- Short-lived presigned PUT and GET URLs
- MIME/size/filename validation
- CSRF protection for authenticated mutating API requests
- Upstash Redis rate limiting for login/register when configured
- Security headers + CSP
- Prisma migration + seed
- Unit/security tests + Playwright smoke tests
- GitHub Actions verification pipeline
- Vercel deployment documentation

## Demo seed

`demo@aibusiness.local` / `Demo@12345`

## Commands

```bash
npm install
npx prisma generate
npx prisma migrate deploy
npm run db:seed
npm run typecheck
npm test
npm run build
npm run dev
```

For E2E tests, start the app first and run `npm run test:e2e`.

## Production environment

Copy `.env.example` to `.env` and configure PostgreSQL, JWT secret, Upstash Redis and private S3/R2 storage.
