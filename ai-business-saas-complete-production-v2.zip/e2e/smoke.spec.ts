import { test, expect } from '@playwright/test';
const baseURL = process.env.E2E_BASE_URL || 'http://127.0.0.1:3000';
test('login page renders', async ({ page }) => { await page.goto(`${baseURL}/login`); await expect(page.getByText(/welcome back/i)).toBeVisible(); });
test('protected dashboard redirects unauthenticated users', async ({ page }) => { await page.goto(`${baseURL}/dashboard`); await expect(page).toHaveURL(/login/); });
