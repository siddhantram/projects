import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "NexaFlow — AI Business Management",
  description: "Production-style AI business management SaaS portfolio application",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
