import { ArrowUpRight, Users, Target, FolderKanban, IndianRupee } from "lucide-react";
import RevenueChart from "@/components/dashboard/RevenueChart";

const stats=[
 {label:"Total Revenue",value:"₹8,45,000",change:"+12.5%",Icon:IndianRupee},
 {label:"Customers",value:"1,248",change:"+8.2%",Icon:Users},
 {label:"Active Leads",value:"186",change:"+18.4%",Icon:Target},
 {label:"Projects",value:"42",change:"+5.7%",Icon:FolderKanban},
];
const activities=[
 ["Website redesign","Project","Today, 10:42 AM"],
 ["Rahul Sharma added","Customer","Today, 09:18 AM"],
 ["Proposal sent to Acme","Lead","Yesterday"],
 ["Invoice #INV-1048 paid","Invoice","Yesterday"],
];
export default function DashboardPage(){
 return <div className="space-y-6">
  <div><p className="text-sm font-medium text-indigo-600">Monday, October 26, 2026</p><h1 className="mt-1 text-2xl font-bold tracking-tight sm:text-3xl">Good afternoon, Siddhant 👋</h1><p className="mt-1 text-sm text-slate-500">Here’s what’s happening with your business today.</p></div>
  <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{stats.map(({label,value,change,Icon})=><div className="card p-5" key={label}><div className="flex items-center justify-between"><div className="grid size-10 place-items-center rounded-xl bg-indigo-50 text-indigo-600"><Icon size={19}/></div><span className="flex items-center gap-1 text-xs font-semibold text-emerald-600">{change}<ArrowUpRight size={13}/></span></div><p className="mt-5 text-sm text-slate-500">{label}</p><p className="mt-1 text-2xl font-bold">{value}</p></div>)}</div>
  <div className="grid gap-6 xl:grid-cols-[1fr_360px]"><RevenueChart/><div className="card p-5"><h3 className="font-semibold">Recent activity</h3><p className="text-sm text-slate-500">Latest workspace events</p><div className="mt-5 space-y-5">{activities.map(([title,type,time])=><div className="flex gap-3" key={title}><div className="mt-1 size-2.5 shrink-0 rounded-full bg-indigo-500"/><div className="min-w-0"><p className="text-sm font-medium">{title}</p><p className="text-xs text-slate-500">{type} · {time}</p></div></div>)}</div></div></div>
  <div className="card overflow-hidden"><div className="flex items-center justify-between border-b border-slate-100 p-5"><div><h3 className="font-semibold">AI business insights</h3><p className="text-sm text-slate-500">Actionable recommendations</p></div><span className="rounded-full bg-indigo-50 px-3 py-1 text-xs font-semibold text-indigo-700">AI Beta</span></div><div className="grid gap-4 p-5 md:grid-cols-3">{["Follow up with 12 high-value leads today.","3 projects are approaching their deadlines.","Revenue is trending 14% above last month."].map((x,i)=><div className="rounded-xl bg-slate-50 p-4" key={x}><p className="text-xs font-semibold text-indigo-600">INSIGHT {i+1}</p><p className="mt-2 text-sm leading-6 text-slate-700">{x}</p></div>)}</div></div>
 </div>
}
