
import { NextResponse } from "next/server";
import { requireRole } from "@/lib/security";
import { db } from "@/lib/db";

export async function POST(){
  const s=await requireRole(["SUPER_ADMIN","ADMIN","MANAGER","EMPLOYEE"]);if(!s)return NextResponse.json({success:false,error:"Unauthorized"},{status:401});
  const [customers,leads,projects,invoices]=await Promise.all([
    db.customer.count({where:{organizationId:s.organizationId}}),
    db.lead.findMany({where:{organizationId:s.organizationId},select:{status:true,value:true}}),
    db.project.count({where:{organizationId:s.organizationId}}),
    db.invoice.findMany({where:{organizationId:s.organizationId},select:{amount:true,status:true}})
  ]);
  const context={customers,projects,leadCount:leads.length,pipeline:leads.reduce((a,l)=>a+Number(l.value),0),won:leads.filter(l=>l.status==="WON").reduce((a,l)=>a+Number(l.value),0),paid:invoices.filter(i=>i.status==="PAID").reduce((a,i)=>a+Number(i.amount),0)};
  const key=process.env.AI_API_KEY;
  if(!key) {
    return NextResponse.json({success:true,source:"local",insights:[
      `You have ${context.leadCount} leads with a pipeline value of ₹${Math.round(context.pipeline).toLocaleString("en-IN")}.`,
      `Won revenue is ₹${Math.round(context.won).toLocaleString("en-IN")}; focus on qualified and proposal-stage leads.`,
      `Paid invoice revenue is ₹${Math.round(context.paid).toLocaleString("en-IN")}.`
    ],context});
  }
  try {
    const endpoint=process.env.AI_API_URL || "https://api.openai.com/v1/chat/completions";
    const model=process.env.AI_MODEL || "gpt-4o-mini";
    const r=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`},body:JSON.stringify({model,messages:[{role:"system",content:"You are a concise business analyst. Return exactly 3 actionable insights as a JSON array of strings."},{role:"user",content:JSON.stringify(context)}],temperature:0.2})});
    if(!r.ok) throw new Error("AI provider error");
    const data=await r.json();
    let text=data?.choices?.[0]?.message?.content || "[]";
    let insights; try { insights=JSON.parse(text); } catch { insights=[text]; }
    return NextResponse.json({success:true,source:"ai",insights,context});
  } catch {
    return NextResponse.json({success:true,source:"fallback",insights:["AI provider is temporarily unavailable. Review your highest-value leads.","Prioritize overdue invoices and proposal-stage opportunities.","Keep project workload aligned with available team capacity."],context});
  }
}
