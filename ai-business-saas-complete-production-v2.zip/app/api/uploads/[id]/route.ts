import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { presignedGetUrl } from "@/lib/storage";
export async function GET(_:Request,{params}:{params:Promise<{id:string}>}){const s=await getSession();if(!s)return NextResponse.json({success:false,error:"Unauthorized"},{status:401});const {id}=await params;const file=await db.attachment.findFirst({where:{id,organizationId:s.organizationId}});if(!file)return NextResponse.json({success:false,error:"Not found"},{status:404});return NextResponse.json({success:true,url:presignedGetUrl(file.url,300),expiresIn:300});}
