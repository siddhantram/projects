import { NextResponse } from "next/server";
import { requirePermission, audit, safeError } from "@/lib/security";
import { db } from "@/lib/db";
import { storageKey, presignedPutUrl } from "@/lib/storage";
const MAX = Number(process.env.UPLOAD_MAX_BYTES || 10 * 1024 * 1024);
const ALLOWED = new Set(["image/jpeg","image/png","image/webp","application/pdf","text/plain","application/zip"]);
export async function POST(req:Request){try{const s=await requirePermission("uploadWrite"); const body=await req.json(); const filename=String(body.filename||""); const mimeType=String(body.mimeType||""); const size=Number(body.size||0); if(!filename||filename.length>160||!ALLOWED.has(mimeType)||!Number.isInteger(size)||size<1||size>MAX) return NextResponse.json({success:false,error:"Invalid file. Allowed types: JPG, PNG, WEBP, PDF, TXT, ZIP; max 10MB."},{status:400}); const key=storageKey(filename); const uploadUrl=presignedPutUrl(key,mimeType,600); const attachment=await db.attachment.create({data:{organizationId:s.organizationId,userId:s.userId,customerId:body.customerId||null,filename,mimeType,size,url:key}}); await audit(s,"CREATE","Attachment",attachment.id,{filename,size,mimeType}); return NextResponse.json({success:true,attachment,uploadUrl,expiresIn:600},{status:201});}catch(e){return safeError(e)}}
