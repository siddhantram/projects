
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/security";
export async function GET(){
 const s=await requireRole(["SUPER_ADMIN","ADMIN","MANAGER","EMPLOYEE"]);if(!s)return NextResponse.json({success:false,error:"Unauthorized"},{status:401});
 const [customers,leads,projects,tasks,invoices]=await Promise.all([
  db.customer.count({where:{organizationId:s.organizationId}}),
  db.lead.findMany({where:{organizationId:s.organizationId},select:{value:true,status:true}}),
  db.project.count({where:{organizationId:s.organizationId}}),
  db.task.count({where:{organizationId:s.organizationId,status:"DONE"}}),
  db.invoice.findMany({where:{organizationId:s.organizationId},select:{amount:true,status:true}})
 ]);
 const pipeline=leads.reduce((sum,l)=>sum+Number(l.value),0);
 const won=leads.filter(l=>l.status==="WON").reduce((sum,l)=>sum+Number(l.value),0);
 const paid=invoices.filter(i=>i.status==="PAID").reduce((sum,i)=>sum+Number(i.amount),0);
 return NextResponse.json({success:true,metrics:{customers,leads:leads.length,projects,completedTasks:tasks,pipeline,wonRevenue:won,paidRevenue:paid}});
}
