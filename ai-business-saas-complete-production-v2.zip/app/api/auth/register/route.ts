
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";
import { registerSchema } from "@/lib/validation";
import { redisRateLimit } from "@/lib/upstash";

export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    const rl = await redisRateLimit(`register:${ip}`, 5, 3600);
    if (!rl.success) return NextResponse.json({success:false,error:"Too many registration attempts. Try again later."},{status:429,headers:{"Retry-After":"3600"}});
    const body = await req.json();
    const parsed = registerSchema.safeParse(body);
    if (!parsed.success) return NextResponse.json({ success:false, error:"Invalid registration data" }, {status:400});

    const { name, email, password, organization } = parsed.data;
    const exists = await db.user.findUnique({ where: { email: email.toLowerCase() } });
    if (exists) return NextResponse.json({ success:false, error:"Email already registered" }, {status:409});

    const slugBase = organization.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "organization";
    const slug = `${slugBase}-${Math.random().toString(36).slice(2,7)}`;
    const passwordHash = await bcrypt.hash(password, 12);

    const result = await db.$transaction(async tx => {
      const org = await tx.organization.create({ data: { name: organization, slug } });
      const user = await tx.user.create({
        data: { name, email: email.toLowerCase(), passwordHash, role:"ADMIN", organizationId: org.id }
      });
      return { org, user };
    });

    await createSession({ userId: result.user.id, organizationId: result.org.id, role: result.user.role });
    return NextResponse.json({ success:true, user:{ id:result.user.id, name:result.user.name, email:result.user.email } }, {status:201});
  } catch (e) {
    console.error(e);
    return NextResponse.json({ success:false, error:"Registration failed" }, {status:500});
  }
}
