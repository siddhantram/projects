
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";
import { loginSchema } from "@/lib/validation";
import { redisRateLimit } from "@/lib/upstash";

export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    const rl = await redisRateLimit(`login:${ip}`, 10, 60);
    if (!rl.success) return NextResponse.json({success:false,error:"Too many login attempts. Try again later."},{status:429,headers:{"Retry-After":"60"}});
    const body = await req.json();
    const parsed = loginSchema.safeParse(body);
    if (!parsed.success) return NextResponse.json({success:false,error:"Invalid credentials"}, {status:400});
    const {email,password} = parsed.data;
    const user = await db.user.findUnique({where:{email:email.toLowerCase()}});
    if (!user || !(await bcrypt.compare(password,user.passwordHash))) {
      return NextResponse.json({success:false,error:"Invalid email or password"}, {status:401});
    }
    await createSession({userId:user.id, organizationId:user.organizationId, role:user.role});
    return NextResponse.json({success:true,user:{id:user.id,name:user.name,email:user.email,role:user.role}});
  } catch(e) {
    console.error(e);
    return NextResponse.json({success:false,error:"Login failed"}, {status:500});
  }
}
