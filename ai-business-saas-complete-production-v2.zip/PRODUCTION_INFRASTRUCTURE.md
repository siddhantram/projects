# Production Infrastructure

This project is wired for the following production topology:

PostgreSQL
  -> Prisma migrations
  -> Next.js 16 on Vercel
  -> JWT + RBAC + tenant isolation
  -> Upstash Redis rate limiting
  -> private S3/R2-compatible object storage
  -> presigned upload/download URLs
  -> GitHub Actions CI
  -> Vercel production deployment

## Required production services

### 1. PostgreSQL
Create a production PostgreSQL database and set:

- `DATABASE_URL`

Run:

```bash
npx prisma migrate deploy
```

Never use `prisma migrate dev` against production.

### 2. Upstash Redis

Set:

- `UPSTASH_REDIS_REST_URL`
- `UPSTASH_REDIS_REST_TOKEN`

Authentication endpoints already use Redis-backed rate limiting.

### 3. Private S3 / Cloudflare R2

Set:

- `S3_ENDPOINT`
- `S3_REGION`
- `S3_BUCKET`
- `S3_ACCESS_KEY_ID`
- `S3_SECRET_ACCESS_KEY`
- `S3_PUBLIC_BASE_URL`

Keep the bucket private. The API issues short-lived presigned URLs.

Recommended limits:

- Maximum file size: 10 MB
- Validate MIME type and extension
- Generate application-owned object keys
- Do not expose long-lived public credentials to the browser

### 4. Vercel

Connect the repository to Vercel or use the included GitHub Actions deployment workflow.

Required GitHub Actions secrets:

- `DATABASE_URL`
- `JWT_SECRET`
- `UPSTASH_REDIS_REST_URL`
- `UPSTASH_REDIS_REST_TOKEN`
- `S3_ENDPOINT`
- `S3_REGION`
- `S3_BUCKET`
- `S3_ACCESS_KEY_ID`
- `S3_SECRET_ACCESS_KEY`
- `S3_PUBLIC_BASE_URL`
- `VERCEL_ORG_ID`
- `VERCEL_PROJECT_ID`
- `VERCEL_TOKEN`

The workflow:

1. installs dependencies
2. generates Prisma client
3. applies production migrations
4. runs type checking
5. runs tests
6. creates a production build
7. deploys to Vercel

## Local verification

```bash
npm install
npx prisma generate
npx prisma migrate deploy
npm run typecheck
npm test
npm run build
npm run dev
```

## Vercel CLI

Authenticate once:

```bash
npx vercel login
```

Then link the project:

```bash
npx vercel link
```

Production deploy:

```bash
npm run vercel:deploy
```

## Important limitation

The archive contains the complete deployment configuration, but the final production deployment itself requires the user's real PostgreSQL, Upstash, storage, GitHub and Vercel credentials. Those credentials must never be embedded in the source archive.
