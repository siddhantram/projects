# AgentOS — Multi-Agent Business Automation

A production-style Next.js 16 + TypeScript + PostgreSQL + Prisma application demonstrating multi-agent orchestration, organization isolation, RBAC-ready memberships, workflow execution, tool-call traces, human approval gates, audit activity and a zero-cost local AI fallback.

## What is actually implemented
- Next.js 16 App Router
- TypeScript + strict mode
- PostgreSQL + Prisma schema and seed
- Email/password authentication with bcrypt + HttpOnly JWT session
- Multi-tenant Organization + Membership + roles
- Agent registry: Sales, Support, HR, Finance, Operations
- Agent execution API with tool-call trace and persisted runs
- Workflow execution API with multi-step agent orchestration
- Human approval state for consequential workflow steps
- Dashboard metrics + activity feed
- Organization-scoped database queries
- Local AI simulator: works without OpenAI credits or an API key
- Optional provider environment variables prepared for hosted AI integration
- Responsive dashboard UI
- Durable PostgreSQL-backed job queue + dedicated worker with retry/backoff and SKIP LOCKED claiming
- Request rate limiting with safe in-process fallback (use an edge/Redis limiter when horizontally scaled)
- Security headers/CSP, same-origin mutation guard and safer session-secret rotation via current/previous secrets
- Structured JSON observability logs with request/job context
- Automated security/unit tests via Node test runner + tsx
- PostgreSQL backup scripts for PowerShell and Bash
- Docker Compose for PostgreSQL + app + worker

## Quick start (Windows PowerShell)

1. Install PostgreSQL and create a database named `multi_agent_automation`.
2. Copy `.env.example` to `.env` and update `DATABASE_URL` and `JWT_SECRET`.
3. Run:

```powershell
npm.cmd install
npm.cmd run db:generate
npm.cmd run db:push
npm.cmd run db:seed
npm.cmd run dev
```

Open `http://localhost:3000`.

Demo account:
- Email: `demo@automation.local`
- Password: `Demo@12345`

## Production build

```powershell
npm.cmd run build
npm.cmd start
```

## AI provider

The default local simulator is intentional: the portfolio project remains runnable with zero paid AI credits. To connect a hosted provider, add `OPENAI_API_KEY` and extend `app/lib/ai.ts` with your chosen provider SDK/API. Keep secrets server-side only.

## Architecture

Browser → Next.js App Router → Auth/session → organization-scoped service/API → Prisma → PostgreSQL

Workflow → Agent Router → specialized Agent → tools → approval gate → persisted AgentRun/WorkflowRun → Activity/Audit trail

## Background worker / queue

Workflow requests are persisted as jobs in PostgreSQL and return HTTP 202. The worker claims jobs using `FOR UPDATE SKIP LOCKED`, retries transient failures with exponential backoff, and marks permanently failed jobs after the configured attempt limit. Start it locally in a second terminal:

```powershell
npm.cmd run worker
```

## Tests

```powershell
npm.cmd test
npm.cmd run lint
npm.cmd run build
```

## Backups

Windows:
```powershell
npm.cmd run db:backup
```
Linux/macOS:
```bash
./scripts/backup.sh
```

For real production, store backups outside the application host, encrypt them, test restores, and use a managed PostgreSQL backup/PITR strategy.

## Secret rotation

Use `JWT_SECRET_CURRENT` for new sessions and temporarily keep the previous key in `JWT_SECRET_PREVIOUS`. Tokens signed with either key remain valid during a controlled rotation window; after all old sessions expire, remove the previous key. Never commit either secret.

## Observability

The server emits JSON logs with timestamps, levels and structured metadata. In production, ship stdout/stderr to your log platform and add OpenTelemetry/Sentry/metrics as your deployment standard requires.

## Security checklist

Before real customer traffic: managed secrets, TLS, WAF/edge rate limiting, CSRF/origin protection review, dependency scanning, SAST/DAST, database least privilege, encrypted backups + restore drills, PII/data-retention policy, audit-log retention, alerting, incident response, penetration testing and a formal threat model.

## Important portfolio note

This is a strong production-style portfolio foundation, not a claim that it is a fully hardened enterprise SaaS. Before real customer production, add rate limiting, CSRF strategy where applicable, secret rotation, queue/worker infrastructure, real provider adapters, comprehensive automated tests, observability, backups, data retention controls and a formal security review.
