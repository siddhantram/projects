import { db } from '../app/lib/db';
import { runLocalAgent } from '../app/lib/ai';
import { logger } from '../app/lib/logger';
const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms));
async function claim(){
  const job=await db.$queryRawUnsafe<any[]>(`UPDATE "Job" SET status='RUNNING', "lockedAt"=NOW(), "startedAt"=COALESCE("startedAt",NOW()), attempts=attempts+1, "updatedAt"=NOW() WHERE id=(SELECT id FROM "Job" WHERE status='QUEUED' AND "availableAt"<=NOW() ORDER BY "createdAt" LIMIT 1 FOR UPDATE SKIP LOCKED) RETURNING *`);
  return job[0];
}
async function handle(job:any){
  if(job.type!=='workflow.run') throw new Error(`Unknown job type: ${job.type}`);
  const payload=job.payload as {workflowRunId:string;userId:string};
  const run=await db.workflowRun.findUnique({where:{id:payload.workflowRunId},include:{workflow:true}}); if(!run) throw new Error('Workflow run not found');
  await db.workflowRun.update({where:{id:run.id},data:{status:'RUNNING',startedAt:new Date()}});
  const steps=Array.isArray(run.workflow.steps)?run.workflow.steps as {agentType?:string;action?:string;required?:boolean}[]:[];
  let last=''; let approval=false;
  for(const step of steps){
    if(!step.agentType) continue;
    const agent=await db.agent.findFirst({where:{organizationId:run.organizationId,type:step.agentType as any,status:'ACTIVE'}}); if(!agent) continue;
    const started=Date.now(); const result=await runLocalAgent(String((run.input as any)?.text||''),agent.name);
    last=result.output; approval ||= !!step.required;
    await db.agentRun.create({data:{agentId:agent.id,workflowRunId:run.id,userId:payload.userId,input:{text:(run.input as any)?.text,action:step.action},output:{text:result.output,provider:result.provider},toolCalls:result.toolCalls,status:'COMPLETED',latencyMs:Date.now()-started}});
  }
  await db.workflowRun.update({where:{id:run.id},data:{status:'COMPLETED',output:{summary:last,steps:steps.length},approvalStatus:approval?'PENDING':'NOT_REQUIRED',completedAt:new Date()}});
  await db.activity.create({data:{action:'workflow.run.completed',entityType:'WorkflowRun',entityId:run.id,organizationId:run.organizationId,userId:payload.userId,metadata:{approvalRequired:approval}}});
}
async function fail(job:any,error:unknown){
  const message=String(error instanceof Error?error.message:error);
  if(job.attempts < job.maxAttempts) await db.job.update({where:{id:job.id},data:{status:'QUEUED',lastError:message,availableAt:new Date(Date.now()+Math.min(60000,1000*2**job.attempts))}});
  else { await db.job.update({where:{id:job.id},data:{status:'FAILED',lastError:message,completedAt:new Date()}}); const p=job.payload as any; if(p.workflowRunId) await db.workflowRun.updateMany({where:{id:p.workflowRunId},data:{status:'FAILED',error:message,completedAt:new Date()}}); }
}
async function main(){logger.info('worker.started'); while(true){try{const job=await claim(); if(!job){await sleep(1000);continue;} try{await handle(job);await db.job.update({where:{id:job.id},data:{status:'COMPLETED',completedAt:new Date()}});}catch(e){logger.error('job.failed',{jobId:job.id,error:String(e)});await fail(job,e);}}catch(e){logger.error('worker.loop.error',{error:String(e)});await sleep(2000);}}}
main().catch(e=>{logger.error('worker.fatal',{error:String(e)});process.exit(1)});
