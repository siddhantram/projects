#!/usr/bin/env bash
set -euo pipefail
mkdir -p "${1:-./backups}"
stamp=$(date +%Y%m%d-%H%M%S)
pg_dump "$DATABASE_URL" --format=custom --file="${1:-./backups}/business-automation-$stamp.dump"
echo "Backup created"
