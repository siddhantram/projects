param([string]$OutputDir = "./backups")
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$file = Join-Path $OutputDir "business-automation-$stamp.sql"
if (-not $env:DATABASE_URL) { throw "DATABASE_URL is required" }
pg_dump $env:DATABASE_URL --format=custom --file=$file
Write-Host "Backup created: $file"
