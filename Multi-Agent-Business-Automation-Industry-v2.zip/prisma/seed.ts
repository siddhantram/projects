import { PrismaClient, AgentType, AgentStatus, WorkflowStatus, Role } from '@prisma/client';
import bcrypt from 'bcryptjs';
const prisma = new PrismaClient();
async function main() {
  const email = 'demo@automation.local';
  const passwordHash = await bcrypt.hash('Demo@12345', 12);
  const user = await prisma.user.upsert({ where: { email }, update: {}, create: { name: 'Demo Admin', email, passwordHash } });
  const org = await prisma.organization.upsert({ where: { slug: 'acme-automation' }, update: {}, create: { name: 'Acme Automation', slug: 'acme-automation' } });
  await prisma.membership.upsert({ where: { userId_organizationId: { userId: user.id, organizationId: org.id } }, update: { role: Role.OWNER }, create: { userId: user.id, organizationId: org.id, role: Role.OWNER } });
  const agents = [
    ['Sales Agent','Qualifies leads, drafts follow-ups and recommends next actions.',AgentType.SALES,'You are a B2B sales operations agent. Be concise, evidence-based and never invent CRM facts.'],
    ['Support Agent','Classifies customer issues and drafts safe responses.',AgentType.SUPPORT,'You are a customer support agent. Prioritize customer impact, clarity and escalation when confidence is low.'],
    ['HR Agent','Helps with recruiting workflows and employee operations.',AgentType.HR,'You are an HR operations agent. Protect sensitive information and request approval for consequential actions.'],
    ['Finance Agent','Summarizes finance tasks and flags risks.',AgentType.FINANCE,'You are a finance operations agent. Never execute payments. Flag missing evidence and approval requirements.'],
    ['Operations Agent','Coordinates internal tasks and business workflows.',AgentType.OPERATIONS,'You are an operations agent. Turn requests into auditable steps and surface dependencies.']
  ] as const;
  for (const [name,description,type,systemPrompt] of agents) await prisma.agent.upsert({ where: { id: `${org.id}-${type.toLowerCase()}` }, update: { name,description,type,systemPrompt }, create: { id: `${org.id}-${type.toLowerCase()}`, name,description,type,status:AgentStatus.ACTIVE,systemPrompt,tools:['database.read','activity.create','human.approval'],organizationId:org.id } });
  const count = await prisma.workflow.count({ where:{ organizationId:org.id }});
  if (!count) await prisma.workflow.create({ data:{ name:'Lead Qualification & Follow-up', description:'Score a new lead, prepare a response and route risky actions for approval.', status:WorkflowStatus.ACTIVE, trigger:{type:'manual'}, steps:[{agentType:'SALES',action:'qualify'},{agentType:'SALES',action:'draft_followup'},{action:'human_approval',required:true}], organizationId:org.id }});
  console.log(`Demo login: ${email} / Demo@12345`);
}
main().finally(()=>prisma.$disconnect());
