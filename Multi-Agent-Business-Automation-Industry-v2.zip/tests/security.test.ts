import test from 'node:test';
import assert from 'node:assert/strict';
import { rateLimit } from '../app/lib/rate-limit';
import { hashSecret, safeCompare } from '../app/lib/security';
test('rate limiter blocks after limit',()=>{const key='test-'+Date.now(); for(let i=0;i<60;i++) assert.equal(rateLimit(key,60).ok,true); assert.equal(rateLimit(key,60).ok,false);});
test('secret hashing is deterministic and constant-time comparable',()=>{const a=hashSecret('hello');const b=hashSecret('hello');assert.equal(a,b);assert.equal(safeCompare(a,b),true);});
