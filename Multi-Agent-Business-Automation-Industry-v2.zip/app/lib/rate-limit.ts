type Entry={count:number;resetAt:number};
const buckets=new Map<string,Entry>();
const WINDOW=60_000; const LIMIT=60;
export function rateLimit(key:string, limit=LIMIT){
  const now=Date.now(); const e=buckets.get(key);
  if(!e || e.resetAt<=now){buckets.set(key,{count:1,resetAt:now+WINDOW});return {ok:true,remaining:limit-1};}
  e.count++; if(e.count>limit)return {ok:false,remaining:0,retryAfter:Math.ceil((e.resetAt-now)/1000)};
  return {ok:true,remaining:limit-e.count};
}
