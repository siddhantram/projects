export type ToolCall={tool:string; input:Record<string,unknown>; result:unknown};
export async function runLocalAgent(input:string, agentName:string){
  const lower=input.toLowerCase();
  const intent=lower.includes('lead')||lower.includes('sales')?'sales':lower.includes('support')||lower.includes('ticket')?'support':lower.includes('hire')||lower.includes('employee')?'hr':lower.includes('invoice')||lower.includes('payment')?'finance':'operations';
  const toolCalls:ToolCall[]=[{tool:'database.read',input:{scope:intent},result:{status:'simulated','recordsChecked':3}}];
  const output=`${agentName} analyzed the request. Recommended intent: ${intent}. Next action: create an auditable task, verify the relevant records, and request human approval before any external or irreversible action.`;
  return {output,toolCalls,provider:'local-simulator'};
}
