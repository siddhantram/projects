import { db } from './db';
import { logger } from './logger';
export async function enqueueJob(args:{type:string;payload:unknown;organizationId:string;idempotencyKey?:string;maxAttempts?:number}){
  try { return await db.job.create({data:{type:args.type,payload:args.payload as any,organizationId:args.organizationId,idempotencyKey:args.idempotencyKey,maxAttempts:args.maxAttempts??3}}); }
  catch(e:any){ if(args.idempotencyKey) return db.job.findUnique({where:{idempotencyKey:args.idempotencyKey}}); logger.error('job.enqueue.failed',{error:String(e)}); throw e; }
}
