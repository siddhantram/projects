import crypto from 'node:crypto';
export function hashSecret(value:string){return crypto.createHash('sha256').update(value).digest('hex');}
export function safeCompare(a:string,b:string){const aa=Buffer.from(a),bb=Buffer.from(b);return aa.length===bb.length&&crypto.timingSafeEqual(aa,bb);}
export function requestId(req:Request){return req.headers.get('x-request-id')||crypto.randomUUID();}
export function assertSameOrigin(req:Request){
  if(process.env.NODE_ENV==='development') return;
  const origin=req.headers.get('origin'); const host=req.headers.get('host');
  if(origin && host && new URL(origin).host!==host) throw new Error('FORBIDDEN');
}
