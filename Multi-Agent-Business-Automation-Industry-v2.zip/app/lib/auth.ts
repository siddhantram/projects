import { cookies } from 'next/headers';
import { SignJWT, jwtVerify } from 'jose';
import { db } from './db';

function secretFor(value:string){ return new TextEncoder().encode(value); }
function secrets(){
  const current=process.env.JWT_SECRET_CURRENT || process.env.JWT_SECRET || 'dev-secret-change-me-please-32-chars';
  const previous=process.env.JWT_SECRET_PREVIOUS;
  return [current, ...(previous?[previous]:[])];
}
export async function signSession(userId:string, organizationId:string){
  const secret=secretFor(secrets()[0]);
  return new SignJWT({userId,organizationId}).setProtectedHeader({alg:'HS256'}).setIssuedAt().setExpirationTime('7d').sign(secret);
}
export async function getSession(){
  const token=(await cookies()).get('session')?.value; if(!token)return null;
  for(const raw of secrets()) try { const {payload}=await jwtVerify(token,secretFor(raw)); if(typeof payload.userId==='string'&&typeof payload.organizationId==='string') return {userId:payload.userId,organizationId:payload.organizationId}; } catch {}
  return null;
}
export async function requireSession(){const s=await getSession();if(!s)throw new Error('UNAUTHORIZED');const membership=await db.membership.findUnique({where:{userId_organizationId:{userId:s.userId,organizationId:s.organizationId}},include:{user:true,organization:true}});if(!membership)throw new Error('FORBIDDEN');return {...s,membership};}
