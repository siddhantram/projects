import { NextResponse } from 'next/server';
export function apiError(error:unknown){ const message=error instanceof Error?error.message:'Unexpected error'; const status=message==='UNAUTHORIZED'?401:message==='FORBIDDEN'?403:message==='RATE_LIMITED'?429:400; return NextResponse.json({success:false,error:message},{status,headers:message==='RATE_LIMITED'?{'Retry-After':'60'}:undefined}); }
