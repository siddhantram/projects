type Meta = Record<string, unknown>;
function write(level: string, message: string, meta?: Meta) {
  const line = JSON.stringify({ ts: new Date().toISOString(), level, message, ...(meta ? { meta } : {}) });
  if (level === 'error') console.error(line); else console.log(line);
}
export const logger = { info:(m:string,meta?:Meta)=>write('info',m,meta), warn:(m:string,meta?:Meta)=>write('warn',m,meta), error:(m:string,meta?:Meta)=>write('error',m,meta) };
