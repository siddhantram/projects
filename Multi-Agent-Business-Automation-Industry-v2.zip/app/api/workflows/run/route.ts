import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '@/app/lib/auth';
import { db } from '@/app/lib/db';
import { enqueueJob } from '@/app/lib/queue';
import { rateLimit } from '@/app/lib/rate-limit';
import { apiError } from '@/app/lib/http';
import { logger } from '@/app/lib/logger';
const schema=z.object({workflowId:z.string(),input:z.string().min(2).max(10000),idempotencyKey:z.string().min(8).max(120).optional()});
export async function POST(req:Request){try{const s=await requireSession();const rl=rateLimit(`workflow:${s.userId}`,20);if(!rl.ok)throw new Error('RATE_LIMITED');const b=schema.parse(await req.json());const wf=await db.workflow.findFirst({where:{id:b.workflowId,organizationId:s.organizationId,status:'ACTIVE'}});if(!wf)return NextResponse.json({success:false,error:'Active workflow not found'},{status:404});const run=await db.workflowRun.create({data:{workflowId:wf.id,organizationId:s.organizationId,input:{text:b.input},status:'QUEUED'}});const job=await enqueueJob({type:'workflow.run',organizationId:s.organizationId,payload:{workflowRunId:run.id,userId:s.userId},idempotencyKey:b.idempotencyKey});logger.info('workflow.queued',{runId:run.id,jobId:job?.id,organizationId:s.organizationId});return NextResponse.json({success:true,queued:true,run,jobId:job?.id},{status:202});}catch(e){return apiError(e);}}
