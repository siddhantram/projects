import './globals.css';
export const metadata={title:'AgentOS — Multi-Agent Business Automation',description:'Production-style multi-agent business automation platform'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
