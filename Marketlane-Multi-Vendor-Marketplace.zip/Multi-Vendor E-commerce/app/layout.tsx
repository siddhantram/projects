import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Marketlane — Independent brands, one marketplace",
  description: "Discover thoughtful products from independent sellers on Marketlane."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
