import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole, AuthError } from "@/lib/auth";
import { errorResponse, serverError } from "@/lib/http";

type Context = { params: Promise<{ id: string }> };
export async function GET(_request: Request, { params }: Context) {
  try {
    const { id } = await params;
    const product = await prisma.product.findFirst({ where: { OR: [{ id }, { slug: id }], status: "ACTIVE" }, include: { vendor: { select: { id: true, storeName: true, slug: true } }, category: true, reviews: { include: { user: { select: { name: true } } }, orderBy: { createdAt: "desc" }, take: 20 } });
    if (!product) return errorResponse("Product not found.", 404);
    return NextResponse.json({ product });
  } catch (e) { return serverError(e); }
}
const schema = z.object({ name: z.string().trim().min(2).max(160).optional(), description: z.string().trim().min(10).max(5000).optional(), price: z.number().positive().optional(), stock: z.number().int().min(0).optional(), status: z.enum(["DRAFT", "ACTIVE", "ARCHIVED"]).optional(), imageUrl: z.url().nullable().optional() });
export async function PATCH(request: Request, { params }: Context) {
  try {
    const user = await requireRole("VENDOR", "ADMIN");
    const { id } = await params;
    const product = await prisma.product.findUnique({ where: { id } });
    if (!product) return errorResponse("Product not found.", 404);
    if (user.role === "VENDOR" && product.vendorId !== user.vendorId) return errorResponse("You cannot modify another vendor's product.", 403);
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success || Object.keys(parsed.data || {}).length === 0) return errorResponse("Provide valid fields to update.");
    const updated = await prisma.product.update({ where: { id }, data: parsed.data });
    return NextResponse.json({ product: updated });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
export async function DELETE(_request: Request, { params }: Context) {
  try {
    const user = await requireRole("VENDOR", "ADMIN");
    const { id } = await params;
    const product = await prisma.product.findUnique({ where: { id } });
    if (!product) return errorResponse("Product not found.", 404);
    if (user.role === "VENDOR" && product.vendorId !== user.vendorId) return errorResponse("You cannot delete another vendor's product.", 403);
    await prisma.product.update({ where: { id }, data: { status: "ARCHIVED" } });
    return NextResponse.json({ message: "Product archived." });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
