import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { getSession, requireRole, AuthError } from "@/lib/auth";
import { errorResponse, serverError } from "@/lib/http";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const q = url.searchParams.get("q")?.trim();
    const category = url.searchParams.get("category");
    const page = Math.max(1, Number(url.searchParams.get("page") || 1));
    const limit = Math.min(48, Math.max(1, Number(url.searchParams.get("limit") || 12)));
    const where = {
      status: "ACTIVE" as const,
      ...(q ? { OR: [{ name: { contains: q, mode: "insensitive" as const } }, { description: { contains: q, mode: "insensitive" as const } }] } : {}),
      ...(category ? { category: { slug: category } } : {})
    };
    const [items, total] = await Promise.all([
      prisma.product.findMany({ where, include: { vendor: { select: { storeName: true, slug: true } }, category: true }, orderBy: { createdAt: "desc" }, skip: (page - 1) * limit, take: limit }),
      prisma.product.count({ where })
    ]);
    return NextResponse.json({ items, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
  } catch (e) { return serverError(e); }
}

const schema = z.object({
  name: z.string().trim().min(2).max(160), description: z.string().trim().min(10).max(5000),
  price: z.number().positive(), stock: z.number().int().min(0), sku: z.string().trim().min(2).max(80),
  categoryId: z.string().optional(), imageUrl: z.url().optional()
});
export async function POST(request: Request) {
  try {
    const user = await requireRole("VENDOR", "ADMIN");
    if (user.role === "VENDOR" && !user.vendorId) return errorResponse("Vendor profile is missing.", 403);
    if (user.role === "VENDOR") {
      const vendor = await prisma.vendor.findUnique({ where: { id: user.vendorId } });
      if (vendor?.status !== "APPROVED") return errorResponse("Your vendor account must be approved before listing products.", 403);
    }
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return errorResponse(parsed.error.issues[0]?.message ?? "Invalid product.");
    const data = parsed.data;
    const vendorId = user.role === "ADMIN" ? (new URL(request.url).searchParams.get("vendorId") || user.vendorId) : user.vendorId;
    if (!vendorId) return errorResponse("An approved vendor account is required.");
    const slug = `${data.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}-${Date.now().toString(36)}`;
    const product = await prisma.product.create({ data: { ...data, slug, vendorId, status: "ACTIVE" }, include: { vendor: { select: { storeName: true } } } });
    return NextResponse.json({ product }, { status: 201 });
  } catch (e) {
    if (e instanceof AuthError) return errorResponse(e.message, e.status);
    return serverError(e);
  }
}
