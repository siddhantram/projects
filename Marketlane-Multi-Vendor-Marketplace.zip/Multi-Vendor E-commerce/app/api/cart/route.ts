import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole, AuthError } from "@/lib/auth";
import { errorResponse, serverError } from "@/lib/http";

export async function GET() {
  try {
    const user = await requireRole("CUSTOMER");
    const cart = await prisma.cart.findUnique({ where: { userId: user.id }, include: { items: { include: { product: { include: { vendor: { select: { storeName: true } } } } } } } });
    return NextResponse.json({ cart: cart ?? { items: [] } });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
const schema = z.object({ productId: z.string().min(1), quantity: z.number().int().min(1).max(50).default(1) });
export async function POST(request: Request) {
  try {
    const user = await requireRole("CUSTOMER");
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return errorResponse("Provide a valid product and quantity.");
    const { productId, quantity } = parsed.data;
    const product = await prisma.product.findFirst({ where: { id: productId, status: "ACTIVE" } });
    if (!product) return errorResponse("Product is unavailable.", 404);
    if (product.stock < quantity) return errorResponse("Not enough stock available.", 409);
    const cart = await prisma.cart.upsert({ where: { userId: user.id }, create: { userId: user.id }, update: {} });
    const item = await prisma.cartItem.upsert({ where: { cartId_productId: { cartId: cart.id, productId } }, create: { cartId: cart.id, productId, quantity }, update: { quantity: { increment: quantity } } });
    return NextResponse.json({ item }, { status: 201 });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
export async function DELETE(request: Request) {
  try {
    const user = await requireRole("CUSTOMER");
    const url = new URL(request.url);
    const itemId = url.searchParams.get("itemId");
    if (!itemId) return errorResponse("itemId is required.");
    const item = await prisma.cartItem.findFirst({ where: { id: itemId, cart: { userId: user.id } } });
    if (!item) return errorResponse("Cart item not found.", 404);
    await prisma.cartItem.delete({ where: { id: item.id } });
    return NextResponse.json({ message: "Item removed." });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
