import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { createSession, setSessionCookie } from "@/lib/auth";
import { errorResponse, serverError } from "@/lib/http";

const schema = z.object({ email: z.email(), password: z.string().min(1) });
export async function POST(request: Request) {
  try {
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return errorResponse("Enter a valid email and password.");
    const email = parsed.data.email.toLowerCase();
    const user = await prisma.user.findUnique({ where: { email }, include: { vendor: true } });
    if (!user || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) return errorResponse("Invalid email or password.", 401);
    const token = await createSession({ id: user.id, email: user.email, name: user.name, role: user.role, vendorId: user.vendor?.id });
    await setSessionCookie(token);
    return NextResponse.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role, vendorStatus: user.vendor?.status } });
  } catch (e) { return serverError(e); }
}
