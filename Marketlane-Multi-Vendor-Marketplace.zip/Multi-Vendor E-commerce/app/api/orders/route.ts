import { NextResponse } from "next/server";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { requireRole, AuthError } from "@/lib/auth";
import { errorResponse, serverError } from "@/lib/http";

const addressSchema = z.object({ recipient: z.string().min(2), line1: z.string().min(3), line2: z.string().optional(), city: z.string().min(2), state: z.string().min(2), postalCode: z.string().min(3), country: z.string().default("India"), phone: z.string().min(8) });
export async function GET() {
  try {
    const user = await requireRole("CUSTOMER", "ADMIN", "SUPPORT", "VENDOR");
    const orders = await prisma.order.findMany({
      where: user.role === "CUSTOMER" ? { userId: user.id } : user.role === "VENDOR" ? { items: { some: { vendorId: user.vendorId } } } : {},
      include: { items: { include: { product: true, vendor: { select: { storeName: true } } } }, payment: true },
      orderBy: { createdAt: "desc" }, take: 100
    });
    return NextResponse.json({ orders });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
export async function POST(request: Request) {
  try {
    const user = await requireRole("CUSTOMER");
    const parsed = z.object({ shippingAddress: addressSchema }).safeParse(await request.json());
    if (!parsed.success) return errorResponse(parsed.error.issues[0]?.message ?? "Invalid shipping address.");
    const cart = await prisma.cart.findUnique({ where: { userId: user.id }, include: { items: { include: { product: { include: { vendor: true } } } } } });
    if (!cart?.items.length) return errorResponse("Your cart is empty.");
    const order = await prisma.$transaction(async tx => {
      let subtotal = new Prisma.Decimal(0);
      const lines = cart.items.map(item => {
        if (item.product.status !== "ACTIVE" || item.product.stock < item.quantity) throw new Error(`Insufficient stock for ${item.product.name}.`);
        const lineTotal = item.product.price.mul(item.quantity);
        subtotal = subtotal.add(lineTotal);
        const commission = lineTotal.mul(item.product.vendor.commissionBps).div(10000).toDecimalPlaces(2);
        return { productId: item.productId, vendorId: item.product.vendorId, productName: item.product.name, quantity: item.quantity, unitPrice: item.product.price, commissionAmount: commission, vendorNetAmount: lineTotal.sub(commission), gross: lineTotal };
      });
      const created = await tx.order.create({
        data: {
          orderNumber: `MV-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
          userId: user.id, subtotal, total: subtotal, shippingAddress: parsed.data.shippingAddress,
          items: { create: lines.map(({ gross, ...line }) => line) },
          payment: { create: { amount: subtotal, status: "PENDING", provider: "MANUAL" } }
        }, include: { items: true }
      });
      for (const item of cart.items) {
        await tx.product.update({ where: { id: item.productId }, data: { stock: { decrement: item.quantity } } });
      }
      const grouped = new Map<string, { gross: Prisma.Decimal; commission: Prisma.Decimal; net: Prisma.Decimal }>();
      for (const line of lines) {
        const old = grouped.get(line.vendorId) ?? { gross: new Prisma.Decimal(0), commission: new Prisma.Decimal(0), net: new Prisma.Decimal(0) };
        old.gross = old.gross.add(line.gross); old.commission = old.commission.add(line.commissionAmount); old.net = old.net.add(line.vendorNetAmount); grouped.set(line.vendorId, old);
      }
      for (const [vendorId, amounts] of grouped) await tx.vendorPayout.create({ data: { vendorId, orderId: created.id, grossAmount: amounts.gross, commission: amounts.commission, netAmount: amounts.net } });
      await tx.cartItem.deleteMany({ where: { cartId: cart.id } });
      return created;
    });
    return NextResponse.json({ order }, { status: 201 });
  } catch (e) {
    if (e instanceof AuthError) return errorResponse(e.message, e.status);
    if (e instanceof Error && e.message.startsWith("Insufficient stock")) return errorResponse(e.message, 409);
    return serverError(e);
  }
}
