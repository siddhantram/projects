import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await prisma.product.findFirst({ where: { OR: [{ slug }, { id: slug }], status: "ACTIVE" }, include: { vendor: true, category: true } }).catch(() => null);
  if (!product) notFound();
  return <><header className="site-header"><Link href="/" className="brand">market<span>lane.</span></Link><div className="header-actions"><Link href="/" className="pill">← Continue shopping</Link><Link href="/login" className="pill dark">Log in to buy</Link></div></header><main className="page-shell"><div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(280px,1fr))",gap:38,alignItems:"start"}}><div className="product-image" style={{height:430,borderRadius:20}}>{product.imageUrl ? <img src={product.imageUrl} alt={product.name}/> : <span style={{fontSize:80}}>✳</span>}</div><div><div className="eyebrow" style={{color:"var(--green)"}}>{product.vendor.storeName}</div><h1 style={{fontSize:42,letterSpacing:-1.5,marginBottom:8}}>{product.name}</h1><p style={{fontSize:25,fontWeight:800}}>₹{Number(product.price).toLocaleString("en-IN")}</p><p className="muted">{product.description}</p><p className="muted">{product.stock > 0 ? `${product.stock} in stock` : "Out of stock"}</p><Link href="/login" className="hero-cta" style={{background:"var(--ink)",color:"white"}}>Log in to add to cart ↗</Link><p className="muted">Secure checkout and order history are available after signing in.</p></div></div></main></>;
}
