import { NextResponse } from "next/server";

export function errorResponse(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}
export function serverError(error: unknown) {
  console.error(error);
  return errorResponse("An unexpected server error occurred.", 500);
}
