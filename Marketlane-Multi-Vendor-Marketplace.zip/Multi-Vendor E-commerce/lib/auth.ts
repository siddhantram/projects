import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import { prisma } from "@/lib/db";
import type { Role } from "@prisma/client";

const COOKIE_NAME = "marketplace_session";
function secret() {
  const value = process.env.JWT_SECRET;
  if (!value || value.length < 32) throw new Error("JWT_SECRET must be at least 32 characters.");
  return new TextEncoder().encode(value);
}

export type SessionUser = { id: string; email: string; name: string; role: Role; vendorId?: string };

export async function createSession(user: SessionUser) {
  return new SignJWT({ email: user.email, name: user.name, role: user.role, vendorId: user.vendorId })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(secret());
}

export async function setSessionCookie(token: string) {
  const store = await cookies();
  store.set(COOKIE_NAME, token, {
    httpOnly: true, secure: process.env.NODE_ENV === "production",
    sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 7,
  });
}

export async function clearSessionCookie() {
  const store = await cookies();
  store.set(COOKIE_NAME, "", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 0 });
}

export async function getSession(): Promise<SessionUser | null> {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret());
    if (!payload.sub || typeof payload.email !== "string" || typeof payload.name !== "string" || typeof payload.role !== "string") return null;
    return { id: payload.sub, email: payload.email, name: payload.name, role: payload.role as Role, vendorId: typeof payload.vendorId === "string" ? payload.vendorId : undefined };
  } catch { return null; }
}

export async function requireUser() {
  const session = await getSession();
  if (!session) throw new AuthError("Please log in to continue.", 401);
  return session;
}
export async function requireRole(...roles: Role[]) {
  const user = await requireUser();
  if (!roles.includes(user.role)) throw new AuthError("You do not have permission to perform this action.", 403);
  return user;
}
export class AuthError extends Error {
  constructor(message: string, public status: number) { super(message); }
}
export async function sessionForDatabaseUser(id: string) {
  const user = await prisma.user.findUnique({ where: { id }, include: { vendor: true } });
  if (!user) return null;
  return { id: user.id, email: user.email, name: user.name, role: user.role, vendorId: user.vendor?.id };
}
