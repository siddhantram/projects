# Marketlane — Multi-vendor marketplace starter

A runnable full-stack marketplace foundation built with Next.js App Router, TypeScript, PostgreSQL, Prisma, cookie-based sessions, and role checks. It includes a customer storefront, product detail pages, customer/vendor registration, login/logout APIs, vendor onboarding approval, vendor dashboard, admin overview, product APIs, cart APIs, transactional checkout/order creation, commission calculations, and vendor payout ledger records.

> **Scope honesty:** This is a strong runnable MVP foundation, not a production-certified Amazon/Flipkart clone. Real payment-provider integration, shipping integrations, email delivery, Redis/BullMQ workers, refunds, rate limiting/WAF, automated tests, and production observability still need to be added and tested before handling real customers or money. The current payment record is deliberately `MANUAL` and does not charge cards.

## Requirements

- Node.js 20.19+ (Node 22 LTS recommended)
- npm
- Docker Desktop, or a PostgreSQL 16 server

## 1. Install

In Windows PowerShell or Command Prompt, enter the project folder:

```bash
cd "Multi-Vendor E-commerce"
npm install
```

If you downloaded the ZIP, extract it first. Do not run commands from the parent directory.

## 2. Configure environment

Copy `.env.example` to `.env`.

Windows Command Prompt:
```bat
copy .env.example .env
```

PowerShell:
```powershell
Copy-Item .env.example .env
```

Keep the local database URL for the included Docker setup. Replace `JWT_SECRET` with a random secret of at least 32 characters. Never commit `.env`.

## 3. Start PostgreSQL

```bash
docker compose up -d postgres
```

Wait until the database health check is healthy.

## 4. Create tables and demo data

```bash
npx prisma generate
npx prisma migrate dev --name init
npm run db:seed
```

Demo accounts (seed password for both: `DemoPass123!`):

- Admin: `admin@marketplace.local`
- Vendor: `vendor@marketplace.local`

Change or remove demo credentials before any public deployment. The demo vendor is pre-approved and has sample products.

## 5. Run the app

```bash
npm run dev
```

Open http://localhost:3000.

## Available pages

- `/` — storefront and product catalogue
- `/products/<slug>` — product detail
- `/login` and `/register` — account flows
- `/vendor` — vendor dashboard (vendor/admin roles)
- `/admin` — admin overview and vendor applications

## API overview

All successful API responses are JSON. Errors use `{ "error": "..." }`.

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Create customer/vendor account |
| POST | `/api/auth/login` | Sign in and set HttpOnly cookie |
| POST | `/api/auth/logout` | Clear session |
| GET | `/api/auth/me` | Current session |
| GET | `/api/products?q=lamp&page=1&limit=12` | Search and paginate active products |
| POST | `/api/products` | Create a product (approved vendor/admin) |
| GET | `/api/products/:id` | Get active product by ID or slug |
| PATCH | `/api/products/:id` | Update own product (admin can manage all) |
| DELETE | `/api/products/:id` | Archive own product (admin can manage all) |
| GET | `/api/cart` | Get signed-in customer's cart |
| POST | `/api/cart` | Add `{ "productId": "...", "quantity": 1 }` |
| DELETE | `/api/cart?itemId=...` | Remove own cart item |
| GET | `/api/orders` | List orders allowed for the current role |
| POST | `/api/orders` | Checkout cart and create order, commission, payout ledger |
| PATCH | `/api/admin/vendors/:id` | Admin approves/rejects/suspends vendor |

Vendor approval example (send while logged in as admin, e.g. from an API client):
```json
{ "status": "APPROVED", "commissionBps": 1000 }
```
`commissionBps` uses basis points: `1000` means 10%.

## Checkout request

`POST /api/orders` expects:
```json
{
  "shippingAddress": {
    "recipient": "Demo Customer",
    "line1": "12 Example Road",
    "city": "New Delhi",
    "state": "Delhi",
    "postalCode": "110001",
    "country": "India",
    "phone": "9999999999"
  }
}
```

The checkout uses a database transaction to create the order and line items, decrement stock, clear the cart, and create vendor payout ledger entries. It creates a pending manual payment record only; it does **not** collect money.

## Security notes before production

- Set a unique, strong `JWT_SECRET`, enforce HTTPS, and use production environment variables.
- Remove demo credentials and seed data from public deployments.
- Add rate limiting to authentication and write APIs, email verification/password reset, CSRF strategy appropriate to your deployment, audit logging, monitoring, backups, and security tests.
- Integrate a marketplace-capable payment provider and verify webhooks server-side before marking payments paid or releasing payouts.
- Add idempotency keys to checkout/payment operations, robust shipping/tax rules, refunds, and reconciliation.
- Review all role/ownership rules and run automated tests before production.
- Configure image uploads through a trusted object-storage service; do not accept arbitrary untrusted upload URLs in a production vendor portal.

## Useful commands

```bash
npm run dev
npm run build
npm run lint
npm run db:studio
docker compose down
```

To delete the local database volume and all local data, run `docker compose down -v` (destructive).
