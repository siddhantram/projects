CREATE EXTENSION IF NOT EXISTS vector;

CREATE TYPE "AIAgentType" AS ENUM ('BUSINESS','SALES','FINANCE','HR','SUPPORT','ANALYTICS');
CREATE TYPE "AIMessageRole" AS ENUM ('USER','ASSISTANT','TOOL','SYSTEM');
CREATE TYPE "AIDocumentStatus" AS ENUM ('PROCESSING','READY','FAILED');

CREATE TABLE "AIConversation" (
  "id" TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "title" TEXT NOT NULL DEFAULT 'New conversation',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "AIConversation_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "AIConversation_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "AIConversation_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX "AIConversation_organizationId_userId_updatedAt_idx" ON "AIConversation"("organizationId","userId","updatedAt");

CREATE TABLE "AIMessage" (
  "id" TEXT NOT NULL,
  "conversationId" TEXT NOT NULL,
  "role" "AIMessageRole" NOT NULL,
  "content" TEXT NOT NULL,
  "metadata" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AIMessage_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "AIMessage_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "AIConversation"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX "AIMessage_conversationId_createdAt_idx" ON "AIMessage"("conversationId","createdAt");

CREATE TABLE "AIDocument" (
  "id" TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "uploadedById" TEXT,
  "name" TEXT NOT NULL,
  "mimeType" TEXT,
  "sizeBytes" INTEGER,
  "status" "AIDocumentStatus" NOT NULL DEFAULT 'PROCESSING',
  "textContent" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "AIDocument_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "AIDocument_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "AIDocument_uploadedById_fkey" FOREIGN KEY ("uploadedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE INDEX "AIDocument_organizationId_createdAt_idx" ON "AIDocument"("organizationId","createdAt");

CREATE TABLE "AIDocumentChunk" (
  "id" TEXT NOT NULL,
  "documentId" TEXT NOT NULL,
  "chunkIndex" INTEGER NOT NULL,
  "content" TEXT NOT NULL,
  "embedding" vector(1536),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AIDocumentChunk_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "AIDocumentChunk_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES "AIDocument"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE UNIQUE INDEX "AIDocumentChunk_documentId_chunkIndex_key" ON "AIDocumentChunk"("documentId","chunkIndex");
CREATE INDEX "AIDocumentChunk_documentId_idx" ON "AIDocumentChunk"("documentId");

CREATE TABLE "AIAgentRun" (
  "id" TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "userId" TEXT,
  "agentType" "AIAgentType" NOT NULL,
  "input" TEXT NOT NULL,
  "output" TEXT,
  "toolName" TEXT,
  "toolResult" JSONB,
  "durationMs" INTEGER,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AIAgentRun_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "AIAgentRun_organizationId_createdAt_idx" ON "AIAgentRun"("organizationId","createdAt");
