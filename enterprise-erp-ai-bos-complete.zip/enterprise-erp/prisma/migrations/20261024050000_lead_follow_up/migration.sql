ALTER TABLE "SalesLead" ADD COLUMN "nextFollowUpAt" TIMESTAMP(3);
CREATE INDEX "SalesLead_organizationId_nextFollowUpAt_idx" ON "SalesLead"("organizationId", "nextFollowUpAt");
