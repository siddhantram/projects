ALTER TABLE "Organization"
ADD COLUMN "rolePermissions" JSONB;
