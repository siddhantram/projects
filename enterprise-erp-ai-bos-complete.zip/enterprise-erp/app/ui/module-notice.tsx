type ModuleNoticeProps = { title: string; description: string; workflow: string[] };

export default function ModuleNotice({ title, description, workflow }: ModuleNoticeProps) {
  return <>
    <div className="page-heading"><div><div className="eyebrow">BUSINESS OPERATIONS</div><h1>{title}</h1><p>{description}</p></div></div>
    <section className="panel module-notice"><div className="module-symbol">⌁</div><div className="eyebrow">WORKSPACE MODULE</div><h2>{title} records will appear here</h2><p>This area is ready for your {title.toLowerCase()} workflow. Its document and approval setup is not configured yet.</p><div className="workflow-strip">{workflow.map((step, index) => <div className="workflow-step" key={step}><span>{String(index + 1).padStart(2, "0")}</span><strong>{step}</strong>{index < workflow.length - 1 && <i>→</i>}</div>)}</div></section>
  </>;
}
