"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

type AuthFormProps = { mode: "login" | "register" };

export default function AuthForm({ mode }: AuthFormProps) {
  const router = useRouter();
  const registering = mode === "register";
  const [mfaRequired, setMfaRequired] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setBusy(true);
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(form.entries());
    try {
      const response = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (result.mfaRequired) setMfaRequired(true);
      if (response.ok && result.mfaRequired) return;
      if (!response.ok) throw new Error(result.error ?? "Something went wrong");
      router.replace("/dashboard");
      router.refresh();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to sign in");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth-screen">
      <div className="auth-brand"><span className="brand-mark">E</span><span>Enterprise<span className="brand-muted">ERP</span></span></div>
      <section className="auth-card">
        <div className="eyebrow">WORKSPACE ACCESS</div>
        <h1>{registering ? "Create your workspace" : "Welcome back"}</h1>
        <p className="auth-subtitle">{registering ? "Set up your company and invite your team later." : "Sign in to continue to your business workspace."}</p>
        <form onSubmit={submit} className="auth-form">
          {registering && <label>Company name<input name="organizationName" placeholder="Acme Technologies" required minLength={2} maxLength={120} autoComplete="organization" /></label>}
          {registering && <label>Your name<input name="name" placeholder="Siddhant Sharma" required minLength={2} maxLength={120} autoComplete="name" /></label>}
          <label>Work email<input name="email" type="email" placeholder="you@company.com" required autoComplete="email" /></label>
          <label>Password<input name="password" type="password" placeholder={registering ? "At least 10 characters" : "Your password"} required minLength={registering ? 10 : 1} autoComplete={registering ? "new-password" : "current-password"} /></label>
          {mfaRequired && <label>Authenticator or recovery code<input name="mfaCode" placeholder="Six-digit code or recovery code" required autoComplete="one-time-code" /></label>}
          {error && <p className="form-error" role="alert">{error}</p>}
          <button className="button button-primary auth-submit" disabled={busy}>{busy ? "Please wait…" : registering ? "Create workspace" : "Sign in"}<span aria-hidden>→</span></button>
        </form>
        {!registering && <p className="auth-switch"><a href="/forgot-password">Forgot your password?</a></p>}
        <p className="auth-switch">{registering ? "Already have a workspace?" : "New to Enterprise ERP?"} <a href={registering ? "/login" : "/register"}>{registering ? "Sign in" : "Create an account"}</a></p>
      </section>
      <p className="auth-footnote">Secure, organization-based business management</p>
    </main>
  );
}
