"use client";

import { FormEvent, useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type PasswordRecoveryFormProps = { mode: "request" } | { mode: "reset"; token?: string };

export default function PasswordRecoveryForm(props: PasswordRecoveryFormProps) {
  const router = useRouter();
  const [resetToken] = useState(props.mode === "reset" ? props.token : undefined);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (props.mode === "reset" && resetToken) window.history.replaceState(window.history.state, "", "/reset-password");
  }, [props.mode, resetToken]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setMessage("");
    setBusy(true);
    const payload = Object.fromEntries(new FormData(event.currentTarget).entries());
    if (props.mode === "reset") payload.token = resetToken ?? "";
    try {
      const response = await fetch(`/api/auth/${props.mode === "request" ? "forgot-password" : "reset-password"}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Something went wrong");
      if (props.mode === "reset") {
        router.replace("/login?passwordReset=1");
        router.refresh();
      } else {
        setMessage(result.message ?? "If an active account matches that email, reset instructions will be sent.");
      }
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to process this request");
    } finally {
      setBusy(false);
    }
  }

  const resetting = props.mode === "reset";
  return (
    <main className="auth-screen">
      <div className="auth-brand"><span className="brand-mark">E</span><span>Enterprise<span className="brand-muted">ERP</span></span></div>
      <section className="auth-card">
        <div className="eyebrow">ACCOUNT RECOVERY</div>
        <h1>{resetting ? "Choose a new password" : "Reset your password"}</h1>
        <p className="auth-subtitle">{resetting ? "Choose a strong password with at least 12 characters." : "Enter your work email and we will send a one-time reset link if the account is active."}</p>
        <form onSubmit={submit} className="auth-form">
          {resetting ? <label>New password<input name="password" type="password" placeholder="At least 12 characters" required minLength={12} maxLength={200} autoComplete="new-password" /></label> : <label>Work email<input name="email" type="email" placeholder="you@company.com" required maxLength={254} autoComplete="email" /></label>}
          {error && <p className="form-error" role="alert">{error}</p>}
          {message && <p className="setup-hint" role="status">{message}</p>}
          <button className="button button-primary auth-submit" disabled={busy || (resetting && !resetToken)}>{busy ? "Please wait…" : resetting ? "Update password" : "Send reset link"}</button>
        </form>
        <p className="auth-switch"><a href="/login">Back to sign in</a></p>
      </section>
      <p className="auth-footnote">Reset links expire after 30 minutes and can be used once.</p>
    </main>
  );
}
