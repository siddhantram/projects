import PasswordRecoveryForm from "@/app/(auth)/password-recovery-form";

export default async function ResetPasswordPage({ searchParams }: { searchParams: Promise<{ token?: string | string[] }> }) {
  const { token } = await searchParams;
  return <PasswordRecoveryForm mode="reset" token={typeof token === "string" ? token : undefined} />;
}
