import PasswordRecoveryForm from "@/app/(auth)/password-recovery-form";

export default function ForgotPasswordPage() {
  return <PasswordRecoveryForm mode="request" />;
}
