"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type Product = { id: string; sku: string; name: string; category: string | null; costPrice: string | number; sellingPrice: string | number; reorderLevel: number; active: boolean; stock: number };

export default function ProductManager() {
  const [products, setProducts] = useState<Product[]>([]);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<Product | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    try { const response = await fetch(`/api/products?q=${encodeURIComponent(query)}`); const data = await response.json(); if (response.ok) setProducts(data.products); else setError(data.error ?? "Unable to load products"); }
    catch { setError("Unable to load products"); }
  }, [query]);
  useEffect(() => { void load(); }, [load]);

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      const response = await fetch(selected ? `/api/products/${selected.id}` : "/api/products", { method: selected ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.fromEntries(new FormData(event.currentTarget).entries())) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to save product"); return; }
      setOpen(false); setSelected(null); await load();
    } catch { setError("Network error. Please try again."); }
    finally { setBusy(false); }
  }

  async function toggleActive(product: Product) {
    setError("");
    try {
      const response = await fetch(`/api/products/${product.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ active: !product.active }) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to update product"); return; }
      await load();
    } catch { setError("Network error. Please try again."); }
  }

  return <>
    <div className="toolbar"><div className="search-box"><span>?</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search by name or SKU..." /></div><div className="toolbar-right"><span className="result-count">{products.length} products</span><button className="button button-primary" onClick={() => { setSelected(null); setError(""); setOpen(true); }}>Add product</button></div></div>
    {error && <div className="inline-error" role="alert">{error}</div>}
    <div className="panel data-panel"><div className="table-wrap"><table><thead><tr><th>PRODUCT</th><th>CATEGORY</th><th>COST</th><th>SELLING PRICE</th><th>IN STOCK</th><th>REORDER AT</th><th>STATUS</th><th></th></tr></thead><tbody>{products.map((product) => <tr key={product.id}><td><div className="customer-cell"><span className="product-thumb">P</span><span>{product.name}<small>{product.sku}</small></span></div></td><td>{product.category ?? "—"}</td><td>{Number(product.costPrice).toLocaleString("en-IN", { minimumFractionDigits: 2 })}</td><td>{Number(product.sellingPrice).toLocaleString("en-IN", { minimumFractionDigits: 2 })}</td><td><strong>{product.stock}</strong> <span className="table-unit">units</span></td><td>{product.reorderLevel}</td><td><span className={`badge ${product.active ? "badge-green" : "badge-neutral"}`}>{product.active ? "Active" : "Archived"}</span></td><td><div className="row-actions"><button onClick={() => { setSelected(product); setError(""); setOpen(true); }}>Edit</button><button className={product.active ? "danger-action" : ""} onClick={() => void toggleActive(product)}>{product.active ? "Archive" : "Restore"}</button></div></td></tr>)}</tbody></table>{products.length === 0 && <div className="empty-state"><span className="empty-icon">P</span><strong>Your product catalog is ready</strong><span>Add products before recording stock movements.</span><button className="button button-secondary" onClick={() => setOpen(true)}>Add your first product</button></div>}</div></div>
    {open && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) { setOpen(false); setSelected(null); } }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="product-modal-title"><div className="modal-heading"><div><div className="eyebrow">PRODUCT CATALOG</div><h2 id="product-modal-title">{selected ? "Edit product" : "Add a product"}</h2></div><button className="icon-button" aria-label="Close" onClick={() => { setOpen(false); setSelected(null); }}>X</button></div><form onSubmit={save} className="auth-form"><div className="form-row"><label>Product name<input name="name" required minLength={2} placeholder="Wireless keyboard" defaultValue={selected?.name ?? ""} /></label><label>SKU<input name="sku" required placeholder="ACC-1042" defaultValue={selected?.sku ?? ""} /></label></div><label>Category<input name="category" placeholder="Accessories" defaultValue={selected?.category ?? ""} /></label><div className="form-row"><label>Cost price<input name="costPrice" type="number" min="0" step="0.01" defaultValue={selected?.costPrice ?? 0} /></label><label>Selling price<input name="sellingPrice" type="number" min="0" step="0.01" defaultValue={selected?.sellingPrice ?? 0} /></label></div><label>Reorder level<input name="reorderLevel" type="number" min="0" step="1" defaultValue={selected?.reorderLevel ?? 0} /></label>{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => { setOpen(false); setSelected(null); }}>Cancel</button><button disabled={busy} className="button button-primary">{busy ? "Saving..." : selected ? "Save changes" : "Save product"}</button></div></form></section></div>}
  </>;
}
