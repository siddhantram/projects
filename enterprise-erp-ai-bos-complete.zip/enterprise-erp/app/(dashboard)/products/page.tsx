import ProductManager from "./product-manager";
import { requirePagePermission } from "@/lib/page-access";

export default async function ProductsPage() {
  await requirePagePermission("products.read");
  return <><div className="page-heading"><div><div className="eyebrow">CATALOG</div><h1>Products</h1><p>Manage SKUs, pricing and reorder levels.</p></div></div><ProductManager /></>;
}
