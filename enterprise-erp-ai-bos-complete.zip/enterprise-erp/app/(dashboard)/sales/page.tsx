import SalesManager from "./sales-manager";
import { requirePagePermission } from "@/lib/page-access";
import { hasPermission } from "@/lib/permissions";

export default async function SalesPage() {
  const user = await requirePagePermission("sales.read");
  const canCancelOrders = hasPermission(user.role, "sales.approve", user.organization.rolePermissions);
  return <><div className="page-heading"><div><div className="eyebrow">REVENUE OPERATIONS</div><h1>Sales</h1><p>Track lead follow-up and conversion alongside quotations, orders, invoices and payments.</p></div></div><SalesManager canCancelOrders={canCancelOrders} /></>;
}
