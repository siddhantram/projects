import { notFound, redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import PrintButton from "@/app/ui/print-button";

function formatMoney(amount: number, currency: string) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency, maximumFractionDigits: 2 }).format(amount);
}

function formatDate(date: Date, timeZone: string) {
  return new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "long", year: "numeric", timeZone }).format(date);
}

export default async function QuotationPrintPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!hasPermission(user.role, "sales.read", user.organization.rolePermissions)) redirect("/sales");
  const { id } = await params;
  const quotation = await db.quotation.findFirst({
    where: { id, organizationId: user.organizationId },
    include: { customer: true, lines: true, salesOrder: { select: { number: true } } },
  });
  if (!quotation) notFound();

  return <>
    <div className="quotation-print-actions"><a className="button button-secondary" href="/sales">Back to sales</a><PrintButton /></div>
    <article className="quotation-sheet">
      <header className="quotation-header">
        <div><div className="eyebrow">QUOTATION</div><h1>{quotation.number}</h1><span className={`badge ${quotation.status === "APPROVED" ? "badge-green" : "badge-neutral"}`}>{quotation.status.replaceAll("_", " ")}</span></div>
        <div className="quotation-company"><strong>{user.organization.name}</strong>{user.organization.address && <span>{user.organization.address}</span>}{user.organization.taxId && <span>GST / VAT: {user.organization.taxId}</span>}</div>
      </header>
      <section className="quotation-parties">
        <div><div className="eyebrow">PREPARED FOR</div><strong>{quotation.customer.company || quotation.customer.name}</strong>{quotation.customer.company && <span>{quotation.customer.name}</span>}{quotation.customer.email && <span>{quotation.customer.email}</span>}{quotation.customer.phone && <span>{quotation.customer.phone}</span>}</div>
        <dl><div><dt>Issue date</dt><dd>{formatDate(quotation.createdAt, user.organization.timezone)}</dd></div><div><dt>Valid until</dt><dd>{quotation.validUntil ? formatDate(quotation.validUntil, "UTC") : "No expiry date"}</dd></div>{quotation.salesOrder && <div><dt>Sales order</dt><dd>{quotation.salesOrder.number}</dd></div>}</dl>
      </section>
      <div className="quotation-table-wrap"><table className="quotation-table"><thead><tr><th>DESCRIPTION</th><th>QTY</th><th>UNIT PRICE</th><th>TAX</th><th>LINE TOTAL</th></tr></thead><tbody>{quotation.lines.map((line) => <tr key={line.id}><td>{line.description}</td><td>{line.quantity}</td><td>{formatMoney(Number(line.unitPrice), quotation.currency)}</td><td>{Number(line.taxRate)}%</td><td>{formatMoney(Number(line.lineTotal), quotation.currency)}</td></tr>)}</tbody></table></div>
      <section className="quotation-summary"><div><span>Subtotal</span><strong>{formatMoney(Number(quotation.subtotal), quotation.currency)}</strong></div><div><span>Tax</span><strong>{formatMoney(Number(quotation.taxAmount), quotation.currency)}</strong></div><div className="quotation-total"><span>Total</span><strong>{formatMoney(Number(quotation.total), quotation.currency)}</strong></div></section>
      {quotation.notes && <section className="quotation-notes"><div className="eyebrow">NOTES</div><p>{quotation.notes}</p></section>}
      <footer className="quotation-footer">Thank you for considering {user.organization.name}.</footer>
    </article>
  </>;
}
