﻿"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type Employee = { id: string; employeeCode: string; name: string; email: string | null; phone: string | null; designation: string | null; baseSalary: string | null; active: boolean; department: { id: string; name: string } | null };
type Department = { id: string; name: string };
type Attendance = { id: string; workDate: string; checkIn: string | null; checkOut: string | null; status: string; employee: { id: string; employeeCode: string; name: string } };
type LeaveRequest = { id: string; type: string; status: string; startDate: string; endDate: string; reason: string | null; employee: { id: string; employeeCode: string; name: string } };
type PayrollRecord = { id: string; periodStart: string; grossPay: string; deductions: string; netPay: string; status: string; employee: { id: string; employeeCode: string; name: string } };
type HRData = { employees: Employee[]; departments: Department[]; attendance: Attendance[]; leaveRequests: LeaveRequest[]; payrollRecords: PayrollRecord[]; employee?: Employee | null; meEmployee?: Employee | null; unlinkedUsers?: { id: string; name: string; email: string }[]; access?: { employeesRead: boolean; employeesCreate: boolean; attendanceRead: boolean; attendanceSelf: boolean; leaveRead: boolean; leaveApprove: boolean; leaveCreate: boolean; payrollRead: boolean; payrollCreate: boolean; payrollApprove: boolean; payrollPay: boolean } };
type TabName = "Employees" | "Attendance" | "Leave" | "Payroll";
type Mode = "employee" | "department" | "leave" | "payroll" | null;

export default function HRManager() {
  const [data, setData] = useState<HRData | null>(null);
  const [tab, setTab] = useState<TabName>("Employees");
  const [mode, setMode] = useState<Mode>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const load = useCallback(async () => { const response = await fetch("/api/hr"); const result = await response.json(); if (response.ok) setData(result); else setError(result.error ?? "Unable to load people workspace"); }, []);
  useEffect(() => { void load(); }, [load]);

  async function send(payload: Record<string, unknown>): Promise<boolean> {
    setBusy(true); setError(""); setMessage("");
    try {
      const response = await fetch("/api/hr", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to complete this people action"); return false; }
      setMessage("People record saved."); await load(); return true;
    } catch { setError("Network error. Please try again."); return false; }
    finally { setBusy(false); }
  }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!mode) return;
    const values = Object.fromEntries(new FormData(event.currentTarget).entries());
    const action = mode === "employee" || mode === "department" || mode === "leave" || mode === "payroll" ? mode : "";
    if (await send({ action, ...values, ...(mode === "payroll" && values.periodStart ? { periodStart: `${values.periodStart}-01` } : {}) })) setMode(null);
  }

  const tabs: TabName[] = data ? [
    ...(data.access?.employeesRead ? ["Employees" as const] : []),
    ...(data.access?.attendanceRead || data.access?.attendanceSelf ? ["Attendance" as const] : []),
    ...(data.access?.leaveRead || data.access?.leaveApprove || data.access?.leaveCreate ? ["Leave" as const] : []),
    ...(data.access?.payrollRead ? ["Payroll" as const] : []),
  ] : ["Employees"];
  const tabIsAvailable = tabs.includes(tab);
  const firstAvailableTab = tabs[0];
  useEffect(() => { if (!tabIsAvailable && firstAvailableTab) setTab(firstAvailableTab); }, [tabIsAvailable, firstAvailableTab]);
  const listCounts = { Employees: data?.employees.length ?? 0, Attendance: data?.attendance.length ?? 0, Leave: data?.leaveRequests.length ?? 0, Payroll: data?.payrollRecords.length ?? 0 };
  const leaveEmployees = data?.access?.employeesRead ? data.employees.filter((employee) => employee.active) : data?.meEmployee?.active ? [data.meEmployee] : [];
  const money = (value: string) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(Number(value));
  const date = (value: string) => new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" }).format(new Date(value));

  return <>
    {error && <div className="inline-error" role="alert">{error}</div>}{message && <p className="form-success sales-message" role="status">{message}</p>}
    {data?.access?.attendanceSelf && data.meEmployee && <section className="panel attendance-punch"><div><strong>My attendance</strong><p>Clock times are recorded for today in the workspace timezone.</p></div><div><button disabled={busy} className="button button-secondary" onClick={() => void send({ action: "clock-in" })}>Clock in</button><button disabled={busy} className="button button-primary" onClick={() => void send({ action: "clock-out" })}>Clock out</button></div></section>}
    <div className="toolbar"><div className="tab-list">{tabs.map((item) => <button key={item} className={tab === item ? "tab-button active" : "tab-button"} onClick={() => setTab(item)}>{item}<span>{listCounts[item]}</span></button>)}</div><div className="toolbar-right">{tab === "Employees" && data?.access?.employeesCreate && <><button className="button button-secondary" onClick={() => setMode("department")}>＋ Department</button><button className="button button-primary" onClick={() => setMode("employee")}>＋ Add employee</button></>}{tab === "Leave" && data?.access?.leaveCreate && <button className="button button-primary" onClick={() => setMode("leave")}>＋ Request leave</button>}{tab === "Payroll" && data?.access?.payrollCreate && <button className="button button-primary" onClick={() => setMode("payroll")}>＋ Create payroll</button>}</div></div>
    {!data ? <div className="panel loading-state">Loading people workspace…</div> : <div className="panel data-panel"><div className="table-wrap">
      {tab === "Employees" && <table><thead><tr><th>EMPLOYEE</th><th>DEPARTMENT</th><th>DESIGNATION</th><th>EMAIL</th><th>BASE SALARY</th><th>STATUS</th></tr></thead><tbody>{data.employees.map((employee) => <tr key={employee.id}><td><div className="customer-cell"><span className="customer-avatar">{employee.name.slice(0, 1).toUpperCase()}</span><span>{employee.name}<small>{employee.employeeCode}</small></span></div></td><td>{employee.department?.name ?? "—"}</td><td>{employee.designation ?? "—"}</td><td>{employee.email ?? "—"}</td><td>{employee.baseSalary === null ? "Restricted" : money(employee.baseSalary)}</td><td><span className="badge badge-green">{employee.active ? "Active" : "Inactive"}</span></td></tr>)}</tbody></table>}
      {tab === "Attendance" && <table><thead><tr><th>EMPLOYEE</th><th>DATE</th><th>STATUS</th><th>CHECK IN</th><th>CHECK OUT</th></tr></thead><tbody>{data.attendance.map((record) => <tr key={record.id}><td><div className="customer-cell"><span>{record.employee.name}<small>{record.employee.employeeCode}</small></span></div></td><td>{date(record.workDate)}</td><td><span className="movement-type">{record.status}</span></td><td>{record.checkIn ? new Intl.DateTimeFormat("en-IN", { hour: "2-digit", minute: "2-digit" }).format(new Date(record.checkIn)) : "—"}</td><td>{record.checkOut ? new Intl.DateTimeFormat("en-IN", { hour: "2-digit", minute: "2-digit" }).format(new Date(record.checkOut)) : "—"}</td></tr>)}</tbody></table>}
      {tab === "Leave" && <table><thead><tr><th>EMPLOYEE</th><th>TYPE</th><th>DATES</th><th>REASON</th><th>STATUS</th><th></th></tr></thead><tbody>{data.leaveRequests.map((leave) => <tr key={leave.id}><td><div className="customer-cell"><span>{leave.employee.name}<small>{leave.employee.employeeCode}</small></span></div></td><td>{leave.type}</td><td>{date(leave.startDate)} – {date(leave.endDate)}</td><td>{leave.reason ?? "—"}</td><td><span className={`badge ${leave.status === "APPROVED" ? "badge-green" : "badge-neutral"}`}>{leave.status}</span></td><td>{data.access?.leaveApprove && leave.status === "PENDING" && <div className="row-actions"><button onClick={() => void send({ action: "approve-leave", id: leave.id })}>Approve</button><button className="danger-action" onClick={() => void send({ action: "reject-leave", id: leave.id })}>Reject</button></div>}</td></tr>)}</tbody></table>}
      {tab === "Payroll" && data.access?.payrollRead && <table><thead><tr><th>EMPLOYEE</th><th>PERIOD</th><th>GROSS</th><th>DEDUCTIONS</th><th>NET PAY</th><th>STATUS</th><th></th></tr></thead><tbody>{data.payrollRecords.map((payroll) => <tr key={payroll.id}><td><div className="customer-cell"><span>{payroll.employee.name}<small>{payroll.employee.employeeCode}</small></span></div></td><td>{new Intl.DateTimeFormat("en-IN", { month: "short", year: "numeric", timeZone: "UTC" }).format(new Date(payroll.periodStart))}</td><td>{money(payroll.grossPay)}</td><td>{money(payroll.deductions)}</td><td><strong>{money(payroll.netPay)}</strong></td><td><span className={`badge ${payroll.status === "PAID" ? "badge-green" : "badge-neutral"}`}>{payroll.status}</span></td><td><div className="row-actions">{data.access?.payrollApprove && payroll.status === "DRAFT" && <button onClick={() => void send({ action: "approve-payroll", id: payroll.id })}>Approve</button>}{data.access?.payrollPay && payroll.status === "APPROVED" && <button onClick={() => void send({ action: "pay-payroll", id: payroll.id })}>Pay</button>}</div></td></tr>)}</tbody></table>}
      {((tab === "Employees" && !data.employees.length) || (tab === "Attendance" && !data.attendance.length) || (tab === "Leave" && !data.leaveRequests.length) || (tab === "Payroll" && !data.payrollRecords.length)) && <div className="empty-state"><span className="empty-icon">♙</span><strong>No {tab.toLowerCase()} records</strong><span>People and attendance records for this workspace will appear here.</span>{tab === "Employees" && data.access?.employeesCreate && <button className="button button-secondary" onClick={() => setMode("employee")}>Add an employee</button>}</div>}
    </div></div>}
    {mode && data && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setMode(null); }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="hr-modal-title"><div className="modal-heading"><div><div className="eyebrow">PEOPLE OPERATIONS</div><h2 id="hr-modal-title">{mode === "employee" ? "Add an employee" : mode === "department" ? "Add a department" : mode === "leave" ? "Request leave" : "Create monthly payroll"}</h2></div><button className="icon-button" aria-label="Close" onClick={() => setMode(null)}>×</button></div><form className="auth-form" onSubmit={submit}>
      {mode === "department" && <><label>Department name<input name="name" required minLength={2} placeholder="Operations" /></label><label>Description<input name="description" placeholder="Optional department description" /></label></>}
      {mode === "employee" && <><div className="form-row"><label>Employee ID<input name="employeeCode" required minLength={2} placeholder="EMP-1042" /></label><label>Full name<input name="name" required minLength={2} placeholder="Employee name" /></label></div><div className="form-row"><label>Work email<input name="email" type="email" placeholder="employee@company.com" /></label><label>Phone<input name="phone" type="tel" placeholder="+91 98765 43210" /></label></div><div className="form-row"><label>Department<select name="departmentId"><option value="">No department</option>{data.departments.map((department) => <option key={department.id} value={department.id}>{department.name}</option>)}</select></label><label>Designation<input name="designation" placeholder="Accountant" /></label></div><div className="form-row">{data.access?.payrollCreate && <label>Base monthly salary<input name="baseSalary" type="number" min="0" step="0.01" defaultValue="0" /></label>}<label>Hire date<input name="hireDate" type="date" /></label></div><label>Link login account<select name="userId"><option value="">No login linked</option>{data.unlinkedUsers?.map((account) => <option key={account.id} value={account.id}>{account.name} · {account.email}</option>)}</select></label></>}
      {mode === "leave" && <>{leaveEmployees.length > 0 && <label>Employee<select name="employeeId" required>{leaveEmployees.map((employee) => <option key={employee.id} value={employee.id}>{employee.name} · {employee.employeeCode}</option>)}</select></label>}<div className="form-row"><label>Leave type<select name="type"><option value="CASUAL">Casual</option><option value="SICK">Sick</option><option value="UNPAID">Unpaid</option><option value="OTHER">Other</option></select></label><label>Reason<input name="reason" placeholder="Optional reason" /></label></div><div className="form-row"><label>From<input name="startDate" type="date" required /></label><label>Through<input name="endDate" type="date" required /></label></div></>}
      {mode === "payroll" && <><label>Employee<select name="employeeId" required>{data.employees.filter((employee) => employee.active).map((employee) => <option key={employee.id} value={employee.id}>{employee.name} · {employee.baseSalary === null ? "salary restricted" : `${money(employee.baseSalary)} base`}</option>)}</select></label><div className="form-row"><label>Payroll month<input name="periodStart" type="month" required /></label><label>Deductions<input name="deductions" type="number" min="0" step="0.01" defaultValue="0" /></label></div></>}
      {error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => setMode(null)}>Cancel</button><button disabled={busy || (mode === "leave" && !leaveEmployees.length) || (mode === "payroll" && !data.employees.some((employee) => employee.active))} className="button button-primary">{busy ? "Saving…" : mode === "department" ? "Save department" : mode === "employee" ? "Save employee" : mode === "leave" ? "Submit request" : "Create payroll"}</button></div>
    </form></section></div>}
  </>;
}


