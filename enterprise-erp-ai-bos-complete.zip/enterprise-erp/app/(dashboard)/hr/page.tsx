import HRManager from "./hr-manager";
import { requirePageAnyPermission } from "@/lib/page-access";
import { hasPermission } from "@/lib/permissions";

export default async function HRPage() {
  const user = await requirePageAnyPermission(["employees.read", "attendance.self", "attendance.read", "leave.create", "leave.read", "leave.approve", "payroll.read"]);
  const canManageEmployees = hasPermission(user.role, "employees.read", user.organization.rolePermissions);
  return <><div className="page-heading"><div><div className="eyebrow">PEOPLE OPERATIONS</div><h1>People</h1><p>{canManageEmployees ? "Manage employees, departments, attendance, leave and payroll." : "Review your attendance and leave information."}</p></div></div><HRManager /></>;
}
