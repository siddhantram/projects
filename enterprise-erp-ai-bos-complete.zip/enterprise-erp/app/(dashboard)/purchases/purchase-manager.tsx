"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type Supplier = { id: string; name: string; email: string | null; phone: string | null; taxId: string | null; active: boolean };
type Product = { id: string; name: string; sku: string; costPrice: string };
type Warehouse = { id: string; name: string };
type ReceiptLine = { quantity: number };
type OrderLine = { id: string; productId: string; description: string; quantity: number; unitCost: string; lineTotal: string; product: Product; receipts: ReceiptLine[] };
type Order = { id: string; number: string; status: string; total: string; currency: string; createdAt: string; supplier: Supplier; lines: OrderLine[]; receipts: { id: string; number: string; warehouse: Warehouse; receivedAt: string }[] };
type SupplierInvoice = { id: string; number: string; status: string; currency: string; amount: string; paidAmount: string; dueDate: string | null; supplier: Supplier; purchaseOrder: { id: string; number: string } | null; payments: { id: string; amount: string; paidAt: string; method: string; reference: string | null }[] };
type PurchaseData = { suppliers: Supplier[]; orders: Order[]; products: Product[]; warehouses: Warehouse[]; supplierInvoices: SupplierInvoice[] };
type Mode = "supplier" | "order" | "receive" | "supplier-invoice" | "supplier-payment" | null;

export default function PurchaseManager({ canManageSuppliers, canCreateSuppliers }: { canManageSuppliers: boolean; canCreateSuppliers: boolean }) {
  const [data, setData] = useState<PurchaseData | null>(null);
  const [tab, setTab] = useState<"Orders" | "Suppliers" | "Invoices">("Orders");
  const [mode, setMode] = useState<Mode>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [selectedInvoice, setSelectedInvoice] = useState<SupplierInvoice | null>(null);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/purchases");
      const result = await response.json();
      if (response.ok) setData(result); else setError(result.error ?? "Unable to load purchasing data");
    } catch {
      setError("Unable to reach the purchasing service. Check your connection and try again.");
    }
  }, []);
  useEffect(() => { void load(); }, [load]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!mode) return;
    const values = Object.fromEntries(new FormData(event.currentTarget).entries());
    let payload: Record<string, unknown>;
    if (mode === "supplier") payload = editingSupplier ? { action: "supplier-update", id: editingSupplier.id, ...values } : { action: "supplier", ...values };
    else if (mode === "order") payload = { action: "order", supplierId: values.supplierId, notes: values.notes, lines: [{ productId: values.productId, quantity: Number(values.quantity), unitCost: Number(values.unitCost), taxRate: Number(values.taxRate) }] };
    else if (mode === "receive") {
      const quantities: Record<string, number> = {};
      selectedOrder?.lines.forEach((line) => { const quantity = Number(values[line.id]); if (quantity > 0) quantities[line.id] = quantity; });
      payload = { action: "receive", orderId: selectedOrder?.id, warehouseId: values.warehouseId, quantities };
    } else if (mode === "supplier-invoice") payload = { action: "supplier-invoice", ...values, amount: Number(values.amount) };
    else payload = { action: "supplier-payment", supplierInvoiceId: selectedInvoice?.id, ...values, amount: Number(values.amount) };
    await send(payload);
  }

  async function send(payload: Record<string, unknown>) {
    setBusy(true); setError(""); setMessage("");
    try {
      const isSupplierUpdate = payload.action === "supplier-update";
      const response = await fetch(isSupplierUpdate ? `/api/purchases/suppliers/${encodeURIComponent(String(payload.id))}` : "/api/purchases", { method: isSupplierUpdate ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(isSupplierUpdate ? Object.fromEntries(Object.entries(payload).filter(([key]) => key !== "action" && key !== "id")) : payload) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to complete this purchasing action"); return; }
      setMode(null); setSelectedOrder(null); setSelectedInvoice(null); setEditingSupplier(null); setMessage("Purchasing record saved."); await load();
    } catch {
      setError("Unable to reach the purchasing service. Check your connection and try again.");
    } finally {
      setBusy(false);
    }
  }

  const money = (amount: string, currency: string) => new Intl.NumberFormat("en-IN", { style: "currency", currency, maximumFractionDigits: 2 }).format(Number(amount));
  const orderCount = data?.orders.length ?? 0;
  const supplierCount = data?.suppliers.length ?? 0;
  const activeSuppliers = data?.suppliers.filter((supplier) => supplier.active) ?? [];

  async function setSupplierActive(supplier: Supplier) {
    setBusy(true); setError(""); setMessage("");
    try {
      const response = await fetch(`/api/purchases/suppliers/${encodeURIComponent(supplier.id)}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ active: !supplier.active }) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to update supplier status"); return; }
      setMessage(supplier.active ? "Supplier archived. Existing purchase history is retained." : "Supplier restored and available for new orders.");
      await load();
    } catch {
      setError("Unable to reach the purchasing service. Check your connection and try again.");
    } finally { setBusy(false); }
  }

  return <>
    {error && <div className="inline-error" role="alert">{error}</div>}{message && <p className="form-success sales-message" role="status">{message}</p>}
    <div className="toolbar"><div className="tab-list"><button className={tab === "Orders" ? "tab-button active" : "tab-button"} onClick={() => setTab("Orders")}>Purchase orders<span>{orderCount}</span></button><button className={tab === "Suppliers" ? "tab-button active" : "tab-button"} onClick={() => setTab("Suppliers")}>Suppliers<span>{supplierCount}</span></button><button className={tab === "Invoices" ? "tab-button active" : "tab-button"} onClick={() => setTab("Invoices")}>Supplier invoices<span>{data?.supplierInvoices.length ?? 0}</span></button></div><div className="toolbar-right">{tab === "Orders" && <button className="button button-primary" onClick={() => { setError(""); setMode("order"); }}>＋ New purchase order</button>}{tab === "Suppliers" && canCreateSuppliers && <button className="button button-secondary" onClick={() => { setError(""); setEditingSupplier(null); setMode("supplier"); }}>＋ Add supplier</button>}{tab === "Invoices" && <button className="button button-primary" onClick={() => { setError(""); setMode("supplier-invoice"); }}>＋ Record supplier invoice</button>}</div></div>
    {!data ? <div className="panel loading-state">Loading purchasing workspace…</div> : <div className="panel data-panel"><div className="table-wrap">
      {tab === "Suppliers" && <table><thead><tr><th>SUPPLIER</th><th>EMAIL</th><th>PHONE</th><th>GST / VAT</th><th>STATUS</th>{canManageSuppliers && <th>ACTIONS</th>}</tr></thead><tbody>{data.suppliers.map((supplier) => <tr key={supplier.id}><td><div className="customer-cell"><span className="customer-avatar supplier-avatar">{supplier.name.slice(0, 1).toUpperCase()}</span><span>{supplier.name}</span></div></td><td>{supplier.email ?? "—"}</td><td>{supplier.phone ?? "—"}</td><td>{supplier.taxId ?? "—"}</td><td><span className={`badge ${supplier.active ? "badge-green" : "badge-neutral"}`}>{supplier.active ? "ACTIVE" : "ARCHIVED"}</span></td>{canManageSuppliers && <td><div className="row-actions"><button disabled={busy} onClick={() => { setEditingSupplier(supplier); setMode("supplier"); setError(""); }}>Edit</button><button disabled={busy} className={supplier.active ? "danger-action" : ""} onClick={() => void setSupplierActive(supplier)}>{supplier.active ? "Archive" : "Restore"}</button></div></td>}</tr>)}</tbody></table>}
      {tab === "Orders" && <table><thead><tr><th>PURCHASE ORDER</th><th>SUPPLIER</th><th>ITEMS</th><th>STATUS</th><th>ORDER TOTAL</th><th></th></tr></thead><tbody>{data.orders.map((order) => <tr key={order.id}><td><strong>{order.number}</strong><small className="table-subtext">{new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(order.createdAt))}</small></td><td>{order.supplier.name}</td><td>{order.lines.reduce((total, line) => total + line.quantity, 0)} units</td><td><span className={`badge ${order.status === "RECEIVED" ? "badge-green" : "badge-neutral"}`}>{order.status.replaceAll("_", " ")}</span></td><td>{money(order.total, order.currency)}</td><td><div className="row-actions">{order.status === "DRAFT" && <button disabled={busy} onClick={() => void send({ action: "approve-order", id: order.id })}>Approve</button>}{order.status === "APPROVED" && <button disabled={busy} onClick={() => void send({ action: "place-order", id: order.id })}>Mark ordered</button>}{["ORDERED", "PARTIALLY_RECEIVED"].includes(order.status) && <button disabled={busy} onClick={() => { setSelectedOrder(order); setMode("receive"); setError(""); }}>Receive goods</button>}{["DRAFT", "APPROVED", "ORDERED"].includes(order.status) && <button disabled={busy} className="danger-action" onClick={() => { if (window.confirm(`Cancel purchase order ${order.number}?`)) void send({ action: "cancel-order", id: order.id }); }}>Cancel</button>}</div></td></tr>)}</tbody></table>}
      {tab === "Invoices" && <table><thead><tr><th>SUPPLIER INVOICE</th><th>SUPPLIER</th><th>DUE DATE</th><th>AMOUNT</th><th>PAID</th><th>BALANCE</th><th>STATUS</th><th></th></tr></thead><tbody>{data.supplierInvoices.map((invoice) => { const balance = Math.max(0, Number(invoice.amount) - Number(invoice.paidAmount)); return <tr key={invoice.id}><td><strong>{invoice.number}</strong>{invoice.purchaseOrder && <small className="table-subtext">{invoice.purchaseOrder.number}</small>}</td><td>{invoice.supplier.name}</td><td>{invoice.dueDate ? new Intl.DateTimeFormat("en-IN", { dateStyle: "medium", timeZone: "UTC" }).format(new Date(invoice.dueDate)) : "—"}</td><td>{money(invoice.amount, invoice.currency)}</td><td>{money(invoice.paidAmount, invoice.currency)}</td><td><strong>{money(String(balance), invoice.currency)}</strong></td><td><span className={`badge ${invoice.status === "PAID" ? "badge-green" : "badge-neutral"}`}>{invoice.status.replaceAll("_", " ")}</span></td><td><div className="row-actions">{balance > 0 && <button onClick={() => { setSelectedInvoice(invoice); setMode("supplier-payment"); setError(""); }}>Record payment</button>}</div></td></tr>; })}</tbody></table>}
      {((tab === "Orders" && data.orders.length === 0) || (tab === "Suppliers" && data.suppliers.length === 0) || (tab === "Invoices" && data.supplierInvoices.length === 0)) && <div className="empty-state"><span className="empty-icon">B</span><strong>No {tab.toLowerCase()} yet</strong><span>Supplier bills and payments will appear in this workspace.</span>{tab === "Orders" && <button className="button button-secondary" onClick={() => setMode("order")}>Create purchase order</button>}{tab === "Suppliers" && canCreateSuppliers && <button className="button button-secondary" onClick={() => { setEditingSupplier(null); setMode("supplier"); }}>Add a supplier</button>}{tab === "Invoices" && <button className="button button-secondary" onClick={() => setMode("supplier-invoice")}>Record an invoice</button>}</div>}
    </div></div>}
    {mode && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) { setMode(null); setSelectedOrder(null); setSelectedInvoice(null); setEditingSupplier(null); } }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="purchase-modal-title"><div className="modal-heading"><div><div className="eyebrow">PURCHASING</div><h2 id="purchase-modal-title">{mode === "supplier" ? editingSupplier ? "Edit supplier" : "Add a supplier" : mode === "order" ? "Create purchase order" : mode === "receive" ? "Receive goods" : mode === "supplier-invoice" ? "Record supplier invoice" : "Record supplier payment"}</h2></div><button className="icon-button" aria-label="Close" onClick={() => { setMode(null); setSelectedOrder(null); setSelectedInvoice(null); setEditingSupplier(null); }}>×</button></div>
      {mode === "receive" && selectedOrder ? <form className="auth-form" onSubmit={submit}><p className="payment-context">{selectedOrder.number} · {selectedOrder.supplier.name}</p><label>Warehouse<select name="warehouseId" required>{data?.warehouses.map((warehouse) => <option key={warehouse.id} value={warehouse.id}>{warehouse.name}</option>)}</select></label>{selectedOrder.lines.map((line) => { const received = line.receipts.reduce((sum, receipt) => sum + receipt.quantity, 0); const remaining = line.quantity - received; return <label key={line.id}>{line.description}<small className="field-hint">{remaining} of {line.quantity} remaining</small><input name={line.id} type="number" min="0" max={remaining} step="1" defaultValue="0" /></label>; })}{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => { setMode(null); setSelectedOrder(null); }}>Cancel</button><button disabled={busy} className="button button-primary">{busy ? "Receiving…" : "Receive stock"}</button></div></form> : mode === "supplier-invoice" ? <form className="auth-form" onSubmit={submit}><label>Supplier<select name="supplierId" required>{activeSuppliers.map((supplier) => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}</select></label>{activeSuppliers.length === 0 && <div className="setup-hint">Add or restore a supplier before recording an invoice.</div>}<label>Supplier invoice number<input name="number" required maxLength={100} placeholder="INV-2026-001" /></label><div className="form-row"><label>Invoice amount<input name="amount" type="number" min="0.01" step="0.01" required /></label><label>Due date<input name="dueDate" type="date" /></label></div><label>Notes<input name="notes" placeholder="Optional note" /></label>{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => setMode(null)}>Cancel</button><button disabled={busy || activeSuppliers.length === 0} className="button button-primary">{busy ? "Saving…" : "Record invoice"}</button></div></form> : mode === "supplier-payment" && selectedInvoice ? <form className="auth-form" onSubmit={submit}><p className="payment-context">{selectedInvoice.supplier.name} · {selectedInvoice.number} · Balance {money(String(Number(selectedInvoice.amount) - Number(selectedInvoice.paidAmount)), selectedInvoice.currency)}</p><label>Payment amount<input name="amount" type="number" min="0.01" max={Number(selectedInvoice.amount) - Number(selectedInvoice.paidAmount)} step="0.01" required /></label><div className="form-row"><label>Payment method<select name="method"><option value="BANK_TRANSFER">Bank transfer</option><option value="UPI">UPI</option><option value="CASH">Cash</option><option value="CHEQUE">Cheque</option><option value="CARD">Card</option><option value="OTHER">Other</option></select></label><label>Reference<input name="reference" maxLength={100} placeholder="Optional reference" /></label></div>{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => { setMode(null); setSelectedInvoice(null); }}>Cancel</button><button disabled={busy} className="button button-primary">{busy ? "Saving…" : "Record payment"}</button></div></form> : <form className="auth-form" onSubmit={submit}>{mode === "supplier" ? <><label>Supplier name<input name="name" required minLength={2} defaultValue={editingSupplier?.name ?? ""} placeholder="Supplier company" /></label><div className="form-row"><label>Email<input name="email" type="email" defaultValue={editingSupplier?.email ?? ""} placeholder="accounts@supplier.com" /></label><label>Phone<input name="phone" type="tel" defaultValue={editingSupplier?.phone ?? ""} placeholder="+91 98765 43210" /></label></div><label>GST / VAT number<input name="taxId" defaultValue={editingSupplier?.taxId ?? ""} placeholder="Optional tax registration" /></label></> : <>{activeSuppliers.length ? <label>Supplier<select name="supplierId" required>{activeSuppliers.map((supplier) => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}</select></label> : <div className="setup-hint">Add or restore a supplier first, then you can place a purchase order.</div>}{data?.products.length ? <label>Product<select name="productId" required>{data.products.map((product) => <option key={product.id} value={product.id}>{product.name} · {product.sku}</option>)}</select></label> : <div className="setup-hint">Create a product before ordering stock.</div>}<div className="form-row"><label>Quantity<input name="quantity" type="number" min="1" step="1" defaultValue="1" required /></label><label>Unit cost<input name="unitCost" type="number" min="0" step="0.01" required placeholder="0.00" /></label></div><label>Tax rate (%)<input name="taxRate" type="number" min="0" max="100" step="0.01" defaultValue="0" /></label><label>Notes<input name="notes" placeholder="Optional supplier instructions" /></label></>}{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => { setMode(null); setEditingSupplier(null); }}>Cancel</button><button disabled={busy || (mode === "order" && (!activeSuppliers.length || !data.products.length))} className="button button-primary">{busy ? "Saving…" : mode === "supplier" ? editingSupplier ? "Save changes" : "Save supplier" : "Create purchase order"}</button></div></form>}
    </section></div>}
  </>;
}
