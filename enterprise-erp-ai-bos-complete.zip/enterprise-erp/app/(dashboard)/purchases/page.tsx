import PurchaseManager from "./purchase-manager";
import { requirePagePermission } from "@/lib/page-access";
import { hasPermission } from "@/lib/permissions";

export default async function PurchasesPage() {
  const user = await requirePagePermission("purchases.read");
  const canManageSuppliers = hasPermission(user.role, "purchases.update", user.organization.rolePermissions);
  const canCreateSuppliers = hasPermission(user.role, "purchases.create", user.organization.rolePermissions);
  return <><div className="page-heading"><div><div className="eyebrow">PROCUREMENT</div><h1>Purchases</h1><p>Manage suppliers, approve and place purchase orders, receive stock, and track supplier invoices and payments.</p></div></div><PurchaseManager canManageSuppliers={canManageSuppliers} canCreateSuppliers={canCreateSuppliers} /></>;
}
