"use client";

import { useCallback, useEffect, useState } from "react";

type RolePermissions = { role: string; permissions: string[] };
type PermissionData = { roles: RolePermissions[]; availablePermissions: string[] };
const roleLabels: Record<string, string> = { MANAGER: "Manager", ACCOUNTANT: "Accountant", HR: "HR", SALES: "Sales", INVENTORY_MANAGER: "Inventory manager", EMPLOYEE: "Employee" };
const sections: Record<string, string[]> = {
  Customers: ["customers.read", "customers.create", "customers.update", "customers.delete"],
  Products: ["products.read", "products.create", "products.update"],
  Inventory: ["inventory.read", "inventory.create"],
  Sales: ["sales.read", "sales.create", "sales.approve", "sales.fulfill"],
  Invoices: ["invoices.read", "invoices.create", "payments.read", "payments.create"],
  Purchasing: ["purchases.read", "purchases.create", "purchases.approve", "purchases.receive", "purchases.invoice", "purchases.pay"],
  Finance: ["finance.read", "finance.create", "reports.read"],
  People: ["employees.read", "employees.create", "attendance.self", "leave.create", "leave.approve", "payroll.create", "payroll.approve", "payroll.pay"],
  Workspace: ["audit.read", "notifications.read"],
};

export default function PermissionsManager() {
  const [data, setData] = useState<PermissionData | null>(null);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/permissions");
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to load permissions"); return; }
      setData(result);
    } catch { setError("Unable to reach the permissions service"); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  function toggle(role: string, permission: string) {
    setData((current) => current ? ({ ...current, roles: current.roles.map((item) => item.role !== role ? item : ({ ...item, permissions: item.permissions.includes(permission) ? item.permissions.filter((value) => value !== permission) : [...item.permissions, permission] })) }) : current);
    setMessage("");
  }

  async function save() {
    if (!data) return;
    setBusy(true); setError(""); setMessage("");
    try {
      const response = await fetch("/api/permissions", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ permissions: Object.fromEntries(data.roles.map((item) => [item.role, item.permissions])) }) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to save permissions"); return; }
      setData((current) => current ? { ...current, roles: result.roles } : current);
      setMessage("Role permissions saved.");
    } catch { setError("Unable to reach the permissions service"); }
    finally { setBusy(false); }
  }

  return <>
    {error && <div className="inline-error" role="alert">{error}</div>}
    {message && <p className="form-success" role="status">{message}</p>}
    {!data ? <div className="panel loading-state">Loading role permissions...</div> : <>
      <p className="permission-note">Administrator roles always retain full access. Changes apply to the selected roles across this workspace.</p>
      <div className="permission-role-list">{data.roles.map((role) => <section className="panel permission-role" key={role.role}><div className="panel-heading"><div><h2>{roleLabels[role.role] ?? role.role}</h2><p>{role.permissions.length} permissions enabled</p></div></div><div className="permission-sections">{Object.entries(sections).map(([section, permissions]) => <fieldset className="permission-section" key={section}><legend>{section}</legend><div className="permission-options">{permissions.filter((permission) => data.availablePermissions.includes(permission)).map((permission) => <label key={permission}><input type="checkbox" checked={role.permissions.includes(permission)} onChange={() => toggle(role.role, permission)} /><span>{permission.split(".")[1].replaceAll("_", " ")}</span></label>)}</div></fieldset>)}</div></section>)}</div>
      <div className="permission-save"><button className="button button-primary" disabled={busy} onClick={() => void save()}>{busy ? "Saving..." : "Save permissions"}</button></div>
    </>}
  </>;
}
