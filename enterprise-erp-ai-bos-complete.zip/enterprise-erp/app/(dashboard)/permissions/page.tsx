import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import PermissionsManager from "./permissions-manager";

export default async function PermissionsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!(["ADMIN", "SUPER_ADMIN"] as string[]).includes(user.role)) redirect("/dashboard");
  return <><div className="page-heading"><div><div className="eyebrow">WORKSPACE ACCESS</div><h1>Role permissions</h1><p>Choose what each team role can read or change in this workspace.</p></div></div><PermissionsManager /></>;
}
