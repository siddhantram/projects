import FinanceManager from "./finance-manager";
import { requirePagePermission } from "@/lib/page-access";
import { hasPermission } from "@/lib/permissions";

export default async function FinancePage() {
  const user = await requirePagePermission("finance.read");
  const canCreateFinanceRecords = hasPermission(user.role, "finance.create", user.organization.rolePermissions);
  return <><div className="page-heading"><div><div className="eyebrow">ACCOUNTING</div><h1>Finance</h1><p>Review posted revenue, cash flow, expenses, receivables and the general ledger.</p></div></div><FinanceManager canCreateFinanceRecords={canCreateFinanceRecords} /></>;
}
