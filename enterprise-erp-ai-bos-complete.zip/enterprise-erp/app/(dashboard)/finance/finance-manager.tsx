"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type Account = { id: string; code: string; name: string; type: string };
type AccountBalance = { id: string; code: string; name: string; type: string; balance: number };
type Expense = { id: string; category: string; description: string; vendor: string | null; amount: string; incurredAt: string; journalEntry: { number: string } };
type JournalLine = { debit: string; credit: string; account: { code: string; name: string; type: string } };
type Entry = { id: string; number: string; description: string; entryDate: string; lines: JournalLine[] };
type Ledger = { account: Account; from: string; to: string; openingBalance: number; closingBalance: number; transactions: { id: string; date: string; number: string; description: string; memo: string | null; debit: number; credit: number; balance: number }[] };
type FinanceBase = { accounts: Account[]; accountBalances: AccountBalance[]; incomeStatement: AccountBalance[]; period: { from: string; to: string; revenue: number; expenses: number; profit: number; cashMovement: number; accounts: AccountBalance[] }; balanceSheet: { assets: AccountBalance[]; liabilities: AccountBalance[]; equity: AccountBalance[]; currentEarnings: number; totalAssets: number; totalLiabilities: number; totalEquity: number; balanced: boolean }; cashPosition: number; expenses: Expense[]; entries: Entry[]; totals: { revenue: number; expenses: number; profit: number; receivables: number; payables: number; currency: string } };
type CashFlowLine = { accountId: string; code: string; name: string; amount: number };
type CashFlow = { from: string; to: string; operating: { accounts: CashFlowLine[]; total: number }; investing: { accounts: CashFlowLine[]; total: number }; financing: { accounts: CashFlowLine[]; total: number }; netChange: number };
type FinanceData = FinanceBase & { cashFlow: CashFlow };

export default function FinanceManager({ canCreateFinanceRecords }: { canCreateFinanceRecords: boolean }) {
  const [data, setData] = useState<FinanceData | null>(null);
  const [open, setOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [journalOpen, setJournalOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [ledger, setLedger] = useState<Ledger | null>(null);
  const [ledgerLoading, setLedgerLoading] = useState(false);
  const load = useCallback(async () => {
    try { const response = await fetch("/api/finance"); const result = await response.json(); if (response.ok) setData(result); else setError(result.error ?? "Unable to load finance records"); }
    catch { setError("Unable to load finance records"); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  const formatMoney = (amount: number | string) => data ? new Intl.NumberFormat("en-IN", { style: "currency", currency: data.totals.currency, maximumFractionDigits: 2 }).format(Number(amount)) : "—";

  async function saveExpense(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    try {
      const response = await fetch("/api/finance", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "expense", ...Object.fromEntries(new FormData(event.currentTarget).entries()) }) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to save expense"); return; }
      setOpen(false); setMessage("Expense recorded and journal entry posted."); await load();
    } catch { setError("Network error. Please try again."); }
    finally { setBusy(false); }
  }

  async function saveAccount(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    try {
      const response = await fetch("/api/finance", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "account", ...Object.fromEntries(new FormData(event.currentTarget).entries()) }) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to create account"); return; }
      setAccountOpen(false); setMessage("Account added to the chart of accounts."); await load();
    } catch { setError("Network error. Please try again."); }
    finally { setBusy(false); }
  }

  async function saveJournal(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    const values = Object.fromEntries(new FormData(event.currentTarget).entries());
    const amount = Number(values.amount);
    try {
      const response = await fetch("/api/finance", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "journal", description: values.description, lines: [{ accountId: values.debitAccountId, debit: amount, credit: 0, memo: values.description }, { accountId: values.creditAccountId, debit: 0, credit: amount, memo: values.description }] }) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to post journal entry"); return; }
      setJournalOpen(false); setMessage("Journal entry posted with matching debits and credits."); await load();
    } catch { setError("Network error. Please try again."); }
    finally { setBusy(false); }
  }

  async function loadPeriod(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError("");
    const values = new FormData(event.currentTarget);
    try {
      const response = await fetch(`/api/finance?from=${encodeURIComponent(String(values.get("from")))}&to=${encodeURIComponent(String(values.get("to")))}`);
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to load selected period"); return; }
      setData((current) => current ? { ...current, period: result.period, cashFlow: result.cashFlow } : current);
      setLedger(null);
    } catch { setError("Unable to load selected period"); }
  }

  function exportPeriodCsv() {
    if (!data) return;
    const rows = [
      ["Period finance report", `${data.period.from} to ${data.period.to}`],
      ["Account code", "Account name", "Type", `Amount (${data.totals.currency})`],
      ...data.period.accounts.map((account) => [account.code, account.name, account.type, Number(account.balance.toFixed(2))]),
      [],
      ["Summary", `Amount (${data.totals.currency})`],
      ["Revenue", Number(data.period.revenue.toFixed(2))],
      ["Expenses", Number(data.period.expenses.toFixed(2))],
      ["Net profit", Number(data.period.profit.toFixed(2))],
      ["Cash movement", Number(data.period.cashMovement.toFixed(2))],
      [],
      ["Classified cash flow", "Account code", "Account name", `Cash flow (${data.totals.currency})`],
      ...([ ["Operating", data.cashFlow.operating], ["Investing", data.cashFlow.investing], ["Financing", data.cashFlow.financing] ] as const).flatMap(([category, section]) => [
        ...section.accounts.map((account) => [category, account.code, account.name, Number(account.amount.toFixed(2))]),
        [category, "", "Section total", Number(section.total.toFixed(2))],
      ]),
      ["Net cash change", "", "", Number(data.cashFlow.netChange.toFixed(2))],
    ];
    const csv = rows.map((row) => row.map((cell) => {
      let value = String(cell ?? "");
      if (typeof cell === "string" && /^[\s\u0000-\u001f]*[=+@\-]/.test(value)) value = `'${value}`;
      return `"${value.replaceAll('"', '""')}"`;
    }).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `finance-${data.period.from}-to-${data.period.to}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  async function openLedger(account: AccountBalance) {
    if (ledger?.account.id === account.id) { setLedger(null); return; }
    if (!data) return;
    setLedgerLoading(true); setLedger(null); setError("");
    try {
      const response = await fetch(`/api/finance/accounts/${account.id}/ledger?from=${encodeURIComponent(data.period.from)}&to=${encodeURIComponent(data.period.to)}`);
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to load account ledger"); return; }
      setLedger(result);
    } catch { setError("Unable to load account ledger"); }
    finally { setLedgerLoading(false); }
  }

  function balanceRows(title: string, rows: AccountBalance[], total?: number) {
    return <div className="statement-block"><h3>{title}</h3>{rows.map((row) => <div className="statement-row" key={row.id}><span>{row.code} · {row.name}</span><strong>{formatMoney(row.balance)}</strong></div>)}{total !== undefined && <div className="statement-row statement-total"><strong>Total {title}</strong><strong>{formatMoney(total)}</strong></div>}</div>;
  }

  return <>
    {error && <div className="inline-error" role="alert">{error}</div>}{message && <p className="form-success sales-message" role="status">{message}</p>}
    {data ? <>
      <div className="section-label">FINANCIAL SNAPSHOT <span>Posted entries · life to date</span></div>
      <section className="stats-grid finance-stats">
        {[["Revenue", data.totals.revenue, "Customer invoices"], ["Expenses", data.totals.expenses, "Expense and COGS accounts"], ["Net profit", data.totals.profit, "Revenue less expenses"], ["Receivables", data.totals.receivables, "Customer invoices outstanding"], ["Payables", data.totals.payables, "Supplier invoices outstanding"]].map(([label, amount, note]) => <article className="stat-card" key={String(label)}><div className="stat-top"><span>{label}</span></div><div className="stat-value">{formatMoney(Number(amount))}</div><div className="stat-foot"><span className="stat-note">{note}</span></div></article>)}
      </section>
      <div className="finance-toolbar"><div><h2>Period report</h2><p>Profit and cash movement from posted journal entries.</p></div><button className="button button-secondary" onClick={exportPeriodCsv}>Export CSV</button></div>
      <section className="panel statement-panel">
        <form key={`${data.period.from}-${data.period.to}`} className="form-row" onSubmit={loadPeriod}>
          <label>From<input name="from" type="date" defaultValue={data.period.from} required /></label>
          <label>To<input name="to" type="date" defaultValue={data.period.to} required /></label>
          <button className="button button-primary">Apply dates</button>
        </form>
        <div className="stats-grid finance-stats">
          {[["Revenue", data.period.revenue], ["Expenses", data.period.expenses], ["Net profit", data.period.profit], ["Cash movement", data.period.cashMovement]].map(([label, amount]) => <article className="stat-card" key={String(label)}><div className="stat-top"><span>{label}</span></div><div className="stat-value">{formatMoney(Number(amount))}</div><div className="stat-foot"><span className="stat-note">{data.period.from} to {data.period.to}</span></div></article>)}
        </div>
      </section>
      <div className="finance-toolbar"><div><h2>Classified cash flow</h2><p>Operating includes income, expenses and working-capital accounts; other assets are investing, and remaining liabilities/equity are financing.</p></div><span className="badge badge-neutral">{data.cashFlow.from} to {data.cashFlow.to}</span></div>
      <section className="panel statement-panel cash-flow-panel">{([ ["Operating activities", data.cashFlow.operating], ["Investing activities", data.cashFlow.investing], ["Financing activities", data.cashFlow.financing] ] as const).map(([label, section]) => <div className="statement-block" key={label}><h3>{label}</h3>{section.accounts.map((account) => <div className="statement-row" key={account.accountId}><span>{account.code} · {account.name}</span><strong>{formatMoney(account.amount)}</strong></div>)}{!section.accounts.length && <div className="statement-row"><span>No classified cash movements</span><strong>{formatMoney(0)}</strong></div>}<div className="statement-row statement-total"><strong>Total {label.toLowerCase()}</strong><strong>{formatMoney(section.total)}</strong></div></div>)}<div className="statement-row statement-total"><strong>Net change in cash</strong><strong>{formatMoney(data.cashFlow.netChange)}</strong></div></section>
      <div className="finance-toolbar"><div><h2>Financial statements</h2><p>Balances are calculated from posted journal entries.</p></div><span className={`badge ${data.balanceSheet.balanced ? "badge-green" : "badge-neutral"}`}>{data.balanceSheet.balanced ? "Balanced" : "Review needed"}</span></div>
      <div className="statement-grid"><section className="panel statement-panel">{balanceRows("Income statement · life to date", data.incomeStatement)}<div className="statement-row statement-total"><strong>Net income</strong><strong>{formatMoney(data.totals.profit)}</strong></div></section><section className="panel statement-panel">{balanceRows("Assets", data.balanceSheet.assets, data.balanceSheet.totalAssets)}{balanceRows("Liabilities", data.balanceSheet.liabilities, data.balanceSheet.totalLiabilities)}{balanceRows("Equity", data.balanceSheet.equity)}<div className="statement-row"><span>Current earnings</span><strong>{formatMoney(data.balanceSheet.currentEarnings)}</strong></div><div className="statement-row statement-total"><strong>Total equity</strong><strong>{formatMoney(data.balanceSheet.totalEquity)}</strong></div><div className="statement-row statement-total"><strong>Cash and bank</strong><strong>{formatMoney(data.cashPosition)}</strong></div></section></div>
      <div className="finance-toolbar"><div><h2>Expenses</h2><p>Record a business expense and post its double-entry journal.</p></div>{canCreateFinanceRecords && <button className="button button-primary" onClick={() => { setError(""); setOpen(true); }}>Record expense</button>}</div>
      <section className="panel data-panel"><div className="table-wrap"><table><thead><tr><th>EXPENSE</th><th>CATEGORY</th><th>VENDOR</th><th>JOURNAL</th><th>DATE</th><th>AMOUNT</th></tr></thead><tbody>{data.expenses.map((expense) => <tr key={expense.id}><td><strong>{expense.description}</strong></td><td>{expense.category}</td><td>{expense.vendor ?? "—"}</td><td>{expense.journalEntry.number}</td><td>{new Intl.DateTimeFormat("en-IN", { dateStyle: "medium" }).format(new Date(expense.incurredAt))}</td><td>{formatMoney(expense.amount)}</td></tr>)}</tbody></table>{!data.expenses.length && <div className="empty-state"><strong>No expenses recorded</strong><span>Business expenses will appear here.</span></div>}</div></section>
      <div className="finance-toolbar"><div><h2>Recent journal entries</h2><p>Every posted record keeps debits and credits balanced.</p></div>{canCreateFinanceRecords && <button className="button button-primary" onClick={() => { setError(""); setJournalOpen(true); }}>Post journal entry</button>}</div>
      <section className="panel data-panel"><div className="table-wrap"><table><thead><tr><th>ENTRY</th><th>DESCRIPTION</th><th>DATE</th><th>LINES</th><th>TOTAL DEBIT</th></tr></thead><tbody>{data.entries.slice(0, 10).map((entry) => <tr key={entry.id}><td><strong>{entry.number}</strong></td><td>{entry.description}</td><td>{new Intl.DateTimeFormat("en-IN", { dateStyle: "medium" }).format(new Date(entry.entryDate))}</td><td>{entry.lines.length}</td><td>{formatMoney(entry.lines.reduce((sum, line) => sum + Number(line.debit), 0))}</td></tr>)}</tbody></table></div></section>
      <div className="finance-toolbar"><div><h2>Chart of accounts</h2><p>Select an account to inspect posted movements for the selected period.</p></div>{canCreateFinanceRecords && <button className="button button-secondary" onClick={() => { setError(""); setAccountOpen(true); }}>Add account</button>}</div><section className="panel account-grid">{data.accountBalances.map((account) => <div className="account-row" key={account.id}><span className="account-code">{account.code}</span><strong>{account.name}</strong><span className="movement-type">{account.type}</span><span className="account-balance">{formatMoney(account.balance)}</span><button disabled={ledgerLoading} className="text-link" onClick={() => void openLedger(account)} aria-expanded={ledger?.account.id === account.id}>Ledger</button></div>)}</section>
      {ledgerLoading && <section className="panel loading-state">Loading account ledger...</section>}
      {ledger && <><div className="finance-toolbar"><div><h2>{ledger.account.code} · {ledger.account.name}</h2><p>Posted account activity · {ledger.from} to {ledger.to}</p></div><button className="button button-secondary" onClick={() => setLedger(null)}>Close ledger</button></div><section className="panel data-panel"><div className="table-wrap"><table><thead><tr><th>DATE</th><th>ENTRY</th><th>DESCRIPTION</th><th>DEBIT</th><th>CREDIT</th><th>RUNNING BALANCE</th></tr></thead><tbody><tr><td colSpan={5}>Opening balance</td><td>{formatMoney(ledger.openingBalance)}</td></tr>{ledger.transactions.map((transaction) => <tr key={transaction.id}><td>{new Intl.DateTimeFormat("en-IN", { dateStyle: "medium", timeZone: "UTC" }).format(new Date(transaction.date))}</td><td>{transaction.number}</td><td>{transaction.memo ?? transaction.description}</td><td>{formatMoney(transaction.debit)}</td><td>{formatMoney(transaction.credit)}</td><td><strong>{formatMoney(transaction.balance)}</strong></td></tr>)}{!ledger.transactions.length && <tr><td colSpan={6}>No posted entries in this period.</td></tr>}</tbody><tfoot><tr><th colSpan={5}>Closing balance</th><th>{formatMoney(ledger.closingBalance)}</th></tr></tfoot></table></div></section></>}
    </> : <div className="panel loading-state">Loading finance workspace...</div>}
    {open && data && canCreateFinanceRecords && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setOpen(false); }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="expense-modal-title"><div className="modal-heading"><div><div className="eyebrow">EXPENSE MANAGEMENT</div><h2 id="expense-modal-title">Record an expense</h2></div><button className="icon-button" aria-label="Close" onClick={() => setOpen(false)}>X</button></div><form className="auth-form" onSubmit={saveExpense}><label>Description<input name="description" required minLength={3} placeholder="Monthly office rent" /></label><div className="form-row"><label>Category<input name="category" required minLength={2} placeholder="Rent, travel, utilities" /></label><label>Amount<input name="amount" type="number" min="0.01" step="0.01" required placeholder="0.00" /></label></div><label>Vendor<input name="vendor" placeholder="Optional payee" /></label><div className="form-row"><label>Expense account<select name="expenseAccountId" required>{data.accounts.filter((account) => account.type === "EXPENSE").map((account) => <option key={account.id} value={account.id}>{account.code} · {account.name}</option>)}</select></label><label>Paid from<select name="paymentAccountId" required>{data.accounts.filter((account) => account.code === "1000").map((account) => <option key={account.id} value={account.id}>{account.code} · {account.name}</option>)}</select></label></div><label>Date<input name="date" type="date" defaultValue={new Date().toISOString().slice(0, 10)} /></label>{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => setOpen(false)}>Cancel</button><button disabled={busy} className="button button-primary">{busy ? "Posting..." : "Save and post"}</button></div></form></section></div>}
    {accountOpen && canCreateFinanceRecords && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setAccountOpen(false); }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="account-modal-title"><div className="modal-heading"><div><div className="eyebrow">GENERAL LEDGER</div><h2 id="account-modal-title">Add chart of accounts entry</h2></div><button className="icon-button" aria-label="Close" onClick={() => setAccountOpen(false)}>X</button></div><form className="auth-form" onSubmit={saveAccount}><label>Account code<input name="code" inputMode="numeric" pattern="[0-9]{3,20}" minLength={3} maxLength={20} placeholder="e.g. 6100" required /></label><label>Account name<input name="name" minLength={2} maxLength={120} placeholder="e.g. Office supplies" required /></label><label>Account type<select name="type" defaultValue="EXPENSE"><option value="ASSET">Asset</option><option value="LIABILITY">Liability</option><option value="EQUITY">Equity</option><option value="REVENUE">Revenue</option><option value="EXPENSE">Expense</option></select></label><p className="field-hint">Account codes must be unique within this workspace. Posted accounting entries are retained permanently.</p>{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => setAccountOpen(false)}>Cancel</button><button disabled={busy} className="button button-primary">{busy ? "Saving..." : "Add account"}</button></div></form></section></div>}
    {journalOpen && data && canCreateFinanceRecords && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setJournalOpen(false); }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="journal-modal-title"><div className="modal-heading"><div><div className="eyebrow">GENERAL LEDGER</div><h2 id="journal-modal-title">Post a journal entry</h2></div><button className="icon-button" aria-label="Close" onClick={() => setJournalOpen(false)}>X</button></div><form className="auth-form" onSubmit={saveJournal}><label>Description<input name="description" required minLength={3} maxLength={300} placeholder="Opening adjustment" /></label><div className="form-row"><label>Debit account<select name="debitAccountId" required defaultValue=""><option value="" disabled>Select account</option>{data.accounts.map((account) => <option key={account.id} value={account.id}>{account.code} · {account.name}</option>)}</select></label><label>Credit account<select name="creditAccountId" required defaultValue=""><option value="" disabled>Select account</option>{data.accounts.map((account) => <option key={account.id} value={account.id}>{account.code} · {account.name}</option>)}</select></label></div><label>Amount<input name="amount" type="number" min="0.01" step="0.01" required placeholder="0.00" /></label><p className="field-hint">The amount will be recorded as an equal debit and credit. Choose two different accounts.</p>{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => setJournalOpen(false)}>Cancel</button><button disabled={busy || data.accounts.length < 2} className="button button-primary">{busy ? "Posting..." : "Post entry"}</button></div></form></section></div>}
  </>;
}

