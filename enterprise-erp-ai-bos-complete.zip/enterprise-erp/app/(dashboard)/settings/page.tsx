import SettingsForm from "./settings-form";
import { requirePageUser } from "@/lib/page-access";

export default async function SettingsPage() {
  const user = await requirePageUser();
  const canManageWorkspace = user.role === "ADMIN" || user.role === "SUPER_ADMIN";
  return <><div className="page-heading"><div><div className="eyebrow">WORKSPACE</div><h1>Settings</h1><p>Manage your account security{canManageWorkspace ? " and workspace details" : ""}.</p></div></div><SettingsForm canManageWorkspace={canManageWorkspace} /></>;
}
