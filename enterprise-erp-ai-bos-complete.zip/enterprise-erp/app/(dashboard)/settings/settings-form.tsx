"use client";

import { FormEvent, useEffect, useState } from "react";
import MfaSettings from "./mfa-settings";

type Settings = { name: string; address: string | null; taxId: string | null; currency: string; timezone: string };
const currencies = ["INR", "USD", "EUR", "GBP", "AED", "CAD", "AUD", "SGD"];
const zones = ["Asia/Kolkata", "Asia/Dubai", "Asia/Singapore", "Europe/London", "Europe/Paris", "America/New_York", "America/Los_Angeles", "Australia/Sydney", "UTC"];

export default function SettingsForm({ canManageWorkspace }: { canManageWorkspace: boolean }) {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [passwordMessage, setPasswordMessage] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [passwordBusy, setPasswordBusy] = useState(false);

  useEffect(() => { if (canManageWorkspace) void fetch("/api/organization").then(async (response) => { const result = await response.json(); if (response.ok) setSettings(result.organization); else setError(result.error ?? "Unable to load settings"); }).catch(() => setError("Unable to load settings")); }, [canManageWorkspace]);

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!settings) return; setBusy(true); setError(""); setMessage("");
    try {
      const response = await fetch("/api/organization", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.fromEntries(new FormData(event.currentTarget).entries())) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to save settings"); return; }
      setSettings(result.organization); setMessage("Workspace settings saved.");
    } catch { setError("Network error. Please try again."); }
    finally { setBusy(false); }
  }

  async function changePassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setPasswordBusy(true); setPasswordError(""); setPasswordMessage("");
    const form = event.currentTarget;
    const values = new FormData(form);
    if (values.get("newPassword") !== values.get("confirmPassword")) { setPasswordError("New password and confirmation do not match"); setPasswordBusy(false); return; }
    try {
      const response = await fetch("/api/auth/password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ currentPassword: values.get("currentPassword"), newPassword: values.get("newPassword") }) });
      const result = await response.json();
      if (!response.ok) { setPasswordError(result.error ?? "Unable to change password"); return; }
      form.reset(); setPasswordMessage(result.message ?? "Password updated.");
    } catch { setPasswordError("Network error. Please try again."); }
    finally { setPasswordBusy(false); }
  }

  if (canManageWorkspace && !settings) return <div className="panel loading-state">Loading workspace settings...</div>;
  return <>
    {canManageWorkspace && settings && <form onSubmit={save} className="settings-layout">
      <section className="panel settings-panel"><div className="panel-heading"><div><h2>Company profile</h2><p>Organization details used across your workspace.</p></div></div><div className="settings-fields">
        <label>Company name<input name="name" required minLength={2} maxLength={120} defaultValue={settings.name} /></label>
        <label>Business address<textarea name="address" rows={3} maxLength={400} defaultValue={settings.address ?? ""} placeholder="Street, city, postal code" /></label>
        <label>GST / VAT number<input name="taxId" maxLength={40} defaultValue={settings.taxId ?? ""} placeholder="Optional tax registration" /></label>
        <div className="form-row"><label>Base currency<select name="currency" defaultValue={settings.currency}>{currencies.map((currency) => <option key={currency}>{currency}</option>)}</select></label><label>Timezone<select name="timezone" defaultValue={settings.timezone}>{zones.map((zone) => <option key={zone}>{zone}</option>)}</select></label></div>
        {error && <p className="form-error" role="alert">{error}</p>}{message && <p className="form-success" role="status">{message}</p>}
        <div className="settings-actions"><button disabled={busy} className="button button-primary">{busy ? "Saving..." : "Save changes"}</button></div>
      </div></section>
      <aside className="settings-aside"><div className="panel settings-note"><span className="stat-icon blue">♧</span><h3>Organization data stays private</h3><p>Every customer, product and inventory record is tied to this workspace. Team members only see data from their organization.</p></div></aside>
    </form>}
    <section className="panel settings-panel"><div className="panel-heading"><div><h2>Change your password</h2><p>Confirm your current password. Other active sessions will be signed out.</p></div></div>
      <form onSubmit={changePassword} className="settings-fields"><label>Current password<input name="currentPassword" type="password" autoComplete="current-password" required /></label><div className="form-row"><label>New password<input name="newPassword" type="password" minLength={12} maxLength={200} autoComplete="new-password" required /></label><label>Confirm new password<input name="confirmPassword" type="password" minLength={12} maxLength={200} autoComplete="new-password" required /></label></div>
        {passwordError && <p className="form-error" role="alert">{passwordError}</p>}{passwordMessage && <p className="form-success" role="status">{passwordMessage}</p>}
        <div className="settings-actions"><button disabled={passwordBusy} className="button button-primary">{passwordBusy ? "Updating..." : "Update password"}</button></div>
      </form>
    </section>
    <MfaSettings />
  </>;
}
