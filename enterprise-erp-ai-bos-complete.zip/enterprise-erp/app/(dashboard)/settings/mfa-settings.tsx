"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type MfaStatus = { enabled: boolean; recoveryCodesRemaining: number };
type Setup = { secret: string; otpauthUrl: string };

export default function MfaSettings() {
  const [status, setStatus] = useState<MfaStatus | null>(null);
  const [setup, setSetup] = useState<Setup | null>(null);
  const [recoveryCodes, setRecoveryCodes] = useState<string[]>([]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    const response = await fetch("/api/auth/mfa");
    const result = await response.json();
    if (!response.ok) throw new Error(result.error ?? "Unable to load MFA settings");
    setStatus(result);
  }, []);

  useEffect(() => { void refresh().catch((caught) => setError(caught instanceof Error ? caught.message : "Unable to load MFA settings")); }, [refresh]);

  async function request(path: string, method: string, payload: Record<string, string>) {
    const response = await fetch(path, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error ?? "Unable to update MFA");
    return result;
  }

  async function startSetup(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    const password = new FormData(event.currentTarget).get("password")?.toString() ?? "";
    try { setSetup(await request("/api/auth/mfa", "POST", { password })); }
    catch (caught) { setError(caught instanceof Error ? caught.message : "Unable to start MFA setup"); }
    finally { setBusy(false); }
  }

  async function confirmSetup(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    const code = new FormData(event.currentTarget).get("code")?.toString() ?? "";
    try {
      const result = await request("/api/auth/mfa/confirm", "POST", { code });
      setRecoveryCodes(result.recoveryCodes); setSetup(null); setMessage(result.message); await refresh();
    } catch (caught) { setError(caught instanceof Error ? caught.message : "Unable to confirm MFA setup"); }
    finally { setBusy(false); }
  }

  async function disable(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    const form = event.currentTarget;
    const values = new FormData(form);
    try {
      const result = await request("/api/auth/mfa", "DELETE", { password: values.get("password")?.toString() ?? "", code: values.get("code")?.toString() ?? "" });
      form.reset(); setMessage(result.message); setRecoveryCodes([]); await refresh();
    } catch (caught) { setError(caught instanceof Error ? caught.message : "Unable to disable MFA"); }
    finally { setBusy(false); }
  }

  return <section className="panel settings-panel"><div className="panel-heading"><div><h2>Multi-factor authentication</h2><p>Protect sign-in with a TOTP authenticator app and one-time recovery codes.</p></div></div><div className="settings-fields">
    {status === null ? <p>Loading MFA settings…</p> : status.enabled ? <>
      <p className="form-success" role="status">MFA is enabled. {status.recoveryCodesRemaining} recovery codes remain.</p>
      <form onSubmit={disable} className="auth-form"><label>Current password<input name="password" type="password" required autoComplete="current-password" /></label><label>Authenticator or recovery code<input name="code" required autoComplete="one-time-code" /></label><div className="settings-actions"><button disabled={busy} className="button button-secondary">{busy ? "Updating…" : "Disable MFA"}</button></div></form>
    </> : setup ? <>
      <p>Add this account to your authenticator app with the secret or URI below, then enter its current six-digit code.</p>
      <label>Setup key<input readOnly value={setup.secret} /></label>
      <label>Authenticator URI<input readOnly value={setup.otpauthUrl} /></label>
      <form onSubmit={confirmSetup} className="auth-form"><label>Six-digit authenticator code<input name="code" inputMode="numeric" pattern="[0-9]{6}" minLength={6} maxLength={6} required autoComplete="one-time-code" /></label><div className="settings-actions"><button disabled={busy} className="button button-primary">{busy ? "Confirming…" : "Confirm and enable MFA"}</button></div></form>
    </> : <form onSubmit={startSetup} className="auth-form"><p>MFA is disabled. Confirm your password to begin setup.</p><label>Current password<input name="password" type="password" required autoComplete="current-password" /></label><div className="settings-actions"><button disabled={busy} className="button button-primary">{busy ? "Starting…" : "Set up MFA"}</button></div></form>}
    {recoveryCodes.length > 0 && <div className="setup-hint" role="alert"><strong>Save these recovery codes now. They will not be shown again.</strong><ul>{recoveryCodes.map((code) => <li key={code}><code>{code}</code></li>)}</ul></div>}
    {error && <p className="form-error" role="alert">{error}</p>}{message && <p className="form-success" role="status">{message}</p>}
  </div></section>;
}
