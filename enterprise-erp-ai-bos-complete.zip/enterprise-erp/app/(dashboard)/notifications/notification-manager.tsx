"use client";

import { useCallback, useEffect, useState } from "react";

type Notification = { id: string; title: string; message: string; href: string | null; readAt: string | null; createdAt: string };

export default function NotificationManager() {
  const [items, setItems] = useState<Notification[]>([]);
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/notifications");
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Unable to load notifications");
      setItems(result.notifications);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Unable to load notifications"); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  async function markRead(id?: string) {
    setError("");
    try {
      const response = await fetch("/api/notifications", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(id ? { id } : { action: "read-all" }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Unable to update notifications");
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Unable to update notifications"); }
  }

  return <>
    {error && <div className="inline-error" role="alert">{error}</div>}
    <div className="toolbar"><span className="result-count">{items.filter((item) => !item.readAt).length} unread</span><button className="button button-secondary" onClick={() => void markRead()}>Mark all as read</button></div>
    <section className="panel notification-list">{items.length ? items.map((item) => <article key={item.id} className={item.readAt ? "notification-row read" : "notification-row"}><span className="notification-dot" /><div className="notification-copy"><strong>{item.title}</strong><p>{item.message}</p><time>{new Intl.DateTimeFormat("en-IN", { dateStyle: "medium", timeStyle: "short" }).format(new Date(item.createdAt))}</time></div><div className="notification-actions">{item.href && <a className="text-link" href={item.href}>Open</a>}{!item.readAt && <button onClick={() => void markRead(item.id)}>Mark read</button>}</div></article>) : <div className="empty-state"><span className="empty-icon">i</span><strong>You&apos;re all caught up</strong><span>New workspace updates will appear here.</span></div>}</section>
  </>;
}
