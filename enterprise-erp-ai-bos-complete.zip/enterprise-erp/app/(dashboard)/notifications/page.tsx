import NotificationManager from "./notification-manager";
import { requirePagePermission } from "@/lib/page-access";

export default async function NotificationsPage() {
  await requirePagePermission("notifications.read");
  return <><div className="page-heading"><div><div className="eyebrow">WORKSPACE UPDATES</div><h1>Notifications</h1><p>Review updates and mark completed items as read.</p></div></div><NotificationManager /></>;
}
