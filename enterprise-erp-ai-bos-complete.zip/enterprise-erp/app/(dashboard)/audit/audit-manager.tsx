"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

const actions = ["CREATE", "UPDATE", "DELETE", "LOGIN", "LOGOUT", "APPROVE", "REJECT", "EXPORT"] as const;
type AuditRow = { id: string; createdAt: string; action: typeof actions[number]; entity: string; entityId: string | null; user: { name: string; email: string } | null };
type AuditResult = { logs: AuditRow[]; total: number; page: number; pageSize: number; totalPages: number };
type Filters = { from: string; to: string; action: string; entity: string };

export default function AuditManager() {
  const [result, setResult] = useState<AuditResult | null>(null);
  const [filters, setFilters] = useState<Filters>({ from: "", to: "", action: "", entity: "" });
  const [appliedFilters, setAppliedFilters] = useState<Filters>({ from: "", to: "", action: "", entity: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async (selectedFilters: Filters, page: number) => {
    setBusy(true); setError("");
    try {
      const query = new URLSearchParams({ page: String(page) });
      if (selectedFilters.from) query.set("from", selectedFilters.from);
      if (selectedFilters.to) query.set("to", selectedFilters.to);
      if (selectedFilters.action) query.set("action", selectedFilters.action);
      if (selectedFilters.entity.trim()) query.set("entity", selectedFilters.entity.trim());
      const response = await fetch(`/api/audit?${query}`);
      const payload = await response.json();
      if (!response.ok) { setError(payload.error ?? "Unable to load audit history"); return; }
      setResult(payload);
    } catch { setError("Unable to load audit history"); }
    finally { setBusy(false); }
  }, []);
  useEffect(() => { void load({ from: "", to: "", action: "", entity: "" }, 1); }, [load]);

  async function apply(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setAppliedFilters(filters); await load(filters, 1);
  }

  function exportCsv() {
    if (!result) return;
    const rows: (string | number)[][] = [["Timestamp", "User", "Email", "Action", "Record type", "Record ID"], ...result.logs.map((log) => [log.createdAt, log.user?.name ?? "System", log.user?.email ?? "", log.action, log.entity, log.entityId ?? ""])];
    const csv = rows.map((row) => row.map((value) => {
      let cell = String(value);
      if (typeof value === "string" && /^[\s\u0000-\u001f]*[=+@-]/.test(cell)) cell = `'${cell}`;
      return `"${cell.replaceAll('"', '""')}"`;
    }).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a"); link.href = url; link.download = `audit-page-${result.page}-${new Date().toISOString().slice(0, 10)}.csv`; link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  return <>
    {error && <div className="inline-error" role="alert">{error}</div>}
    <form className="panel audit-filters" onSubmit={apply}>
      <label>From<input type="date" value={filters.from} onChange={(event) => setFilters((current) => ({ ...current, from: event.target.value }))} /></label>
      <label>To<input type="date" value={filters.to} onChange={(event) => setFilters((current) => ({ ...current, to: event.target.value }))} /></label>
      <label>Action<select value={filters.action} onChange={(event) => setFilters((current) => ({ ...current, action: event.target.value }))}><option value="">All actions</option>{actions.map((action) => <option key={action} value={action}>{action}</option>)}</select></label>
      <label>Record type<input value={filters.entity} maxLength={100} onChange={(event) => setFilters((current) => ({ ...current, entity: event.target.value }))} placeholder="e.g. Invoice" /></label>
      <div className="audit-filter-actions"><button disabled={busy} className="button button-primary">Apply filters</button><button type="button" disabled={busy} className="button button-secondary" onClick={() => { const reset = { from: "", to: "", action: "", entity: "" }; setFilters(reset); setAppliedFilters(reset); void load(reset, 1); }}>Clear</button></div>
    </form>
    <div className="toolbar"><span className="result-count">{result ? `${result.total} matching audit records` : "Loading audit history..."}</span><div className="toolbar-right"><button disabled={!result?.logs.length} className="button button-secondary" onClick={exportCsv}>Export this page CSV</button>{result && <><button disabled={busy || result.page <= 1} className="button button-secondary button-small" onClick={() => void load(appliedFilters, result.page - 1)}>Previous</button><span className="result-count">Page {result.page} of {result.totalPages}</span><button disabled={busy || result.page >= result.totalPages} className="button button-secondary button-small" onClick={() => void load(appliedFilters, result.page + 1)}>Next</button></>}</div></div>
    <section className="panel data-panel"><div className="table-wrap"><table><thead><tr><th>WHEN</th><th>USER</th><th>ACTION</th><th>RECORD</th><th>RECORD ID</th></tr></thead><tbody>{result?.logs.map((log) => <tr key={log.id}><td>{new Intl.DateTimeFormat("en-IN", { dateStyle: "medium", timeStyle: "short" }).format(new Date(log.createdAt))}</td><td>{log.user?.name ?? "System"}<small className="table-subtext">{log.user?.email ?? ""}</small></td><td><span className="movement-type">{log.action}</span></td><td>{log.entity}</td><td>{log.entityId ?? "—"}</td></tr>)}</tbody></table>{result && !result.logs.length && <div className="empty-state"><strong>No audit records found</strong><span>Try changing the filters.</span></div>}</div></section>
  </>;
}
