import { requirePagePermission } from "@/lib/page-access";
import AuditManager from "./audit-manager";

export default async function AuditPage() {
  await requirePagePermission("audit.read");
  return <><div className="page-heading"><div><div className="eyebrow">SECURITY</div><h1>Audit history</h1><p>Filter and export recent account and business record changes in this workspace.</p></div></div><AuditManager /></>;
}
