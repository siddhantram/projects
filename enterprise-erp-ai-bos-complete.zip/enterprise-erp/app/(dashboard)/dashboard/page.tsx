import Link from "next/link";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { hasPermission, type Permission } from "@/lib/permissions";

function number(value: number) { return new Intl.NumberFormat("en-IN").format(value); }

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) return null;
  const isAdmin = user.role === "ADMIN" || user.role === "SUPER_ADMIN";
  if (!isAdmin) {
    const modules: { href: string; label: string; permission?: Permission; anyPermission?: Permission[] }[] = [
      { href: "/customers", label: "Customers", permission: "customers.read" },
      { href: "/products", label: "Products", permission: "products.read" },
      { href: "/inventory", label: "Inventory", permission: "inventory.read" },
      { href: "/sales", label: "Sales", permission: "sales.read" },
      { href: "/purchases", label: "Purchases", permission: "purchases.read" },
      { href: "/finance", label: "Finance", permission: "finance.read" },
      { href: "/analytics", label: "Reports", permission: "reports.read" },
      { href: "/hr", label: "People", anyPermission: ["employees.read", "attendance.self", "attendance.read", "leave.create", "leave.read", "leave.approve", "payroll.read"] },
      { href: "/notifications", label: "Notifications", permission: "notifications.read" },
      { href: "/settings", label: "Settings" },
    ];
    const available = modules.filter((module) => (!module.permission || hasPermission(user.role, module.permission, user.organization.rolePermissions)) && (!module.anyPermission || module.anyPermission.some((permission) => hasPermission(user.role, permission, user.organization.rolePermissions))));
    return <><div className="page-heading"><div><div className="eyebrow">WORKSPACE</div><h1>Good to see you, {user.name.split(" ")[0]}</h1><p>Open a workspace area available to your role.</p></div><div className="heading-date">{new Intl.DateTimeFormat("en-IN", { dateStyle: "full", timeZone: user.organization.timezone }).format(new Date())}</div></div><section className="panel"><div className="panel-heading"><div><h2>Your workspace</h2><p>Available areas are based on your assigned permissions.</p></div></div><div className="warehouse-list">{available.map((module) => <Link className="warehouse-row text-link" href={module.href} key={module.href}>{module.label}<span>Open</span></Link>)}</div></section></>;
  }
  const org = user.organizationId;
  const [customers, products, warehouses, movements, recentCustomers, lowStockProducts] = await Promise.all([
    db.customer.count({ where: { organizationId: org } }),
    db.product.count({ where: { organizationId: org, active: true } }),
    db.warehouse.count({ where: { organizationId: org } }),
    db.stockMovement.aggregate({ where: { organizationId: org }, _sum: { quantity: true } }),
    db.customer.findMany({ where: { organizationId: org, active: true }, orderBy: { createdAt: "desc" }, take: 5 }),
    db.product.findMany({ where: { organizationId: org, active: true }, include: { movements: { where: { organizationId: org }, select: { quantity: true } } }, take: 100 }),
  ]);
  const lowStock = lowStockProducts.map((product) => ({ ...product, stock: product.movements.reduce((sum, movement) => sum + movement.quantity, 0) })).filter((product) => product.stock <= product.reorderLevel).slice(0, 4);
  const complete = [customers > 0, products > 0, warehouses > 0].filter(Boolean).length;

  return <>
    <div className="page-heading"><div><div className="eyebrow">OVERVIEW</div><h1>Good to see you, {user.name.split(" ")[0]}</h1><p>Here&apos;s what&apos;s happening across {user.organization.name} today.</p></div><div className="heading-date">{new Intl.DateTimeFormat("en-IN", { dateStyle: "full", timeZone: user.organization.timezone }).format(new Date())}</div></div>
    {complete < 3 && <section className="setup-banner"><div className="setup-icon">✳</div><div className="setup-copy"><strong>Your workspace is ready to set up</strong><span>Add your first records to start seeing activity across your business.</span><div className="setup-progress"><span style={{ width: `${complete / 3 * 100}%` }} /></div></div><span className="setup-count">{complete}/3 complete</span><Link className="text-link" href="/settings">Configure workspace →</Link></section>}
    <div className="section-label">BUSINESS SNAPSHOT <span>Live data</span></div>
    <section className="stats-grid">
      <article className="stat-card"><div className="stat-top"><span>Total customers</span><span className="stat-icon violet">◉</span></div><div className="stat-value">{number(customers)}</div><div className="stat-foot"><span className="stat-note">In your workspace</span><Link href="/customers">View customers →</Link></div><div className="sparkline spark-violet"><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/></div></article>
      <article className="stat-card"><div className="stat-top"><span>Active products</span><span className="stat-icon blue">▧</span></div><div className="stat-value">{number(products)}</div><div className="stat-foot"><span className="stat-note">Across {number(warehouses)} warehouses</span><Link href="/products">View products →</Link></div><div className="sparkline spark-blue"><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/></div></article>
      <article className="stat-card"><div className="stat-top"><span>Units in stock</span><span className="stat-icon green">▤</span></div><div className="stat-value">{number(movements._sum.quantity ?? 0)}</div><div className="stat-foot"><span className="stat-note">Net movement balance</span><Link href="/inventory">Open inventory →</Link></div><div className="sparkline spark-green"><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/></div></article>
      <article className="stat-card"><div className="stat-top"><span>Low stock alerts</span><span className="stat-icon amber">⌁</span></div><div className="stat-value">{number(lowStock.length)}</div><div className="stat-foot"><span className="stat-note">At or below reorder level</span><Link href="/inventory">Review stock →</Link></div><div className="sparkline spark-amber"><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/></div></article>
    </section>
    <section className="dashboard-lower">
      <article className="panel activity-panel"><div className="panel-heading"><div><h2>Recent customers</h2><p>Your latest customer records</p></div><Link className="subtle-link" href="/customers">View all <span>→</span></Link></div>
        {recentCustomers.length ? <div className="table-wrap"><table><thead><tr><th>CUSTOMER</th><th>COMPANY</th><th>ADDED</th><th>STATUS</th></tr></thead><tbody>{recentCustomers.map((customer) => <tr key={customer.id}><td><div className="customer-cell"><span className="customer-avatar">{customer.name.slice(0, 1).toUpperCase()}</span><span>{customer.name}<small>{customer.email ?? "No email"}</small></span></div></td><td>{customer.company ?? "—"}</td><td>{new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "short" }).format(customer.createdAt)}</td><td><span className="badge badge-green">Active</span></td></tr>)}</tbody></table></div> : <div className="empty-state"><span className="empty-icon">◉</span><strong>No customers yet</strong><span>Your customer directory will appear here.</span><Link className="button button-secondary" href="/customers">Add your first customer</Link></div>}
      </article>
      <article className="panel stock-panel"><div className="panel-heading"><div><h2>Stock watch</h2><p>Products that need attention</p></div><Link className="subtle-link" href="/inventory">Inventory <span>→</span></Link></div>
        {lowStock.length ? <div className="stock-list">{lowStock.map((product) => <div className="stock-row" key={product.id}><div className="product-thumb">▧</div><div className="stock-product">{product.name}<small>{product.sku}</small></div><div className="stock-quantity"><strong>{product.stock}</strong><small>of {product.reorderLevel} min</small></div></div>)}</div> : <div className="empty-state compact"><span className="empty-icon success">✓</span><strong>Stock looks healthy</strong><span>No products are below their reorder level.</span></div>}
      </article>
    </section>
  </>;
}
