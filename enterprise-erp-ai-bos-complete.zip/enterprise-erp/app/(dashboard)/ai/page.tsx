import AIAssistant from "./assistant";
export default function AIPage(){ return <AIAssistant/>; }
