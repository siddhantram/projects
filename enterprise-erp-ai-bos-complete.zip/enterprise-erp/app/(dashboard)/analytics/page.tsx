import AnalyticsManager from "./analytics-manager";
import { requirePagePermission } from "@/lib/page-access";

export default async function AnalyticsPage() {
  await requirePagePermission("reports.read");
  return <><div className="page-heading"><div><div className="eyebrow">BUSINESS INTELLIGENCE</div><h1>Analytics and reports</h1><p>Monthly financial activity, invoice exposure and inventory alerts.</p></div></div><AnalyticsManager /></>;
}
