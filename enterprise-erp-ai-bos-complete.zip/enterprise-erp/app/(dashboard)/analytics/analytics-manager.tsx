"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type Analytics = { period: { from: string; to: string }; months: { month: string; label: string; revenue: number; expenses: number }[]; invoiceStatuses: { status: string; count: number; total: number; paid: number }[]; activity: { customersAdded: number; salesOrdersCreated: number }; lowStockCount: number; lowStock: { id: string; name: string; sku: string; stock: number; reorderLevel: number }[]; currency: string };

export default function AnalyticsManager() {
  const [data, setData] = useState<Analytics | null>(null);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [error, setError] = useState("");
  const load = useCallback(async (fromValue?: string, toValue?: string) => {
    try {
      const query = fromValue && toValue ? `?from=${encodeURIComponent(fromValue)}&to=${encodeURIComponent(toValue)}` : "";
      const response = await fetch(`/api/analytics${query}`); const result = await response.json();
      if (response.ok) { setData(result); setFrom(result.period.from); setTo(result.period.to); }
      else setError(result.error ?? "Unable to load reports");
    }
    catch { setError("Unable to load reports"); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  async function applyPeriod(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(""); await load(from, to);
  }
  const money = (value: number) => data ? new Intl.NumberFormat("en-IN", { style: "currency", currency: data.currency, maximumFractionDigits: 0 }).format(value) : "—";
  if (!data) return <>{error && <div className="inline-error" role="alert">{error}</div>}<div className="panel loading-state">Loading analytics…</div></>;
  function exportCsv() {
    const rows: (string | number)[][] = [
      ["Report", "Period / reference", "Metric / product", "Value / stock", "Reorder level"],
      ["Low stock", data.period.to, "Products at or below reorder level (total)", data.lowStockCount],
      ...data.months.flatMap((month) => [["Monthly finance", month.month, "Revenue", month.revenue], ["Monthly finance", month.month, "Expenses", month.expenses]]),
      ...data.invoiceStatuses.flatMap((item) => [["Invoice status", item.status, "Count", item.count], ["Invoice status", item.status, "Invoiced", item.total], ["Invoice status", item.status, "Paid", item.paid], ["Invoice status", item.status, "Outstanding", Math.max(0, item.total - item.paid)]]),
      ...data.lowStock.map((item) => ["Low stock", item.sku, item.name, item.stock, item.reorderLevel]),
    ];
    const csv = rows.map((row) => [...row, ...Array(Math.max(0, 5 - row.length)).fill("")].map((value) => {
      let cell = String(value);
      if (typeof value === "string" && /^[\s\u0000-\u001f]*[=+@-]/.test(cell)) cell = `'${cell}`;
      return `"${cell.replaceAll('"', '""')}"`;
    }).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `enterprise-erp-report-${data.period.from}-to-${data.period.to}.csv`;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  const max = Math.max(1, ...data.months.flatMap((month) => [month.revenue, month.expenses]));
  return <>
    {error && <div className="inline-error" role="alert">{error}</div>}
    <section className="stats-grid"><article className="stat-card"><div className="stat-top"><span>Customers added</span><span className="stat-icon blue">C</span></div><div className="stat-value">{data.activity.customersAdded}</div><div className="stat-foot"><span className="stat-note">Selected period</span></div></article><article className="stat-card"><div className="stat-top"><span>Sales orders</span><span className="stat-icon violet">S</span></div><div className="stat-value">{data.activity.salesOrdersCreated}</div><div className="stat-foot"><span className="stat-note">Selected period</span></div></article><article className="stat-card"><div className="stat-top"><span>Open invoices</span><span className="stat-icon amber">I</span></div><div className="stat-value">{data.invoiceStatuses.filter((item) => ["SENT", "PARTIALLY_PAID", "OVERDUE"].includes(item.status)).reduce((sum, item) => sum + item.count, 0)}</div><div className="stat-foot"><span className="stat-note">Issued in selected period</span></div></article><article className="stat-card"><div className="stat-top"><span>Low stock products</span><span className="stat-icon amber">!</span></div><div className="stat-value">{data.lowStockCount}</div><div className="stat-foot"><span className="stat-note">Total current stock snapshot</span></div></article></section>
    <div className="finance-toolbar"><div><h2>Revenue and expenses</h2><p>Posted entries for {data.period.from} through {data.period.to}.</p></div><div className="toolbar-right"><div className="chart-legend"><span><i className="legend-revenue" />Revenue</span><span><i className="legend-expense" />Expenses</span></div><button className="button button-secondary" onClick={exportCsv}>Export CSV</button></div></div>
    <section className="panel statement-panel"><form className="form-row" onSubmit={applyPeriod}><label>From month<input type="month" value={from} onChange={(event) => setFrom(event.target.value)} required /></label><label>To month<input type="month" value={to} onChange={(event) => setTo(event.target.value)} required /></label><button className="button button-primary">Apply range</button></form><p className="field-hint">Invoice totals use invoices issued in this period and show their current payment balances. Low stock is a current snapshot.</p></section>
    <section className="panel chart-panel"><div className="monthly-chart" style={{ gridTemplateColumns: `repeat(${data.months.length}, minmax(18px, 1fr))`, minWidth: `${Math.max(100, data.months.length * 32)}px` }}>{data.months.map((month) => <div className="month-column" key={month.month}><div className="bar-pair"><div title={`Revenue ${money(month.revenue)}`} className="chart-bar revenue-bar" style={{ height: `${Math.max(month.revenue > 0 ? 3 : 0, month.revenue / max * 100)}%` }} /><div title={`Expenses ${money(month.expenses)}`} className="chart-bar expense-bar" style={{ height: `${Math.max(month.expenses > 0 ? 3 : 0, month.expenses / max * 100)}%` }} /></div><span>{month.label}</span></div>)}</div></section>
    <div className="dashboard-lower"><section className="panel data-panel"><div className="panel-heading"><div><h2>Invoice status</h2><p>Invoice totals by current state</p></div></div><div className="table-wrap"><table><thead><tr><th>STATUS</th><th>COUNT</th><th>INVOICED</th><th>PAID</th><th>OUTSTANDING</th></tr></thead><tbody>{data.invoiceStatuses.map((item) => <tr key={item.status}><td><span className="movement-type">{item.status.replaceAll("_", " ")}</span></td><td>{item.count}</td><td>{money(item.total)}</td><td>{money(item.paid)}</td><td>{money(Math.max(0, item.total - item.paid))}</td></tr>)}</tbody></table>{!data.invoiceStatuses.length && <div className="empty-state">No customer invoices yet.</div>}</div></section><section className="panel data-panel"><div className="panel-heading"><div><h2>Low stock</h2><p>Showing up to 20 of {data.lowStockCount} active products at or below reorder point</p></div></div><div className="table-wrap"><table><thead><tr><th>PRODUCT</th><th>STOCK</th><th>REORDER AT</th></tr></thead><tbody>{data.lowStock.map((product) => <tr key={product.id}><td><strong>{product.name}</strong><small className="table-subtext">{product.sku}</small></td><td>{product.stock}</td><td>{product.reorderLevel}</td></tr>)}</tbody></table>{!data.lowStock.length && <div className="empty-state">Stock is above all reorder points.</div>}</div></section></div>
  </>;
}
