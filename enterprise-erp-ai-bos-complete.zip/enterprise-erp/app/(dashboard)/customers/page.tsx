import CustomerManager from "./customer-manager";
import { requirePagePermission } from "@/lib/page-access";

export default async function CustomersPage() {
  await requirePagePermission("customers.read");
  return <><div className="page-heading"><div><div className="eyebrow">RELATIONSHIPS</div><h1>Customers</h1><p>Manage customer details and review the full sales and payment lifecycle while preserving archived history.</p></div></div><CustomerManager /></>;
}
