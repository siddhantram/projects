"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type Customer = { id: string; name: string; email: string | null; phone: string | null; company: string | null; notes: string | null; active: boolean; createdAt: string };
type Activity = { id: string; type: string; title: string; detail: string; occurredAt: string; actor: string | null };

export default function CustomerManager() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [query, setQuery] = useState("");
  const [includeArchived, setIncludeArchived] = useState(false);
  const [page, setPage] = useState(1);
  const [pageCount, setPageCount] = useState(1);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Customer | null>(null);
  const [historyCustomer, setHistoryCustomer] = useState<Customer | null>(null);
  const [history, setHistory] = useState<Activity[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    const response = await fetch(`/api/customers?q=${encodeURIComponent(query)}&page=${page}&includeArchived=${includeArchived}`);
    const data = await response.json();
    if (response.ok) { setCustomers(data.customers); setPageCount(data.pageCount); }
    else setError(data.error ?? "Unable to load customers");
  }, [query, page, includeArchived]);
  useEffect(() => { void load(); }, [load]);

  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    const form = new FormData(event.currentTarget);
    const response = await fetch(editing ? `/api/customers/${editing.id}` : "/api/customers", { method: editing ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.fromEntries(form.entries())) });
    const data = await response.json(); setBusy(false);
    if (!response.ok) { setError(data.error ?? "Unable to save customer"); return; }
    setOpen(false); setEditing(null); await load();
  }

  async function toggleActive(customer: Customer) {
    const action = customer.active ? "archive" : "restore";
    if (customer.active && !window.confirm(`Archive ${customer.name}? Their sales and invoice history will be preserved.`)) return;
    const response = await fetch(`/api/customers/${customer.id}`, { method: customer.active ? "DELETE" : "PATCH", headers: customer.active ? undefined : { "Content-Type": "application/json" }, ...(customer.active ? {} : { body: JSON.stringify({ active: true }) }) });
    const data = await response.json();
    if (!response.ok) { setError(data.error ?? `Unable to ${action} customer`); return; }
    await load();
  }

  async function showHistory(customer: Customer) {
    setHistoryCustomer(customer); setHistory(null); setError("");
    try {
      const response = await fetch(`/api/customers/${customer.id}`);
      const data = await response.json();
      if (!response.ok) { setError(data.error ?? "Unable to load customer history"); return; }
      setHistory(data.activity);
    } catch { setError("Unable to load customer history"); }
  }

  return <>
    <div className="toolbar"><div className="search-box"><span>⌕</span><input value={query} onChange={(event) => { setPage(1); setQuery(event.target.value); }} placeholder="Search customers…" /></div><div className="toolbar-right"><label className="archived-toggle"><input type="checkbox" checked={includeArchived} onChange={(event) => { setPage(1); setIncludeArchived(event.target.checked); }} /> Show archived</label><span className="result-count">{customers.length} shown</span><a className="button button-secondary" href={`/api/customers/export?q=${encodeURIComponent(query)}&includeArchived=${includeArchived}`}>Export CSV</a><button className="button button-primary" onClick={() => { setEditing(null); setOpen(true); setError(""); }}>＋ Add customer</button></div></div>
    {error && <div className="inline-error" role="alert">{error}</div>}
    <div className="panel data-panel"><div className="table-wrap"><table><thead><tr><th>CUSTOMER</th><th>COMPANY</th><th>PHONE</th><th>ADDED</th><th>STATUS</th><th></th></tr></thead><tbody>{customers.map((customer) => <tr key={customer.id}><td><div className="customer-cell"><span className="customer-avatar">{customer.name.slice(0, 1).toUpperCase()}</span><span>{customer.name}<small>{customer.email ?? "—"}</small></span></div></td><td>{customer.company ?? "—"}</td><td>{customer.phone ?? "—"}</td><td>{new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(customer.createdAt))}</td><td><span className={`badge ${customer.active ? "badge-green" : "badge-neutral"}`}>{customer.active ? "Active" : "Archived"}</span></td><td><div className="row-actions"><button onClick={() => void showHistory(customer)}>History</button><button onClick={() => { setEditing(customer); setError(""); setOpen(true); }}>Edit</button><button className={customer.active ? "danger-action" : "text-link"} onClick={() => void toggleActive(customer)}>{customer.active ? "Archive" : "Restore"}</button></div></td></tr>)}</tbody></table>
    {customers.length === 0 && <div className="empty-state"><span className="empty-icon">◉</span><strong>{query ? "No matching customers" : "Your directory is ready"}</strong><span>{query ? "Try a different name, email or company." : "Add your first customer to keep every relationship in one place."}</span>{!query && <button className="button button-secondary" onClick={() => setOpen(true)}>Add your first customer</button>}</div>}</div>{pageCount > 1 && <div className="pagination"><span>Page {page} of {pageCount}</span><div><button className="button button-secondary button-small" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button><button className="button button-secondary button-small" disabled={page >= pageCount} onClick={() => setPage(page + 1)}>Next</button></div></div>}</div>
    {open && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) { setOpen(false); setEditing(null); } }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="customer-modal-title"><div className="modal-heading"><div><div className="eyebrow">CUSTOMER DIRECTORY</div><h2 id="customer-modal-title">{editing ? "Edit customer" : "Add a customer"}</h2></div><button className="icon-button" aria-label="Close" onClick={() => { setOpen(false); setEditing(null); }}>×</button></div><form onSubmit={create} className="auth-form"><label>Customer name<input name="name" required minLength={2} placeholder="Customer or contact name" defaultValue={editing?.name ?? ""} /></label><div className="form-row"><label>Email<input name="email" type="email" placeholder="name@company.com" defaultValue={editing?.email ?? ""} /></label><label>Phone<input name="phone" type="tel" placeholder="+91 98765 43210" defaultValue={editing?.phone ?? ""} /></label></div><label>Company<input name="company" placeholder="Company name" defaultValue={editing?.company ?? ""} /></label><label>Notes<textarea name="notes" rows={3} maxLength={2000} defaultValue={editing?.notes ?? ""} placeholder="Internal notes about this customer" /></label>{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => { setOpen(false); setEditing(null); }}>Cancel</button><button disabled={busy} className="button button-primary">{busy ? "Saving…" : editing ? "Save changes" : "Save customer"}</button></div></form></section></div>}
    {historyCustomer && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) { setHistoryCustomer(null); setHistory(null); } }}><section className="modal-card customer-history-modal" role="dialog" aria-modal="true" aria-labelledby="customer-history-title"><div className="modal-heading"><div><div className="eyebrow">CUSTOMER LIFECYCLE</div><h2 id="customer-history-title">{historyCustomer.name}</h2><p>{[historyCustomer.company, historyCustomer.email, historyCustomer.phone].filter(Boolean).join(" · ") || "Customer activity"}</p></div><button className="icon-button" aria-label="Close history" onClick={() => { setHistoryCustomer(null); setHistory(null); }}>×</button></div>{history === null ? <div className="loading-state">Loading customer activity…</div> : history.length ? <div className="activity-list">{history.map((item) => <article className="activity-item" key={item.id}><span className={`activity-mark activity-${item.type}`} aria-hidden="true" /><div className="activity-content"><div className="activity-heading"><strong>{item.title}</strong><time>{new Intl.DateTimeFormat("en-IN", { dateStyle: "medium", timeStyle: "short" }).format(new Date(item.occurredAt))}</time></div><p>{item.detail}</p>{item.actor && <small>Updated by {item.actor}</small>}</div></article>)}</div> : <div className="empty-state compact"><strong>No activity recorded</strong><span>Sales and account events for this customer will appear here.</span></div>}{historyCustomer.notes && <p className="customer-history-notes"><strong>Internal notes</strong><br />{historyCustomer.notes}</p>}</section></div>}
  </>;
}
