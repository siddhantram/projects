import InventoryManager from "./inventory-manager";
import { requirePagePermission } from "@/lib/page-access";

export default async function InventoryPage() {
  await requirePagePermission("inventory.read");
  return <><div className="page-heading"><div><div className="eyebrow">OPERATIONS</div><h1>Inventory</h1><p>Track on-hand stock using a complete movement ledger.</p></div></div><InventoryManager /></>;
}
