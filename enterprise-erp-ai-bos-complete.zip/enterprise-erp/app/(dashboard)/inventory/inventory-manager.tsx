"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type Product = { id: string; name: string; sku: string; reorderLevel: number; active: boolean; stock: number };
type Warehouse = { id: string; name: string; location: string | null };
type StockBalance = { productId: string; warehouseId: string; quantity: number };
type Movement = { id: string; type: string; quantity: number; createdAt: string; product: Product; warehouse: Warehouse; reference: string | null };

export default function InventoryManager() {
  const [products, setProducts] = useState<Product[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [stockBalances, setStockBalances] = useState<StockBalance[]>([]);
  const [movements, setMovements] = useState<Movement[]>([]);
  const [loading, setLoading] = useState(true);
  const [warehouseOpen, setWarehouseOpen] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    const [inventoryResponse, productResponse] = await Promise.all([fetch("/api/inventory"), fetch("/api/products")]);
    const [inventory, catalog] = await Promise.all([inventoryResponse.json(), productResponse.json()]);
    if (!inventoryResponse.ok || !productResponse.ok) { setError(inventory.error ?? catalog.error ?? "Unable to load inventory"); setLoading(false); return; }
    setWarehouses(inventory.warehouses);
    setStockBalances(inventory.balances);
    setMovements(inventory.movements);
    setProducts(catalog.products.filter((product: Product) => product.active));
    setLoading(false);
  }, []);
  useEffect(() => { void load(); }, [load]);
  async function submitMovement(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    const formElement = event.currentTarget;
    const payload = Object.fromEntries(new FormData(formElement).entries());
    const response = await fetch("/api/inventory", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const data = await response.json(); setBusy(false);
    if (!response.ok) { setError(data.error ?? "Unable to record movement"); return; }
    formElement.reset(); await load();
  }
  async function addWarehouse(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    const response = await fetch("/api/inventory/warehouses", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.fromEntries(new FormData(event.currentTarget).entries())) });
    const data = await response.json(); setBusy(false);
    if (!response.ok) { setError(data.error ?? "Unable to add warehouse"); return; }
    setWarehouseOpen(false); await load();
  }
  async function submitTransfer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    const formElement = event.currentTarget;
    const response = await fetch("/api/inventory/transfers", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.fromEntries(new FormData(formElement).entries())) });
    const data = await response.json(); setBusy(false);
    if (!response.ok) { setError(data.error ?? "Unable to transfer stock"); return; }
    formElement.reset(); await load();
  }
  const totalUnits = products.reduce((total, product) => total + product.stock, 0);
  const lowStockCount = products.filter((product) => product.stock <= product.reorderLevel).length;

  return <>
    {error && <div className="inline-error" role="alert">{error}</div>}
    <section className="inventory-summary"><div><span>Tracked products</span><strong>{products.length}</strong></div><div><span>Units on hand</span><strong>{totalUnits.toLocaleString("en-IN")}</strong></div><div><span>Warehouses</span><strong>{warehouses.length}</strong></div><div><span>Low stock items</span><strong className={lowStockCount ? "text-amber" : ""}>{lowStockCount}</strong></div></section>
    <div className="inventory-grid"><section className="panel inventory-action"><div className="panel-heading"><div><h2>Record stock movement</h2><p>Use purchase orders and sales fulfilment to record receipts and dispatches.</p></div></div>{products.length === 0 || warehouses.length === 0 ? <div className="setup-hint">Add a product and a warehouse before recording stock.</div> : <form onSubmit={submitMovement} className="auth-form"><label>Product<select name="productId" required>{products.map((product) => <option key={product.id} value={product.id}>{product.name} · {product.sku}</option>)}</select></label><label>Warehouse<select name="warehouseId" required>{warehouses.map((warehouse) => <option key={warehouse.id} value={warehouse.id}>{warehouse.name}</option>)}</select></label><div className="form-row"><label>Movement type<select name="type"><option value="OPENING">Opening stock</option><option value="RETURN">Return received</option><option value="ADJUSTMENT">Adjustment</option></select></label><label>Quantity<input type="number" name="quantity" min="-999999" step="1" required placeholder="0" /></label></div><label>Reference (optional)<input name="reference" placeholder="Reference or note" /></label><button disabled={busy} className="button button-primary">{busy ? "Recording…" : "Record movement"}</button></form>}</section>
    <section className="panel inventory-action"><div className="panel-heading"><div><h2>Transfer between warehouses</h2><p>Both ledger entries are saved together.</p></div></div>{products.length === 0 || warehouses.length < 2 ? <div className="setup-hint">Add a product and at least two warehouses before transferring stock.</div> : <form onSubmit={submitTransfer} className="auth-form"><label>Product<select name="productId" required>{products.map((product) => <option key={product.id} value={product.id}>{product.name} · {product.sku}</option>)}</select></label><div className="form-row"><label>From<select name="sourceWarehouseId" required>{warehouses.map((warehouse) => <option key={warehouse.id} value={warehouse.id}>{warehouse.name}</option>)}</select></label><label>To<select name="destinationWarehouseId" required defaultValue={warehouses[1]?.id}>{warehouses.map((warehouse) => <option key={warehouse.id} value={warehouse.id}>{warehouse.name}</option>)}</select></label></div><label>Quantity<input type="number" name="quantity" min="1" step="1" required placeholder="1" /></label><label>Reference (optional)<input name="reference" placeholder="TR-1042" /></label><button disabled={busy} className="button button-primary">{busy ? "Transferring…" : "Transfer stock"}</button></form>}</section>
    <section className="panel warehouse-panel"><div className="panel-heading"><div><h2>Warehouses</h2><p>Storage locations for your stock</p></div><button className="button button-secondary button-small" onClick={() => { setError(""); setWarehouseOpen(true); }}>＋ Add</button></div>{warehouses.length ? <div className="warehouse-list">{warehouses.map((warehouse) => <div className="warehouse-row" key={warehouse.id}><span className="warehouse-icon">⌂</span><span>{warehouse.name}<small>{warehouse.location ?? "No location set"}</small></span></div>)}</div> : <div className="empty-state compact"><span className="empty-icon">⌂</span><strong>No warehouses yet</strong><button className="button button-secondary" onClick={() => setWarehouseOpen(true)}>Add a warehouse</button></div>}</section></div>
    <section className="panel movement-panel"><div className="panel-heading"><div><h2>Stock by warehouse</h2><p>Current on-hand quantity for each active product and warehouse.</p></div><a className="button button-secondary" href="/api/inventory/export">Export CSV</a></div>{loading ? <div className="loading-state">Loading inventory…</div> : products.length && warehouses.length ? <div className="table-wrap"><table><thead><tr><th>PRODUCT</th><th>SKU</th>{warehouses.map((warehouse) => <th key={warehouse.id}>{warehouse.name}</th>)}</tr></thead><tbody>{products.map((product) => <tr key={product.id}><td>{product.name}</td><td>{product.sku}</td>{warehouses.map((warehouse) => { const quantity = stockBalances.find((balance) => balance.productId === product.id && balance.warehouseId === warehouse.id)?.quantity ?? 0; return <td key={warehouse.id} className={quantity <= product.reorderLevel ? "text-amber" : ""}>{quantity.toLocaleString("en-IN")}</td>; })}</tr>)}</tbody></table></div> : <div className="empty-state compact"><strong>No stock balances to show</strong><span>Add products and warehouses to view quantities by location.</span></div>}</section>
    <section className="panel movement-panel"><div className="panel-heading"><div><h2>Movement history</h2><p>Latest stock changes across your workspace</p></div><span className="result-count">Latest 100</span></div>{loading ? <div className="loading-state">Loading inventory…</div> : movements.length ? <div className="table-wrap"><table><thead><tr><th>PRODUCT</th><th>WAREHOUSE</th><th>MOVEMENT</th><th>QUANTITY</th><th>REFERENCE</th><th>DATE</th></tr></thead><tbody>{movements.map((movement) => <tr key={movement.id}><td><div className="customer-cell"><span className="product-thumb">▧</span><span>{movement.product.name}<small>{movement.product.sku}</small></span></div></td><td>{movement.warehouse.name}</td><td><span className="movement-type">{movement.type.replaceAll("_", " ")}</span></td><td className={movement.quantity < 0 ? "text-amber" : "text-green"}>{movement.quantity > 0 ? "+" : ""}{movement.quantity}</td><td>{movement.reference ?? "—"}</td><td>{new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(movement.createdAt))}</td></tr>)}</tbody></table></div> : <div className="empty-state compact"><span className="empty-icon">▤</span><strong>No movement recorded yet</strong><span>Opening stock and future purchases will appear here.</span></div>}</section>
    {warehouseOpen && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setWarehouseOpen(false); }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="warehouse-modal-title"><div className="modal-heading"><div><div className="eyebrow">INVENTORY SETUP</div><h2 id="warehouse-modal-title">Add a warehouse</h2></div><button className="icon-button" aria-label="Close" onClick={() => setWarehouseOpen(false)}>×</button></div><form onSubmit={addWarehouse} className="auth-form"><label>Warehouse name<input name="name" required minLength={2} placeholder="Main warehouse" /></label><label>Location<input name="location" placeholder="City, region or address" /></label>{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => setWarehouseOpen(false)}>Cancel</button><button disabled={busy} className="button button-primary">{busy ? "Saving…" : "Save warehouse"}</button></div></form></section></div>}
  </>;
}
