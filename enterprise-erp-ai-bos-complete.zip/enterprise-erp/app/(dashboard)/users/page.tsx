import UserManager from "./user-manager";
import { requirePageAdmin } from "@/lib/page-access";

export default async function UsersPage() {
  const user = await requirePageAdmin();
  return <><div className="page-heading"><div><div className="eyebrow">ACCESS CONTROL</div><h1>Users and roles</h1><p>Create workspace accounts, assign roles and deactivate access.</p></div></div><UserManager actorId={user.id} canManageSuperAdmins={user.role === "SUPER_ADMIN"} /></>;
}
