import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";

const actions = ["CREATE", "UPDATE", "DELETE", "LOGIN", "LOGOUT", "APPROVE", "REJECT", "EXPORT"] as const;

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "audit.read", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const search = new URL(request.url).searchParams;
  const from = search.get("from") ?? "";
  const to = search.get("to") ?? "";
  const actionValue = search.get("action") ?? "";
  const entity = (search.get("entity") ?? "").trim().slice(0, 100);
  const pageValue = Number(search.get("page") ?? "1");
  if (!Number.isInteger(pageValue) || pageValue < 1 || pageValue > 1000) return NextResponse.json({ error: "Choose a valid page" }, { status: 400 });
  if (Boolean(from) !== Boolean(to)) return NextResponse.json({ error: "Choose both a start and end date" }, { status: 400 });
  if (actionValue && !actions.includes(actionValue as typeof actions[number])) return NextResponse.json({ error: "Choose a valid audit action" }, { status: 400 });
  let createdAt: { gte: Date; lt: Date } | undefined;
  if (from && to) {
    const pattern = /^\d{4}-\d{2}-\d{2}$/;
    const start = new Date(`${from}T00:00:00.000Z`);
    const end = new Date(`${to}T00:00:00.000Z`);
    const daySpan = (end.getTime() - start.getTime()) / 86400000;
    if (!pattern.test(from) || !pattern.test(to) || !Number.isFinite(daySpan) || daySpan < 0 || daySpan > 366 || start.toISOString().slice(0, 10) !== from || end.toISOString().slice(0, 10) !== to) return NextResponse.json({ error: "Choose a valid date range of up to 367 days" }, { status: 400 });
    createdAt = { gte: start, lt: new Date(end.getTime() + 86400000) };
  }
  const where = { organizationId: user.organizationId, ...(createdAt ? { createdAt } : {}), ...(actionValue ? { action: actionValue as typeof actions[number] } : {}), ...(entity ? { entity: { contains: entity, mode: "insensitive" as const } } : {}) };
  const pageSize = 50;
  const [logs, total] = await Promise.all([
    db.auditLog.findMany({ where, include: { user: { select: { name: true, email: true } } }, orderBy: { createdAt: "desc" }, skip: (pageValue - 1) * pageSize, take: pageSize }),
    db.auditLog.count({ where }),
  ]);
  return NextResponse.json({ logs, total, page: pageValue, pageSize, totalPages: Math.max(1, Math.ceil(total / pageSize)) });
}
