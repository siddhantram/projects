import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { requestIp } from "@/lib/audit";

function csvCell(value: string) {
  let text = value;
  if (/^[\s\u0000-\u001f]*[=+@\-]/.test(text)) text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
}

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "customers.read", user.organization.rolePermissions)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const search = new URL(request.url).searchParams;
  const query = (search.get("q") ?? "").trim().slice(0, 100);
  const includeArchived = search.get("includeArchived") === "true";
  const customers = await db.customer.findMany({
    where: {
      organizationId: user.organizationId,
      ...(includeArchived ? {} : { active: true }),
      ...(query ? { OR: [
        { name: { contains: query, mode: "insensitive" as const } },
        { email: { contains: query, mode: "insensitive" as const } },
        { company: { contains: query, mode: "insensitive" as const } },
      ] } : {}),
    },
    orderBy: [{ name: "asc" }, { id: "asc" }],
    select: { name: true, email: true, phone: true, company: true, active: true, createdAt: true },
  });

  const rows = [["Name", "Email", "Phone", "Company", "Status", "Created at"], ...customers.map((customer) => [
    customer.name,
    customer.email ?? "",
    customer.phone ?? "",
    customer.company ?? "",
    customer.active ? "Active" : "Archived",
    new Intl.DateTimeFormat("en-CA", { dateStyle: "short", timeZone: user.organization.timezone }).format(customer.createdAt),
  ])];
  const csv = `\uFEFF${rows.map((row) => row.map(csvCell).join(",")).join("\r\n")}`;

  await db.auditLog.create({ data: {
    organizationId: user.organizationId,
    userId: user.id,
    action: "EXPORT",
    entity: "Customer",
    ipAddress: requestIp(request),
    afterData: { count: customers.length, includeArchived, query: query || null },
  } });

  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": "attachment; filename=customers.csv",
      "Cache-Control": "no-store",
    },
  });
}
