import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { readEmail, readObject, readOptionalText, readText } from "@/lib/validation";

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "customers.read", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { searchParams } = new URL(request.url);
  const query = searchParams.get("q")?.trim().slice(0, 100) ?? "";
  const includeArchived = searchParams.get("includeArchived") === "true";
  const page = Math.max(1, Math.floor(Number(searchParams.get("page")) || 1));
  const take = 20;
  const where = {
    organizationId: user.organizationId,
    ...(includeArchived ? {} : { active: true }),
    ...(query ? { OR: [{ name: { contains: query, mode: "insensitive" as const } }, { email: { contains: query, mode: "insensitive" as const } }, { company: { contains: query, mode: "insensitive" as const } }] } : {}),
  };
  const [customers, total] = await Promise.all([
    db.customer.findMany({ where, orderBy: { createdAt: "desc" }, skip: (page - 1) * take, take }),
    db.customer.count({ where }),
  ]);
  return NextResponse.json({ customers, page, pageSize: take, total, pageCount: Math.ceil(total / take) });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "customers.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const name = readText(body.name, "Customer name", 2, 120);
  const email = body.email ? readEmail(body.email) : { data: null, error: null };
  const phone = readOptionalText(body.phone, "Phone", 40);
  const company = readOptionalText(body.company, "Company", 120);
  const notes = readOptionalText(body.notes, "Notes", 2000);
  const error = name.error ?? email.error ?? phone.error ?? company.error ?? notes.error;
  if (error) return NextResponse.json({ error }, { status: 400 });
  try {
    const customer = await db.$transaction(async (tx) => {
      const created = await tx.customer.create({ data: { organizationId: user.organizationId, name: name.data, email: email.data, phone: phone.data, company: company.data, notes: notes.data } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "Customer", entityId: created.id, afterData: { name: created.name, email: created.email, company: created.company }, ipAddress: requestIp(request) });
      return created;
    });
    return NextResponse.json({ customer }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "A customer with this email already exists" }, { status: 409 });
    return NextResponse.json({ error: "Unable to create customer" }, { status: 500 });
  }
}
