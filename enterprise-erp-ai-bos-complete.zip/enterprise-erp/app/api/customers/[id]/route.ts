import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { readEmail, readObject, readOptionalText, readText } from "@/lib/validation";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(_request: Request, context: RouteContext) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "customers.read", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await context.params;
  const [customer, customerAudit] = await Promise.all([
    db.customer.findFirst({
      where: { id, organizationId: user.organizationId },
      select: {
        id: true, name: true, email: true, phone: true, company: true, notes: true, active: true, createdAt: true,
        leads: { where: { organizationId: user.organizationId }, orderBy: { createdAt: "desc" }, take: 30, select: { id: true, status: true, source: true, createdAt: true, updatedAt: true } },
        quotations: { where: { organizationId: user.organizationId }, orderBy: { updatedAt: "desc" }, take: 30, select: { id: true, number: true, status: true, total: true, currency: true, createdAt: true, updatedAt: true } },
        salesOrders: { where: { organizationId: user.organizationId }, orderBy: { updatedAt: "desc" }, take: 30, select: { id: true, number: true, status: true, total: true, currency: true, createdAt: true, updatedAt: true } },
        invoices: { where: { organizationId: user.organizationId }, orderBy: { updatedAt: "desc" }, take: 30, select: { id: true, number: true, status: true, total: true, amountPaid: true, currency: true, dueAt: true, createdAt: true, updatedAt: true } },
        payments: { where: { organizationId: user.organizationId }, orderBy: { receivedAt: "desc" }, take: 30, select: { id: true, number: true, amount: true, method: true, receivedAt: true, invoice: { select: { number: true } } } },
      },
    }),
    db.auditLog.findMany({ where: { organizationId: user.organizationId, entity: "Customer", entityId: id }, orderBy: { createdAt: "desc" }, take: 30, select: { id: true, action: true, afterData: true, createdAt: true, user: { select: { name: true } } } }),
  ]);
  if (!customer) return NextResponse.json({ error: "Customer not found" }, { status: 404 });

  const hasCreatedAudit = customerAudit.some((entry) => entry.action === "CREATE");
  const activity = [
    ...(!hasCreatedAudit ? [{ id: `customer-${customer.id}`, type: "customer", title: "Customer added", detail: customer.company ?? customer.email ?? "Customer record created", occurredAt: customer.createdAt, actor: null as string | null }] : []),
    ...customer.leads.map((lead) => ({ id: `lead-${lead.id}`, type: "lead", title: lead.status === "CONVERTED" ? "Lead converted" : "Lead activity", detail: `${lead.status}${lead.source ? ` · ${lead.source}` : ""}`, occurredAt: lead.updatedAt, actor: null as string | null })),
    ...customer.quotations.map((quote) => ({ id: `quote-${quote.id}`, type: "quotation", title: `Quotation ${quote.number}`, detail: `${quote.status} · ${quote.currency} ${Number(quote.total).toFixed(2)}`, occurredAt: quote.updatedAt, actor: null as string | null })),
    ...customer.salesOrders.map((order) => ({ id: `order-${order.id}`, type: "order", title: `Sales order ${order.number}`, detail: `${order.status} · ${order.currency} ${Number(order.total).toFixed(2)}`, occurredAt: order.updatedAt, actor: null as string | null })),
    ...customer.invoices.map((invoice) => ({ id: `invoice-${invoice.id}`, type: "invoice", title: `Invoice ${invoice.number}`, detail: `${invoice.status} · ${invoice.currency} ${Number(invoice.total).toFixed(2)} · paid ${Number(invoice.amountPaid).toFixed(2)}`, occurredAt: invoice.updatedAt, actor: null as string | null })),
    ...customer.payments.map((payment) => ({ id: `payment-${payment.id}`, type: "payment", title: `Payment ${payment.number} received`, detail: `${payment.method} · ${Number(payment.amount).toFixed(2)}${payment.invoice ? ` · ${payment.invoice.number}` : ""}`, occurredAt: payment.receivedAt, actor: null as string | null })),
    ...customerAudit.map((entry) => {
      const after = entry.afterData && typeof entry.afterData === "object" && !Array.isArray(entry.afterData) ? entry.afterData as Record<string, unknown> : null;
      const title = entry.action === "CREATE" ? "Customer added" : after?.active === false ? "Customer archived" : after?.active === true ? "Customer restored" : "Customer details updated";
      return { id: `audit-${entry.id}`, type: "customer", title, detail: entry.action, occurredAt: entry.createdAt, actor: entry.user?.name ?? null };
    }),
  ].sort((left, right) => right.occurredAt.getTime() - left.occurredAt.getTime()).slice(0, 100).map((item) => ({ ...item, occurredAt: item.occurredAt.toISOString() }));

  const { leads: _leads, quotations: _quotations, salesOrders: _orders, invoices: _invoices, payments: _payments, ...customerDetails } = customer;
  return NextResponse.json({ customer: customerDetails, activity });
}

export async function PATCH(request: Request, context: RouteContext) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "customers.update", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const { id } = await context.params;
  const existing = await db.customer.findFirst({ where: { id, organizationId: user.organizationId } });
  if (!existing) return NextResponse.json({ error: "Customer not found" }, { status: 404 });
  if (body.active !== undefined) {
    if (Object.keys(body).length !== 1 || typeof body.active !== "boolean") return NextResponse.json({ error: "Active status must be changed on its own" }, { status: 400 });
    const customer = await db.$transaction(async (tx) => {
      const updated = await tx.customer.update({ where: { id }, data: { active: body.active as boolean } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "Customer", entityId: id, beforeData: { active: existing.active }, afterData: { active: updated.active }, ipAddress: requestIp(request) });
      return updated;
    });
    return NextResponse.json({ customer });
  }
  const name = readText(body.name, "Customer name", 2, 120);
  const email = body.email ? readEmail(body.email) : { data: null, error: null };
  const phone = readOptionalText(body.phone, "Phone", 40);
  const company = readOptionalText(body.company, "Company", 120);
  const notes = readOptionalText(body.notes, "Notes", 2000);
  const error = name.error ?? email.error ?? phone.error ?? company.error ?? notes.error;
  if (error) return NextResponse.json({ error }, { status: 400 });
  try {
    const customer = await db.$transaction(async (tx) => {
      const updated = await tx.customer.update({ where: { id }, data: { name: name.data, email: email.data, phone: phone.data, company: company.data, notes: notes.data } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "Customer", entityId: id, beforeData: { name: existing.name, email: existing.email, phone: existing.phone, company: existing.company }, afterData: { name: updated.name, email: updated.email, phone: updated.phone, company: updated.company }, ipAddress: requestIp(request) });
      return updated;
    });
    return NextResponse.json({ customer });
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "A customer with this email already exists" }, { status: 409 });
    return NextResponse.json({ error: "Unable to update customer" }, { status: 500 });
  }
}

export async function DELETE(request: Request, context: RouteContext) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "customers.delete", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await context.params;
  const existing = await db.customer.findFirst({ where: { id, organizationId: user.organizationId } });
  if (!existing) return NextResponse.json({ error: "Customer not found" }, { status: 404 });
  if (!existing.active) return NextResponse.json({ success: true, active: false });
  await db.$transaction(async (tx) => {
    await tx.customer.update({ where: { id }, data: { active: false } });
    await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "Customer", entityId: id, beforeData: { name: existing.name, active: existing.active }, afterData: { active: false }, ipAddress: requestIp(request) });
  });
  return NextResponse.json({ success: true, active: false });
}
