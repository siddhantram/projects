import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";

type MonthlyTotal = { month: Date; revenue: string; expenses: string };

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "reports.read", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const search = new URL(request.url).searchParams;
  const monthPattern = /^\d{4}-(0[1-9]|1[0-2])$/;
  const today = new Date();
  const currentMonth = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1));
  const defaultFromDate = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth() - 11, 1));
  const from = search.get("from") ?? defaultFromDate.toISOString().slice(0, 7);
  const to = search.get("to") ?? currentMonth.toISOString().slice(0, 7);
  const [fromYear, fromMonth] = from.split("-").map(Number);
  const [toYear, toMonth] = to.split("-").map(Number);
  const monthSpan = (toYear - fromYear) * 12 + toMonth - fromMonth;
  if (!monthPattern.test(from) || !monthPattern.test(to) || monthSpan < 0 || monthSpan > 35) {
    return NextResponse.json({ error: "Choose a valid month range of up to 36 months" }, { status: 400 });
  }
  const start = new Date(Date.UTC(fromYear, fromMonth - 1, 1));
  const endExclusive = new Date(Date.UTC(toYear, toMonth, 1));
  const [monthly, invoiceStatuses, customerCount, orderCount, activeProducts, movements] = await Promise.all([
    db.$queryRaw<MonthlyTotal[]>`SELECT date_trunc('month', j."entryDate") AS month, COALESCE(SUM(CASE WHEN a.type = 'REVENUE' THEN l.credit - l.debit ELSE 0 END), 0)::text AS revenue, COALESCE(SUM(CASE WHEN a.type = 'EXPENSE' THEN l.debit - l.credit ELSE 0 END), 0)::text AS expenses FROM "JournalEntry" j JOIN "JournalLine" l ON l."journalEntryId" = j.id JOIN "Account" a ON a.id = l."accountId" WHERE j."organizationId" = ${user.organizationId} AND j.status = 'POSTED' AND j."entryDate" >= ${start} AND j."entryDate" < ${endExclusive} GROUP BY date_trunc('month', j."entryDate") ORDER BY month ASC`,
    db.invoice.groupBy({ by: ["status"], where: { organizationId: user.organizationId, issuedAt: { gte: start, lt: endExclusive } }, _count: { _all: true }, _sum: { total: true, amountPaid: true } }),
    db.customer.count({ where: { organizationId: user.organizationId, createdAt: { gte: start, lt: endExclusive } } }),
    db.salesOrder.count({ where: { organizationId: user.organizationId, createdAt: { gte: start, lt: endExclusive } } }),
    db.product.findMany({ where: { organizationId: user.organizationId, active: true }, select: { id: true, name: true, sku: true, reorderLevel: true } }),
    db.stockMovement.groupBy({ by: ["productId"], where: { organizationId: user.organizationId }, _sum: { quantity: true } }),
  ]);
  const monthlyMap = new Map(monthly.map((row) => [row.month.toISOString().slice(0, 7), { revenue: Number(row.revenue), expenses: Number(row.expenses) }]));
  const months = Array.from({ length: monthSpan + 1 }, (_, offset) => {
    const date = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + offset, 1));
    const key = date.toISOString().slice(0, 7);
    return { month: key, label: new Intl.DateTimeFormat("en-IN", { month: "short", year: "2-digit", timeZone: "UTC" }).format(date), ...(monthlyMap.get(key) ?? { revenue: 0, expenses: 0 }) };
  });
  const stock = new Map(movements.map((item) => [item.productId, item._sum.quantity ?? 0]));
  const lowStockProducts = activeProducts.map((product) => ({ ...product, stock: stock.get(product.id) ?? 0 })).filter((product) => product.stock <= product.reorderLevel).sort((a, b) => a.stock - b.stock);
  return NextResponse.json({ period: { from, to }, months, invoiceStatuses: invoiceStatuses.map((item) => ({ status: item.status, count: item._count._all, total: Number(item._sum.total ?? 0), paid: Number(item._sum.amountPaid ?? 0) })), activity: { customersAdded: customerCount, salesOrdersCreated: orderCount }, lowStockCount: lowStockProducts.length, lowStock: lowStockProducts.slice(0, 20), currency: user.organization.currency });
}
