import { randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { readObject, readOptionalText, readText } from "@/lib/validation";

function journalNumber() {
  return `JE-${new Date().getFullYear()}-${randomBytes(3).toString("hex").toUpperCase()}`;
}

function money(cents: number) {
  return `${Math.floor(cents / 100)}.${String(cents % 100).padStart(2, "0")}`;
}

const MAX_JOURNAL_AMOUNT = 999_999_999_999.99;

function cashFlowCategory(account: { code: string; type: string }) {
  if (["1100", "1200", "2000", "2100"].includes(account.code) || account.type === "REVENUE" || account.type === "EXPENSE") return "OPERATING" as const;
  if (account.type === "ASSET") return "INVESTING" as const;
  if (account.type === "LIABILITY" || account.type === "EQUITY") return "FINANCING" as const;
  return "OPERATING" as const;
}

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "finance.read", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const url = new URL(request.url);
  const datePattern = /^\d{4}-\d{2}-\d{2}$/;
  const requestedFrom = url.searchParams.get("from");
  const requestedTo = url.searchParams.get("to");
  const today = new Date();
  const defaultTo = today.toISOString().slice(0, 10);
  const defaultFromDate = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth() - 11, 1));
  const from = requestedFrom ?? defaultFromDate.toISOString().slice(0, 10);
  const to = requestedTo ?? defaultTo;
  const fromDate = new Date(`${from}T00:00:00.000Z`);
  const toDate = new Date(`${to}T00:00:00.000Z`);
  const dayCount = (toDate.getTime() - fromDate.getTime()) / 86400000;
  if (!datePattern.test(from) || !datePattern.test(to) || !Number.isFinite(dayCount) || dayCount < 0 || dayCount > 366 || fromDate.toISOString().slice(0, 10) !== from || toDate.toISOString().slice(0, 10) !== to) {
    return NextResponse.json({ error: "Choose a valid date range of up to 367 days" }, { status: 400 });
  }
  const toExclusive = new Date(toDate.getTime() + 86400000);
  const [accounts, entries, expenses, balances, periodBalances, cashEntries] = await Promise.all([
    db.account.findMany({ where: { organizationId: user.organizationId, active: true }, orderBy: { code: "asc" } }),
    db.journalEntry.findMany({ where: { organizationId: user.organizationId, status: "POSTED" }, include: { lines: { include: { account: { select: { code: true, name: true, type: true } } }, expense: true } }, orderBy: { entryDate: "desc" }, take: 50 }),
    db.expense.findMany({ where: { organizationId: user.organizationId }, include: { journalEntry: { select: { number: true } } }, orderBy: { incurredAt: "desc" }, take: 50 }),
    db.journalLine.groupBy({ by: ["accountId"], where: { journalEntry: { organizationId: user.organizationId, status: "POSTED" } }, _sum: { debit: true, credit: true } }),
    db.journalLine.groupBy({ by: ["accountId"], where: { journalEntry: { organizationId: user.organizationId, status: "POSTED", entryDate: { gte: fromDate, lt: toExclusive } } }, _sum: { debit: true, credit: true } }),
    db.journalEntry.findMany({ where: { organizationId: user.organizationId, status: "POSTED", entryDate: { gte: fromDate, lt: toExclusive }, lines: { some: { account: { code: "1000" } } } }, include: { lines: { include: { account: { select: { id: true, code: true, name: true, type: true } } } } } }),
  ]);
  const totals = new Map(balances.map((line) => [line.accountId, { debit: Number(line._sum.debit ?? 0), credit: Number(line._sum.credit ?? 0) }]));
  const accountBalances = accounts.map((account) => {
    const balance = totals.get(account.id) ?? { debit: 0, credit: 0 };
    const naturalDebit = account.type === "ASSET" || account.type === "EXPENSE";
    return { id: account.id, code: account.code, name: account.name, type: account.type, debit: balance.debit, credit: balance.credit, balance: naturalDebit ? balance.debit - balance.credit : balance.credit - balance.debit };
  });
  const result = accountBalances.reduce((summary, account) => {
    if (account.type === "REVENUE") summary.revenue += account.balance;
    if (account.type === "EXPENSE") summary.expenses += account.balance;
    if (account.type === "ASSET" && account.code === "1100") summary.receivables += account.balance;
    if (account.type === "LIABILITY" && account.code === "2000") summary.payables += account.balance;
    return summary;
  }, { revenue: 0, expenses: 0, receivables: 0, payables: 0 });
  const profit = result.revenue - result.expenses;
  const assets = accountBalances.filter((account) => account.type === "ASSET");
  const liabilities = accountBalances.filter((account) => account.type === "LIABILITY");
  const equity = accountBalances.filter((account) => account.type === "EQUITY");
  const totalAssets = assets.reduce((sum, account) => sum + account.balance, 0);
  const totalLiabilities = liabilities.reduce((sum, account) => sum + account.balance, 0);
  const totalEquity = equity.reduce((sum, account) => sum + account.balance, 0) + profit;
  const incomeStatement = accountBalances.filter((account) => account.type === "REVENUE" || account.type === "EXPENSE");
  const periodTotals = new Map(periodBalances.map((line) => [line.accountId, { debit: Number(line._sum.debit ?? 0), credit: Number(line._sum.credit ?? 0) }]));
  const periodAccounts = accounts.map((account) => {
    const balance = periodTotals.get(account.id) ?? { debit: 0, credit: 0 };
    const naturalDebit = account.type === "ASSET" || account.type === "EXPENSE";
    return { id: account.id, code: account.code, name: account.name, type: account.type, balance: naturalDebit ? balance.debit - balance.credit : balance.credit - balance.debit };
  });
  const period = periodAccounts.reduce((summary, account) => {
    if (account.type === "REVENUE") summary.revenue += account.balance;
    if (account.type === "EXPENSE") summary.expenses += account.balance;
    if (account.code === "1000") summary.cashMovement += account.balance;
    return summary;
  }, { from, to, revenue: 0, expenses: 0, profit: 0, cashMovement: 0, accounts: periodAccounts.filter((account) => account.type === "REVENUE" || account.type === "EXPENSE") });
  period.profit = period.revenue - period.expenses;
  const cashFlowTotals = { OPERATING: 0, INVESTING: 0, FINANCING: 0 };
  const cashFlowLines = new Map<string, { accountId: string; code: string; name: string; category: keyof typeof cashFlowTotals; amountCents: number }>();
  for (const entry of cashEntries) {
    for (const line of entry.lines) {
      if (line.account.code === "1000") continue;
      const category = cashFlowCategory(line.account);
      const amountCents = Math.round((Number(line.credit) - Number(line.debit)) * 100);
      const current = cashFlowLines.get(line.account.id);
      if (current) current.amountCents += amountCents;
      else cashFlowLines.set(line.account.id, { accountId: line.account.id, code: line.account.code, name: line.account.name, category, amountCents });
      cashFlowTotals[category] += amountCents;
    }
  }
  const cashFlow = {
    from, to,
    operating: { accounts: [...cashFlowLines.values()].filter((line) => line.category === "OPERATING").map(({ accountId, code, name, amountCents }) => ({ accountId, code, name, amount: amountCents / 100 })), total: cashFlowTotals.OPERATING / 100 },
    investing: { accounts: [...cashFlowLines.values()].filter((line) => line.category === "INVESTING").map(({ accountId, code, name, amountCents }) => ({ accountId, code, name, amount: amountCents / 100 })), total: cashFlowTotals.INVESTING / 100 },
    financing: { accounts: [...cashFlowLines.values()].filter((line) => line.category === "FINANCING").map(({ accountId, code, name, amountCents }) => ({ accountId, code, name, amount: amountCents / 100 })), total: cashFlowTotals.FINANCING / 100 },
    netChange: (cashFlowTotals.OPERATING + cashFlowTotals.INVESTING + cashFlowTotals.FINANCING) / 100,
  };
  return NextResponse.json({ accounts, entries, expenses, accountBalances, incomeStatement, period, cashFlow, balanceSheet: { assets, liabilities, equity, currentEarnings: profit, totalAssets, totalLiabilities, totalEquity, balanced: Math.abs(totalAssets - totalLiabilities - totalEquity) < 0.01 }, cashPosition: accountBalances.filter((account) => account.code === "1000").reduce((sum, account) => sum + account.balance, 0), totals: { ...result, profit, currency: user.organization.currency } });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "finance.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });

  if (body.action === "account") {
    const code = readText(body.code, "Account code", 3, 20);
    const name = readText(body.name, "Account name", 2, 120);
    const type = body.type;
    const types = ["ASSET", "LIABILITY", "EQUITY", "REVENUE", "EXPENSE"] as const;
    if (code.error || name.error || typeof type !== "string" || !types.includes(type as typeof types[number])) return NextResponse.json({ error: code.error ?? name.error ?? "Choose a valid account type" }, { status: 400 });
    const normalizedCode = code.data.trim();
    if (!/^\d{3,20}$/.test(normalizedCode)) return NextResponse.json({ error: "Account code must contain 3 to 20 digits" }, { status: 400 });
    try {
      const account = await db.$transaction(async (tx) => {
        const created = await tx.account.create({ data: { organizationId: user.organizationId, code: normalizedCode, name: name.data, type: type as typeof types[number] } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "Account", entityId: created.id, afterData: { code: created.code, name: created.name, type: created.type }, ipAddress: requestIp(request) });
        return created;
      });
      return NextResponse.json({ account }, { status: 201 });
    } catch (error) {
      if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "An account with this code already exists in the workspace" }, { status: 409 });
      return NextResponse.json({ error: "Unable to create account" }, { status: 500 });
    }
  }

  if (body.action === "expense") {
    const category = readText(body.category, "Category", 2, 100);
    const description = readText(body.description, "Description", 3, 300);
    const vendor = readOptionalText(body.vendor, "Vendor", 120);
    const expenseAccountId = readText(body.expenseAccountId, "Expense account", 1, 100);
    const paymentAccountId = readText(body.paymentAccountId, "Payment account", 1, 100);
    const amount = Number(body.amount);
    const date = body.date ? new Date(String(body.date)) : new Date();
    const error = category.error ?? description.error ?? vendor.error ?? expenseAccountId.error ?? paymentAccountId.error;
    if (error || !Number.isFinite(amount) || amount <= 0 || !Number.isFinite(date.getTime())) return NextResponse.json({ error: error ?? "Enter a valid positive amount and date" }, { status: 400 });
    const amountCents = Math.round(amount * 100);
    const [expenseAccount, paymentAccount] = await Promise.all([
      db.account.findFirst({ where: { id: expenseAccountId.data, organizationId: user.organizationId, active: true } }),
      db.account.findFirst({ where: { id: paymentAccountId.data, organizationId: user.organizationId, active: true } }),
    ]);
    if (!expenseAccount || expenseAccount.type !== "EXPENSE" || !paymentAccount || paymentAccount.code !== "1000") return NextResponse.json({ error: "Choose an active expense account and the cash and bank account" }, { status: 400 });
    const expense = await db.$transaction(async (tx) => {
      const entry = await tx.journalEntry.create({ data: { organizationId: user.organizationId, postedById: user.id, number: journalNumber(), description: description.data, entryDate: date, status: "POSTED", lines: { create: [ { accountId: expenseAccount.id, debit: money(amountCents), credit: "0", memo: description.data }, { accountId: paymentAccount.id, debit: "0", credit: money(amountCents), memo: description.data } ] } } });
      const created = await tx.expense.create({ data: { organizationId: user.organizationId, createdById: user.id, journalEntryId: entry.id, category: category.data, description: description.data, vendor: vendor.data, amount: money(amountCents), incurredAt: date } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "Expense", entityId: created.id, afterData: { category: created.category, amount: amountCents / 100, journalEntry: entry.number }, ipAddress: requestIp(request) });
      return created;
    });
    return NextResponse.json({ expense }, { status: 201 });
  }

  if (body.action === "journal") {
    const description = readText(body.description, "Description", 3, 300);
    const rawLines = Array.isArray(body.lines) ? body.lines : [];
    if (description.error || rawLines.length < 2 || rawLines.length > 50) return NextResponse.json({ error: description.error ?? "A journal entry needs between 2 and 50 lines" }, { status: 400 });
    const lines = rawLines.map((raw) => {
      const line = readObject(raw);
      if (!line) return null;
      const accountId = readText(line.accountId, "Account", 1, 100);
      const debit = Number(line.debit ?? 0);
      const credit = Number(line.credit ?? 0);
      const memo = readOptionalText(line.memo, "Memo", 300);
      if (accountId.error || memo.error || !Number.isFinite(debit) || !Number.isFinite(credit) || debit < 0 || credit < 0 || debit > MAX_JOURNAL_AMOUNT || credit > MAX_JOURNAL_AMOUNT || (debit > 0) === (credit > 0)) return null;
      const debitCents = Math.round(debit * 100);
      const creditCents = Math.round(credit * 100);
      if (!Number.isSafeInteger(debitCents) || !Number.isSafeInteger(creditCents)) return null;
      return { accountId: accountId.data, debitCents, creditCents, memo: memo.data };
    });
    if (lines.some((line) => !line)) return NextResponse.json({ error: "Each journal line must have an account and either a debit or credit amount" }, { status: 400 });
    const debitTotal = lines.reduce((sum, line) => sum + (line?.debitCents ?? 0), 0);
    const creditTotal = lines.reduce((sum, line) => sum + (line?.creditCents ?? 0), 0);
    if (debitTotal <= 0 || debitTotal !== creditTotal) return NextResponse.json({ error: "Debits and credits must be equal and greater than zero" }, { status: 400 });
    const accountIds = [...new Set(lines.map((line) => line!.accountId))];
    if (accountIds.length < 2) return NextResponse.json({ error: "A journal entry must affect at least two different accounts" }, { status: 400 });
    const accounts = await db.account.findMany({ where: { id: { in: accountIds }, organizationId: user.organizationId, active: true } });
    if (accounts.length !== accountIds.length) return NextResponse.json({ error: "One or more accounts were not found in your workspace" }, { status: 404 });
    const entry = await db.$transaction(async (tx) => {
      const created = await tx.journalEntry.create({ data: { organizationId: user.organizationId, postedById: user.id, number: journalNumber(), description: description.data, lines: { create: lines.map((line) => ({ accountId: line!.accountId, debit: money(line!.debitCents), credit: money(line!.creditCents), memo: line!.memo })) } }, include: { lines: true } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "JournalEntry", entityId: created.id, afterData: { number: created.number, description: created.description, total: debitTotal / 100 }, ipAddress: requestIp(request) });
      return created;
    });
    return NextResponse.json({ entry }, { status: 201 });
  }

  return NextResponse.json({ error: "Unknown finance action" }, { status: 400 });
}
