import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "finance.read", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;
  const search = new URL(request.url).searchParams;
  const from = search.get("from");
  const to = search.get("to");
  const datePattern = /^\d{4}-\d{2}-\d{2}$/;
  if (!from || !to || !datePattern.test(from) || !datePattern.test(to)) return NextResponse.json({ error: "Choose a valid date range" }, { status: 400 });
  const fromDate = new Date(`${from}T00:00:00.000Z`);
  const toDate = new Date(`${to}T00:00:00.000Z`);
  const dayCount = (toDate.getTime() - fromDate.getTime()) / 86400000;
  if (!Number.isFinite(dayCount) || dayCount < 0 || dayCount > 366 || fromDate.toISOString().slice(0, 10) !== from || toDate.toISOString().slice(0, 10) !== to) return NextResponse.json({ error: "Choose a valid date range of up to 367 days" }, { status: 400 });

  const account = await db.account.findFirst({ where: { id, organizationId: user.organizationId } });
  if (!account) return NextResponse.json({ error: "Account not found" }, { status: 404 });
  const toExclusive = new Date(toDate.getTime() + 86400000);
  const journalFilter = { organizationId: user.organizationId, status: "POSTED" as const };
  const [opening, lines] = await Promise.all([
    db.journalLine.aggregate({ where: { accountId: account.id, journalEntry: { ...journalFilter, entryDate: { lt: fromDate } } }, _sum: { debit: true, credit: true } }),
    db.journalLine.findMany({ where: { accountId: account.id, journalEntry: { ...journalFilter, entryDate: { gte: fromDate, lt: toExclusive } } }, include: { journalEntry: { select: { number: true, description: true, entryDate: true } } }, orderBy: [{ journalEntry: { entryDate: "asc" } }, { id: "asc" }] }),
  ]);
  const naturalDebit = account.type === "ASSET" || account.type === "EXPENSE";
  const openingDebit = Number(opening._sum.debit ?? 0);
  const openingCredit = Number(opening._sum.credit ?? 0);
  const roundMoney = (value: number) => Math.round(value * 100) / 100;
  const openingBalance = roundMoney(naturalDebit ? openingDebit - openingCredit : openingCredit - openingDebit);
  let runningBalance = openingBalance;
  const transactions = lines.map((line) => {
    const debit = Number(line.debit);
    const credit = Number(line.credit);
    runningBalance = roundMoney(runningBalance + (naturalDebit ? debit - credit : credit - debit));
    return { id: line.id, date: line.journalEntry.entryDate, number: line.journalEntry.number, description: line.journalEntry.description, memo: line.memo, debit: roundMoney(debit), credit: roundMoney(credit), balance: runningBalance };
  });
  return NextResponse.json({ account: { id: account.id, code: account.code, name: account.name, type: account.type }, from, to, openingBalance, closingBalance: runningBalance, transactions });
}
