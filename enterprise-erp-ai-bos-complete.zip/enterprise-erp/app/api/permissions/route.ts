import { NextResponse } from "next/server";
import type { RoleName } from "@/generated/prisma/client";
import { getCurrentUser } from "@/lib/auth";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";
import { defaultPermissions, editableRoles, permissionCatalog } from "@/lib/permissions";
import { readObject } from "@/lib/validation";

function isAdmin(role: RoleName) {
  return role === "ADMIN" || role === "SUPER_ADMIN";
}

function resolvedPermissions(role: typeof editableRoles[number], overrides: unknown) {
  const configured = overrides && typeof overrides === "object" && !Array.isArray(overrides)
    ? (overrides as Record<string, unknown>)[role]
    : null;
  const grants = Array.isArray(configured) && configured.every((item) => typeof item === "string")
    ? configured as string[]
    : defaultPermissions[role];
  return permissionCatalog.filter((permission) => grants.some((grant) => grant === permission || (grant.endsWith(".*") && permission.startsWith(grant.slice(0, -1)))));
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!isAdmin(user.role)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  return NextResponse.json({
    roles: editableRoles.map((role) => ({ role, permissions: resolvedPermissions(role, user.organization.rolePermissions) })),
    availablePermissions: permissionCatalog,
  });
}

export async function PUT(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!isAdmin(user.role)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  const raw = body && readObject(body.permissions);
  if (!raw) return NextResponse.json({ error: "Provide role permissions" }, { status: 400 });

  const normalized: Record<string, string[]> = {};
  for (const role of editableRoles) {
    const grants = raw[role];
    if (!Array.isArray(grants) || grants.some((grant) => typeof grant !== "string" || !permissionCatalog.includes(grant as typeof permissionCatalog[number]))) {
      return NextResponse.json({ error: `Choose valid permissions for ${role.replaceAll("_", " ")}` }, { status: 400 });
    }
    normalized[role] = [...new Set(grants as string[])];
  }
  if (Object.keys(raw).some((role) => !editableRoles.includes(role as typeof editableRoles[number]))) {
    return NextResponse.json({ error: "Administrator roles cannot be customized here" }, { status: 400 });
  }

  try {
    const organization = await db.$transaction(async (tx) => {
      const current = await tx.organization.findUnique({ where: { id: user.organizationId }, select: { rolePermissions: true } });
      if (!current) throw new Error("ORGANIZATION_NOT_FOUND");
      const updated = await tx.organization.update({ where: { id: user.organizationId }, data: { rolePermissions: normalized } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "RolePermissions", entityId: user.organizationId, beforeData: { configured: current.rolePermissions !== null }, afterData: { permissions: normalized }, ipAddress: requestIp(request) });
      return updated;
    });
    return NextResponse.json({ roles: editableRoles.map((role) => ({ role, permissions: resolvedPermissions(role, organization.rolePermissions) })) });
  } catch {
    return NextResponse.json({ error: "Unable to save role permissions" }, { status: 500 });
  }
}
