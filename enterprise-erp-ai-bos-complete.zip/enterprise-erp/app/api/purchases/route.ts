import { randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { readEmail, readObject, readOptionalText, readText } from "@/lib/validation";
import { notifyRoles } from "@/lib/notifications";

function number(prefix: string) {
  return `${prefix}-${new Date().getFullYear()}-${randomBytes(3).toString("hex").toUpperCase()}`;
}

function money(cents: number) {
  return `${Math.floor(cents / 100)}.${String(cents % 100).padStart(2, "0")}`;
}

function dateOnly(value: unknown) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const date = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value ? date : null;
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "purchases.read", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const [suppliers, orders, products, warehouses, supplierInvoices] = await Promise.all([
    db.supplier.findMany({ where: { organizationId: user.organizationId }, orderBy: { name: "asc" } }),
    db.purchaseOrder.findMany({ where: { organizationId: user.organizationId }, include: { supplier: true, lines: { include: { product: true, receipts: true } }, receipts: { include: { warehouse: true, lines: true }, orderBy: { receivedAt: "desc" } } }, orderBy: { createdAt: "desc" }, take: 100 }),
    db.product.findMany({ where: { organizationId: user.organizationId, active: true }, select: { id: true, name: true, sku: true, costPrice: true } }),
    db.warehouse.findMany({ where: { organizationId: user.organizationId }, select: { id: true, name: true }, orderBy: { name: "asc" } }),
    db.supplierInvoice.findMany({ where: { organizationId: user.organizationId }, include: { supplier: true, purchaseOrder: { select: { id: true, number: true } }, payments: { orderBy: { paidAt: "desc" } } }, orderBy: { createdAt: "desc" }, take: 100 }),
  ]);
  return NextResponse.json({ suppliers, orders, products, warehouses, supplierInvoices });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const action = body.action;

  if (action === "supplier") {
    if (!hasPermission(user.role, "purchases.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const name = readText(body.name, "Supplier name", 2, 120);
    const email = body.email ? readEmail(body.email) : { data: null, error: null };
    const phone = readOptionalText(body.phone, "Phone", 40);
    const taxId = readOptionalText(body.taxId, "GST/VAT number", 40);
    if (name.error || email.error || phone.error || taxId.error) return NextResponse.json({ error: name.error ?? email.error ?? phone.error ?? taxId.error }, { status: 400 });
    try {
      const supplier = await db.$transaction(async (tx) => {
        const created = await tx.supplier.create({ data: { organizationId: user.organizationId, name: name.data, email: email.data?.toLowerCase() ?? null, phone: phone.data, taxId: taxId.data } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "Supplier", entityId: created.id, afterData: { name: created.name }, ipAddress: requestIp(request) });
        return created;
      });
      return NextResponse.json({ supplier }, { status: 201 });
    } catch (error) {
      if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "A supplier with this name already exists" }, { status: 409 });
      return NextResponse.json({ error: "Unable to create supplier" }, { status: 500 });
    }
  }

  if (action === "supplier-invoice") {
    if (!hasPermission(user.role, "purchases.invoice", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const supplierId = readText(body.supplierId, "Supplier", 1, 100);
    const numberValue = readText(body.number, "Supplier invoice number", 1, 100);
    const purchaseOrderId = body.purchaseOrderId ? readText(body.purchaseOrderId, "Purchase order", 1, 100) : { data: null, error: null };
    const notes = readOptionalText(body.notes, "Notes", 1000);
    const amount = Number(body.amount);
    const hasDueDate = body.dueDate !== undefined && body.dueDate !== null && body.dueDate !== "";
    const dueDate = hasDueDate ? dateOnly(body.dueDate) : null;
    const error = supplierId.error ?? numberValue.error ?? purchaseOrderId.error ?? notes.error;
    if (error || !Number.isFinite(amount) || amount <= 0 || amount > 1_000_000_000 || (hasDueDate && !dueDate)) return NextResponse.json({ error: error ?? "Enter a valid positive amount and due date" }, { status: 400 });
    const supplier = await db.supplier.findFirst({ where: { id: supplierId.data, organizationId: user.organizationId } });
    if (!supplier) return NextResponse.json({ error: "Supplier not found in your workspace" }, { status: 404 });
    if (!supplier.active) return NextResponse.json({ error: "Supplier is archived. Restore it before recording a new invoice." }, { status: 409 });
    let order = null;
    if (purchaseOrderId.data) {
      order = await db.purchaseOrder.findFirst({ where: { id: purchaseOrderId.data, organizationId: user.organizationId, supplierId: supplier.id } });
      if (!order || ["DRAFT", "APPROVED", "CANCELLED"].includes(order.status)) return NextResponse.json({ error: "Choose a supplier order that has been placed or received" }, { status: 400 });
    }
    const accounts = await db.account.findMany({ where: { organizationId: user.organizationId, code: { in: ["1200", "2000"] }, active: true } });
    const inventory = accounts.find((account) => account.code === "1200");
    const payables = accounts.find((account) => account.code === "2000");
    if (!inventory || !payables) return NextResponse.json({ error: "Inventory and accounts payable accounts are not configured" }, { status: 500 });
    const cents = Math.round(amount * 100);
    try {
      const invoice = await db.$transaction(async (tx) => {
        const entry = await tx.journalEntry.create({ data: { organizationId: user.organizationId, postedById: user.id, number: number("JE"), description: `Supplier invoice ${numberValue.data} from ${supplier.name}`, lines: { create: [{ accountId: inventory.id, debit: money(cents), credit: "0" }, { accountId: payables.id, debit: "0", credit: money(cents) }] } } });
        const created = await tx.supplierInvoice.create({ data: { organizationId: user.organizationId, supplierId: supplier.id, purchaseOrderId: order?.id, journalEntryId: entry.id, number: numberValue.data, currency: user.organization.currency, amount: money(cents), dueDate, notes: notes.data }, include: { supplier: true, purchaseOrder: { select: { id: true, number: true } }, payments: true } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "SupplierInvoice", entityId: created.id, afterData: { number: created.number, amount: cents / 100, supplier: supplier.name, journalEntry: entry.number }, ipAddress: requestIp(request) });
        await notifyRoles(tx, user.organizationId, ["ADMIN", "MANAGER"], "Supplier invoice recorded", `${supplier.name}: ${numberValue.data} (${user.organization.currency} ${money(cents)}).`, "/purchases");
        return created;
      });
      return NextResponse.json({ supplierInvoice: invoice }, { status: 201 });
    } catch (cause) {
      if (cause instanceof Error && "code" in cause && cause.code === "P2002") return NextResponse.json({ error: "This supplier invoice number already exists" }, { status: 409 });
      return NextResponse.json({ error: "Unable to record supplier invoice" }, { status: 500 });
    }
  }

  if (action === "supplier-payment") {
    if (!hasPermission(user.role, "purchases.pay", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const invoiceId = readText(body.supplierInvoiceId, "Supplier invoice", 1, 100);
    const reference = readOptionalText(body.reference, "Payment reference", 100);
    const amount = Number(body.amount);
    const methods = ["BANK_TRANSFER", "CASH", "CARD", "UPI", "CHEQUE", "OTHER"] as const;
    const method = body.method;
    if (invoiceId.error || reference.error || !Number.isFinite(amount) || amount <= 0 || !methods.includes(method as typeof methods[number])) return NextResponse.json({ error: invoiceId.error ?? reference.error ?? "Enter a valid amount and payment method" }, { status: 400 });
    const cents = Math.round(amount * 100);
    const invoice = await db.supplierInvoice.findFirst({ where: { id: invoiceId.data, organizationId: user.organizationId } });
    if (!invoice) return NextResponse.json({ error: "Supplier invoice not found" }, { status: 404 });
    const [payables, bank] = await Promise.all([
      db.account.findFirst({ where: { organizationId: user.organizationId, code: "2000", active: true } }),
      db.account.findFirst({ where: { organizationId: user.organizationId, code: "1000", active: true } }),
    ]);
    if (!payables || !bank) return NextResponse.json({ error: "Accounts payable and cash/bank accounts are not configured" }, { status: 500 });
    try {
      const payment = await db.$transaction(async (tx) => {
        const current = await tx.supplierInvoice.findFirst({ where: { id: invoice.id, organizationId: user.organizationId } });
        if (!current) throw new Error("INVOICE_NOT_FOUND");
        const outstanding = Math.round((Number(current.amount) - Number(current.paidAmount)) * 100);
        if (cents > outstanding || outstanding <= 0) throw new Error("OVERPAYMENT");
        const entry = await tx.journalEntry.create({ data: { organizationId: user.organizationId, postedById: user.id, number: number("JE"), description: `Payment for supplier invoice ${current.number}`, lines: { create: [{ accountId: payables.id, debit: money(cents), credit: "0" }, { accountId: bank.id, debit: "0", credit: money(cents) }] } } });
        const created = await tx.supplierPayment.create({ data: { organizationId: user.organizationId, supplierInvoiceId: current.id, journalEntryId: entry.id, amount: money(cents), method: method as typeof methods[number], reference: reference.data } });
        const paidCents = Math.round(Number(current.paidAmount) * 100) + cents;
        const status = paidCents === Math.round(Number(current.amount) * 100) ? "PAID" : "PARTIALLY_PAID";
        await tx.supplierInvoice.update({ where: { id: current.id }, data: { paidAmount: money(paidCents), status } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "SupplierPayment", entityId: created.id, afterData: { invoiceNumber: current.number, amount: cents / 100, journalEntry: entry.number }, ipAddress: requestIp(request) });
        return created;
      }, { isolationLevel: "Serializable" });
      return NextResponse.json({ payment }, { status: 201 });
    } catch (cause) {
      if (cause instanceof Error && cause.message === "OVERPAYMENT") return NextResponse.json({ error: "Payment exceeds the outstanding invoice balance" }, { status: 409 });
      if (cause instanceof Error && "code" in cause && cause.code === "P2034") return NextResponse.json({ error: "Invoice changed during payment. Refresh and try again." }, { status: 409 });
      return NextResponse.json({ error: "Unable to record supplier payment" }, { status: 500 });
    }
  }

  if (action === "order") {
    if (!hasPermission(user.role, "purchases.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const supplierId = readText(body.supplierId, "Supplier", 1, 100);
    const notes = readOptionalText(body.notes, "Notes", 2000);
    const rawLines = Array.isArray(body.lines) ? body.lines : [];
    if (supplierId.error || notes.error || rawLines.length < 1 || rawLines.length > 100) return NextResponse.json({ error: supplierId.error ?? notes.error ?? "An order must contain between 1 and 100 items" }, { status: 400 });
    const parsedLines = rawLines.map((raw) => {
      const line = readObject(raw);
      if (!line) return null;
      const productId = readText(line.productId, "Product", 1, 100);
      const quantity = Number(line.quantity);
      const unitCost = Number(line.unitCost);
      const taxRate = Number(line.taxRate ?? 0);
      if (productId.error || !Number.isInteger(quantity) || quantity < 1 || quantity > 100000 || !Number.isFinite(unitCost) || unitCost < 0 || !Number.isFinite(taxRate) || taxRate < 0 || taxRate > 100) return null;
      return { productId: productId.data, quantity, unitCostCents: Math.round(unitCost * 100), taxRate };
    });
    if (parsedLines.some((line) => !line)) return NextResponse.json({ error: "Each item needs a valid product, quantity, unit cost and tax rate" }, { status: 400 });
    const supplier = await db.supplier.findFirst({ where: { id: supplierId.data, organizationId: user.organizationId } });
    if (!supplier) return NextResponse.json({ error: "Supplier not found in your workspace" }, { status: 404 });
    if (!supplier.active) return NextResponse.json({ error: "Supplier is archived. Restore it before creating a purchase order." }, { status: 409 });
    const productIds = [...new Set(parsedLines.map((line) => line!.productId))];
    const products = await db.product.findMany({ where: { id: { in: productIds }, organizationId: user.organizationId, active: true } });
    const productMap = new Map(products.map((product) => [product.id, product]));
    if (products.length !== productIds.length) return NextResponse.json({ error: "One or more products were not found in your workspace" }, { status: 404 });
    const lines = parsedLines.map((raw) => {
      const line = raw!;
      const product = productMap.get(line.productId)!;
      const baseCents = line.unitCostCents * line.quantity;
      const taxCents = Math.round(baseCents * line.taxRate / 100);
      return { productId: product.id, description: product.name, quantity: line.quantity, unitCost: money(line.unitCostCents), taxRate: money(Math.round(line.taxRate * 100)), lineTotal: money(baseCents + taxCents), baseCents, taxCents };
    });
    const subtotal = lines.reduce((sum, line) => sum + line.baseCents, 0);
    const taxAmount = lines.reduce((sum, line) => sum + line.taxCents, 0);
    const order = await db.$transaction(async (tx) => {
      const created = await tx.purchaseOrder.create({ data: { organizationId: user.organizationId, supplierId: supplier.id, number: number("PO"), currency: user.organization.currency, subtotal: money(subtotal), taxAmount: money(taxAmount), total: money(subtotal + taxAmount), notes: notes.data, lines: { create: lines.map(({ baseCents: _base, taxCents: _tax, ...line }) => line) } }, include: { lines: true, supplier: true } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "PurchaseOrder", entityId: created.id, afterData: { number: created.number, total: Number(created.total) }, ipAddress: requestIp(request) });
      return created;
    });
    return NextResponse.json({ order }, { status: 201 });
  }

  if (action === "approve-order") {
    if (!hasPermission(user.role, "purchases.approve", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const id = readText(body.id, "Purchase order", 1, 100);
    if (id.error) return NextResponse.json({ error: id.error }, { status: 400 });
    const order = await db.purchaseOrder.findFirst({ where: { id: id.data, organizationId: user.organizationId } });
    if (!order) return NextResponse.json({ error: "Purchase order not found" }, { status: 404 });
    if (order.status !== "DRAFT") return NextResponse.json({ error: "Only draft purchase orders can be approved" }, { status: 409 });
    const supplier = await db.supplier.findFirst({ where: { id: order.supplierId, organizationId: user.organizationId, active: true }, select: { id: true } });
    if (!supplier) return NextResponse.json({ error: "Restore the archived supplier before approving this order." }, { status: 409 });
    const updated = await db.$transaction(async (tx) => {
      const changed = await tx.purchaseOrder.updateMany({ where: { id: order.id, organizationId: user.organizationId, status: "DRAFT" }, data: { status: "APPROVED" } });
      if (!changed.count) return null;
      const approved = await tx.purchaseOrder.findUniqueOrThrow({ where: { id: order.id } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "APPROVE", entity: "PurchaseOrder", entityId: order.id, beforeData: { status: order.status }, afterData: { status: approved.status }, ipAddress: requestIp(request) });
      return approved;
    });
    if (!updated) return NextResponse.json({ error: "Order changed during approval. Refresh and try again." }, { status: 409 });
    return NextResponse.json({ order: updated });
  }

  if (action === "place-order") {
    if (!hasPermission(user.role, "purchases.approve", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const id = readText(body.id, "Purchase order", 1, 100);
    if (id.error) return NextResponse.json({ error: id.error }, { status: 400 });
    const order = await db.purchaseOrder.findFirst({ where: { id: id.data, organizationId: user.organizationId } });
    if (!order) return NextResponse.json({ error: "Purchase order not found" }, { status: 404 });
    if (order.status !== "APPROVED") return NextResponse.json({ error: "Approve the purchase order before placing it with the supplier" }, { status: 409 });
    const supplier = await db.supplier.findFirst({ where: { id: order.supplierId, organizationId: user.organizationId, active: true }, select: { id: true } });
    if (!supplier) return NextResponse.json({ error: "Restore the archived supplier before placing this order." }, { status: 409 });
    const updated = await db.$transaction(async (tx) => {
      const changed = await tx.purchaseOrder.updateMany({ where: { id: order.id, organizationId: user.organizationId, status: "APPROVED" }, data: { status: "ORDERED" } });
      if (!changed.count) return null;
      const placed = await tx.purchaseOrder.findUniqueOrThrow({ where: { id: order.id } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "PurchaseOrder", entityId: order.id, beforeData: { status: order.status }, afterData: { status: placed.status, supplier: order.supplierId }, ipAddress: requestIp(request) });
      return placed;
    });
    if (!updated) return NextResponse.json({ error: "Order changed during placement. Refresh and try again." }, { status: 409 });
    return NextResponse.json({ order: updated });
  }

  if (action === "cancel-order") {
    if (!hasPermission(user.role, "purchases.approve", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const id = readText(body.id, "Purchase order", 1, 100);
    if (id.error) return NextResponse.json({ error: id.error }, { status: 400 });
    try {
      const cancelled = await db.$transaction(async (tx) => {
        const order = await tx.purchaseOrder.findFirst({ where: { id: id.data, organizationId: user.organizationId }, include: { receipts: { select: { id: true } } } });
        if (!order) throw new Error("ORDER_NOT_FOUND");
        if (!["DRAFT", "APPROVED", "ORDERED"].includes(order.status) || order.receipts.length) throw new Error("ORDER_CANNOT_CANCEL");
        const changed = await tx.purchaseOrder.updateMany({ where: { id: order.id, organizationId: user.organizationId, status: order.status }, data: { status: "CANCELLED" } });
        if (!changed.count) throw new Error("ORDER_STATE_CHANGED");
        const updated = await tx.purchaseOrder.findUniqueOrThrow({ where: { id: order.id } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "PurchaseOrder", entityId: order.id, beforeData: { status: order.status }, afterData: { status: updated.status }, ipAddress: requestIp(request) });
        return updated;
      }, { isolationLevel: "Serializable" });
      return NextResponse.json({ order: cancelled });
    } catch (error) {
      if (error instanceof Error && error.message === "ORDER_NOT_FOUND") return NextResponse.json({ error: "Purchase order not found" }, { status: 404 });
      if (error instanceof Error && error.message === "ORDER_CANNOT_CANCEL") return NextResponse.json({ error: "Only orders with no goods receipts can be cancelled" }, { status: 409 });
      if (error instanceof Error && error.message === "ORDER_STATE_CHANGED") return NextResponse.json({ error: "Order changed during cancellation. Refresh and try again." }, { status: 409 });
      if (error instanceof Error && "code" in error && error.code === "P2034") return NextResponse.json({ error: "Order changed during cancellation. Refresh and try again." }, { status: 409 });
      throw error;
    }
  }

  if (action === "receive") {
    if (!hasPermission(user.role, "purchases.receive", user.organization.rolePermissions) || !hasPermission(user.role, "inventory.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const orderId = readText(body.orderId, "Purchase order", 1, 100);
    const warehouseId = readText(body.warehouseId, "Warehouse", 1, 100);
    const rawQuantities = readObject(body.quantities);
    if (orderId.error || warehouseId.error || !rawQuantities || Object.keys(rawQuantities).length === 0) return NextResponse.json({ error: orderId.error ?? warehouseId.error ?? "Enter received quantities" }, { status: 400 });
    try {
      const receipt = await db.$transaction(async (tx) => {
        const order = await tx.purchaseOrder.findFirst({ where: { id: orderId.data, organizationId: user.organizationId }, include: { lines: { include: { receipts: true } } } });
        if (!order) throw new Error("ORDER_NOT_FOUND");
        if (!["ORDERED", "PARTIALLY_RECEIVED"].includes(order.status)) throw new Error("ORDER_NOT_OPEN");
        const warehouse = await tx.warehouse.findFirst({ where: { id: warehouseId.data, organizationId: user.organizationId } });
        if (!warehouse) throw new Error("WAREHOUSE_NOT_FOUND");
        const receivedLines: { purchaseOrderLineId: string; productId: string; quantity: number }[] = [];
        for (const [lineId, rawQuantity] of Object.entries(rawQuantities)) {
          const line = order.lines.find((item) => item.id === lineId);
          const quantity = Number(rawQuantity);
          if (!line || !Number.isInteger(quantity) || quantity < 1) throw new Error("INVALID_RECEIVED_QUANTITY");
          const alreadyReceived = line.receipts.reduce((sum, item) => sum + item.quantity, 0);
          if (alreadyReceived + quantity > line.quantity) throw new Error("OVER_RECEIVED");
          receivedLines.push({ purchaseOrderLineId: line.id, productId: line.productId, quantity });
        }
        const activeProductCount = await tx.product.count({ where: { id: { in: [...new Set(receivedLines.map((line) => line.productId))] }, organizationId: user.organizationId, active: true } });
        if (activeProductCount !== new Set(receivedLines.map((line) => line.productId)).size) throw new Error("PRODUCT_ARCHIVED");
        const created = await tx.goodsReceipt.create({ data: { organizationId: user.organizationId, purchaseOrderId: order.id, warehouseId: warehouse.id, number: number("GR"), lines: { create: receivedLines } }, include: { lines: true, warehouse: true } });
        for (const line of receivedLines) {
          await tx.stockMovement.create({ data: { organizationId: user.organizationId, productId: line.productId, warehouseId: warehouse.id, type: "PURCHASE", quantity: line.quantity, reference: created.number, note: `Received from ${order.number}` } });
        }
        const fullOrder = order.lines.every((line) => {
          const current = line.receipts.reduce((sum, item) => sum + item.quantity, 0);
          const additional = receivedLines.find((received) => received.purchaseOrderLineId === line.id)?.quantity ?? 0;
          return current + additional >= line.quantity;
        });
        const updatedOrder = await tx.purchaseOrder.update({ where: { id: order.id }, data: { status: fullOrder ? "RECEIVED" : "PARTIALLY_RECEIVED" } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "GoodsReceipt", entityId: created.id, afterData: { number: created.number, purchaseOrder: order.number, warehouse: warehouse.name }, ipAddress: requestIp(request) });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "PurchaseOrder", entityId: order.id, beforeData: { status: order.status }, afterData: { status: updatedOrder.status }, ipAddress: requestIp(request) });
        return created;
      }, { isolationLevel: "Serializable" });
      return NextResponse.json({ receipt }, { status: 201 });
    } catch (error) {
      if (error instanceof Error && error.message === "ORDER_NOT_FOUND") return NextResponse.json({ error: "Purchase order not found" }, { status: 404 });
      if (error instanceof Error && error.message === "ORDER_NOT_OPEN") return NextResponse.json({ error: "This order is not open for receiving" }, { status: 409 });
      if (error instanceof Error && error.message === "WAREHOUSE_NOT_FOUND") return NextResponse.json({ error: "Warehouse not found in your workspace" }, { status: 404 });
      if (error instanceof Error && error.message === "INVALID_RECEIVED_QUANTITY") return NextResponse.json({ error: "Received quantities must be positive whole numbers for items in this order" }, { status: 400 });
      if (error instanceof Error && error.message === "OVER_RECEIVED") return NextResponse.json({ error: "Received quantity exceeds the remaining quantity on the order" }, { status: 409 });
      if (error instanceof Error && error.message === "PRODUCT_ARCHIVED") return NextResponse.json({ error: "This order contains a product that has been archived. Restore it before receiving goods." }, { status: 409 });
      if (error instanceof Error && "code" in error && error.code === "P2034") return NextResponse.json({ error: "Order changed during receiving. Refresh and try again." }, { status: 409 });
      console.error("Goods receipt failed", error);
      return NextResponse.json({ error: "Unable to receive goods" }, { status: 500 });
    }
  }

  return NextResponse.json({ error: "Unknown purchase action" }, { status: 400 });
}

