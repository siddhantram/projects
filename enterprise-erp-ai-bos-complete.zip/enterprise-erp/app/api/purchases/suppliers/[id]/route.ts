import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import type { Prisma } from "@/generated/prisma/client";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { readEmail, readObject, readOptionalText, readText } from "@/lib/validation";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "purchases.update", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const { id } = await params;
  const existing = await db.supplier.findFirst({ where: { id, organizationId: user.organizationId } });
  if (!existing) return NextResponse.json({ error: "Supplier not found" }, { status: 404 });

  let data: { active: boolean } | { name: string; email: string | null; phone: string | null; taxId: string | null };
  let beforeData: Prisma.InputJsonObject;
  let afterData: Prisma.InputJsonObject;
  if (body.active !== undefined) {
    if (Object.keys(body).length !== 1 || typeof body.active !== "boolean") return NextResponse.json({ error: "Active status must be changed on its own" }, { status: 400 });
    data = { active: body.active };
    beforeData = { active: existing.active };
    afterData = { active: body.active };
  } else {
    const name = readText(body.name, "Supplier name", 2, 120);
    const email = body.email ? readEmail(body.email) : { data: null, error: null };
    const phone = readOptionalText(body.phone, "Phone", 40);
    const taxId = readOptionalText(body.taxId, "GST/VAT number", 40);
    const error = name.error ?? email.error ?? phone.error ?? taxId.error;
    if (error) return NextResponse.json({ error }, { status: 400 });
    const normalized = { name: name.data, email: email.data?.toLowerCase() ?? null, phone: phone.data, taxId: taxId.data };
    data = normalized;
    beforeData = { name: existing.name, email: existing.email, phone: existing.phone, taxId: existing.taxId };
    afterData = normalized;
  }

  try {
    const supplier = await db.$transaction(async (tx) => {
      const updated = await tx.supplier.update({ where: { id }, data });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "Supplier", entityId: id, beforeData, afterData, ipAddress: requestIp(request) });
      return updated;
    });
    return NextResponse.json({ supplier });
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "A supplier with this name already exists" }, { status: 409 });
    return NextResponse.json({ error: "Unable to update supplier" }, { status: 500 });
  }
}
