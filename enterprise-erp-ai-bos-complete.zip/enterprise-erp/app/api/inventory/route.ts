import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { readObject, readOptionalText, readText } from "@/lib/validation";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "inventory.read", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const [warehouses, movements, groupedStock] = await Promise.all([
    db.warehouse.findMany({ where: { organizationId: user.organizationId }, orderBy: { name: "asc" } }),
    db.stockMovement.findMany({ where: { organizationId: user.organizationId }, include: { product: true, warehouse: true }, orderBy: { createdAt: "desc" }, take: 100 }),
    db.stockMovement.groupBy({ by: ["productId", "warehouseId"], where: { organizationId: user.organizationId }, _sum: { quantity: true } }),
  ]);
  const balances = groupedStock.map((row) => ({ productId: row.productId, warehouseId: row.warehouseId, quantity: row._sum.quantity ?? 0 }));
  return NextResponse.json({ warehouses, movements, balances });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "inventory.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const productId = readText(body.productId, "Product", 1, 100);
  const warehouseId = readText(body.warehouseId, "Warehouse", 1, 100);
  const reference = readOptionalText(body.reference, "Reference", 100);
  const note = readOptionalText(body.note, "Note", 1000);
  const type = body.type;
  const quantity = Number(body.quantity);
  const kinds = ["OPENING", "RETURN", "ADJUSTMENT"] as const;
  if (productId.error || warehouseId.error || reference.error || note.error || !kinds.includes(type as typeof kinds[number]) || !Number.isSafeInteger(quantity) || Math.abs(quantity) > 2_147_483_647 || quantity === 0) {
    return NextResponse.json({ error: "Provide a product, warehouse, movement type and a non-zero whole-number quantity" }, { status: 400 });
  }
  const movementType = type as typeof kinds[number];
  const [product, warehouse] = await Promise.all([
    db.product.findFirst({ where: { id: productId.data, organizationId: user.organizationId } }),
    db.warehouse.findFirst({ where: { id: warehouseId.data, organizationId: user.organizationId } }),
  ]);
  if (!product?.active || !warehouse) return NextResponse.json({ error: "Active product or warehouse was not found in your workspace" }, { status: 404 });
  const signedQuantity = movementType === "ADJUSTMENT" ? quantity : Math.abs(quantity);
  try {
    const movement = await db.$transaction(async (tx) => {
      const activeProduct = await tx.product.findFirst({ where: { id: product.id, organizationId: user.organizationId, active: true }, select: { id: true } });
      if (!activeProduct) throw new Error("PRODUCT_ARCHIVED");
      if (signedQuantity < 0) {
        const current = await tx.stockMovement.aggregate({ where: { organizationId: user.organizationId, productId: product.id, warehouseId: warehouse.id }, _sum: { quantity: true } });
        if ((current._sum.quantity ?? 0) + signedQuantity < 0) throw new Error("INSUFFICIENT_STOCK");
      }
      const movement = await tx.stockMovement.create({ data: { organizationId: user.organizationId, productId: product.id, warehouseId: warehouse.id, type: movementType, quantity: signedQuantity, reference: reference.data, note: note.data } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "StockMovement", entityId: movement.id, afterData: { productId: product.id, warehouseId: warehouse.id, type: movementType, quantity: signedQuantity }, ipAddress: requestIp(request) });
      return movement;
    }, { isolationLevel: "Serializable" });
    return NextResponse.json({ movement }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message === "PRODUCT_ARCHIVED") return NextResponse.json({ error: "Archived products cannot receive stock movements" }, { status: 409 });
    if (error instanceof Error && error.message === "INSUFFICIENT_STOCK") return NextResponse.json({ error: "This movement would reduce stock below zero" }, { status: 409 });
    if (error instanceof Error && "code" in error && error.code === "P2034") return NextResponse.json({ error: "Stock changed during this request. Refresh and try again." }, { status: 409 });
    console.error("Inventory movement failed", error);
    return NextResponse.json({ error: "Unable to record stock movement" }, { status: 500 });
  }
}
