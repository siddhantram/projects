import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { readObject, readOptionalText, readText } from "@/lib/validation";

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "inventory.create", user.organization.rolePermissions)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });

  const productId = readText(body.productId, "Product", 1, 100);
  const sourceWarehouseId = readText(body.sourceWarehouseId, "Source warehouse", 1, 100);
  const destinationWarehouseId = readText(body.destinationWarehouseId, "Destination warehouse", 1, 100);
  const reference = readOptionalText(body.reference, "Reference", 100);
  const note = readOptionalText(body.note, "Note", 1000);
  const quantity = Number(body.quantity);
  if (productId.error || sourceWarehouseId.error || destinationWarehouseId.error || reference.error || note.error ||
      sourceWarehouseId.data === destinationWarehouseId.data || !Number.isSafeInteger(quantity) || quantity <= 0 || quantity > 2_147_483_647) {
    return NextResponse.json({ error: "Choose a product, two different warehouses, and a positive whole-number quantity" }, { status: 400 });
  }

  const [product, source, destination] = await Promise.all([
    db.product.findFirst({ where: { id: productId.data, organizationId: user.organizationId, active: true }, select: { id: true } }),
    db.warehouse.findFirst({ where: { id: sourceWarehouseId.data, organizationId: user.organizationId }, select: { id: true, name: true } }),
    db.warehouse.findFirst({ where: { id: destinationWarehouseId.data, organizationId: user.organizationId }, select: { id: true, name: true } }),
  ]);
  if (!product || !source || !destination) {
    return NextResponse.json({ error: "Active product and both warehouses must belong to your workspace" }, { status: 404 });
  }

  try {
    const transfer = await db.$transaction(async (tx) => {
      const activeProduct = await tx.product.findFirst({ where: { id: product.id, organizationId: user.organizationId, active: true }, select: { id: true } });
      if (!activeProduct) throw new Error("PRODUCT_ARCHIVED");
      const current = await tx.stockMovement.aggregate({
        where: { organizationId: user.organizationId, productId: product.id, warehouseId: source.id },
        _sum: { quantity: true },
      });
      if ((current._sum.quantity ?? 0) < quantity) throw new Error("INSUFFICIENT_STOCK");

      const transferRef = reference.data ?? `TRANSFER-${Date.now()}`;
      const movements = await Promise.all([
        tx.stockMovement.create({ data: {
          organizationId: user.organizationId, productId: product.id, warehouseId: source.id,
          type: "TRANSFER_OUT", quantity: -quantity, reference: transferRef,
          note: note.data ?? `Transfer to ${destination.name}`,
        } }),
        tx.stockMovement.create({ data: {
          organizationId: user.organizationId, productId: product.id, warehouseId: destination.id,
          type: "TRANSFER_IN", quantity, reference: transferRef,
          note: note.data ?? `Transfer from ${source.name}`,
        } }),
      ]);
      await writeAuditLog(tx, {
        organizationId: user.organizationId, userId: user.id, action: "CREATE",
        entity: "StockTransfer", entityId: transferRef,
        afterData: { productId: product.id, sourceWarehouseId: source.id, destinationWarehouseId: destination.id, quantity, movementIds: movements.map((movement) => movement.id) },
        ipAddress: requestIp(request),
      });
      return movements;
    }, { isolationLevel: "Serializable" });
    return NextResponse.json({ movements: transfer }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message === "PRODUCT_ARCHIVED") {
      return NextResponse.json({ error: "Archived products cannot be transferred" }, { status: 409 });
    }
    if (error instanceof Error && error.message === "INSUFFICIENT_STOCK") {
      return NextResponse.json({ error: "Source warehouse does not have enough stock" }, { status: 409 });
    }
    if (error instanceof Error && "code" in error && error.code === "P2034") {
      return NextResponse.json({ error: "Stock changed during this transfer. Refresh and try again." }, { status: 409 });
    }
    console.error("Inventory transfer failed", error);
    return NextResponse.json({ error: "Unable to transfer stock" }, { status: 500 });
  }
}
