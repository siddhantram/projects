import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { readObject, readOptionalText, readText } from "@/lib/validation";

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "inventory.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const name = readText(body.name, "Warehouse name", 2, 100);
  const location = readOptionalText(body.location, "Location", 160);
  if (name.error || location.error) return NextResponse.json({ error: name.error ?? location.error }, { status: 400 });
  try {
    const warehouse = await db.$transaction(async (tx) => {
      const created = await tx.warehouse.create({ data: { organizationId: user.organizationId, name: name.data, location: location.data } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "Warehouse", entityId: created.id, afterData: { name: created.name, location: created.location }, ipAddress: requestIp(request) });
      return created;
    });
    return NextResponse.json({ warehouse }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "A warehouse with this name already exists" }, { status: 409 });
    return NextResponse.json({ error: "Unable to create warehouse" }, { status: 500 });
  }
}
