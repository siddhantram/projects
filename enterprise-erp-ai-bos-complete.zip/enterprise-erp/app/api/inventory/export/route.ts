import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { requestIp, writeAuditLog } from "@/lib/audit";

function csvCell(value: string | number) {
  let text = String(value);
  if (typeof value === "string" && /^[\s]*[=+@\-]/.test(text)) text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
}

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "inventory.read", user.organization.rolePermissions)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const [products, warehouses, groupedStock] = await Promise.all([
    db.product.findMany({ where: { organizationId: user.organizationId, active: true }, orderBy: [{ sku: "asc" }] }),
    db.warehouse.findMany({ where: { organizationId: user.organizationId }, orderBy: [{ name: "asc" }] }),
    db.stockMovement.groupBy({ by: ["productId", "warehouseId"], where: { organizationId: user.organizationId }, _sum: { quantity: true } }),
  ]);
  const stockByLocation = new Map(groupedStock.map((row) => [`${row.productId}:${row.warehouseId}`, row._sum.quantity ?? 0]));
  const rows: (string | number)[][] = [["SKU", "Product", "Warehouse", "Location", "On hand", "Reorder level", "Stock status"]];

  for (const product of products) {
    for (const warehouse of warehouses) {
      const onHand = stockByLocation.get(`${product.id}:${warehouse.id}`) ?? 0;
      rows.push([product.sku, product.name, warehouse.name, warehouse.location ?? "", onHand, product.reorderLevel, onHand <= product.reorderLevel ? "LOW STOCK" : "OK"]);
    }
  }
  const csv = `\uFEFF${rows.map((row) => row.map(csvCell).join(",")).join("\r\n")}`;
  await db.auditLog.create({ data: {
    organizationId: user.organizationId, userId: user.id, action: "EXPORT", entity: "Inventory", ipAddress: requestIp(request),
    afterData: { activeProducts: products.length, warehouses: warehouses.length, rows: rows.length - 1 },
  } });
  const date = new Intl.DateTimeFormat("en-CA", { timeZone: user.organization.timezone }).format(new Date());
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="inventory-${date}.csv"`,
      "Cache-Control": "no-store",
    },
  });
}
