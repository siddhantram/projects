import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { readObject, readText } from "@/lib/validation";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "notifications.read", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const notifications = await db.notification.findMany({ where: { organizationId: user.organizationId, userId: user.id }, orderBy: { createdAt: "desc" }, take: 100 });
  return NextResponse.json({ notifications, unreadCount: notifications.filter((notification) => !notification.readAt).length });
}

export async function PATCH(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "notifications.read", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  if (body.action === "read-all") {
    const result = await db.notification.updateMany({ where: { organizationId: user.organizationId, userId: user.id, readAt: null }, data: { readAt: new Date() } });
    return NextResponse.json({ updated: result.count });
  }
  const id = readText(body.id, "Notification", 1, 100);
  if (id.error) return NextResponse.json({ error: id.error }, { status: 400 });
  const result = await db.notification.updateMany({ where: { id: id.data, organizationId: user.organizationId, userId: user.id, readAt: null }, data: { readAt: new Date() } });
  return NextResponse.json({ updated: result.count });
}
