import { NextResponse } from "next/server";
import { hashPassword, getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { readEmail, readObject, readText } from "@/lib/validation";

const roles = ["SUPER_ADMIN", "ADMIN", "MANAGER", "ACCOUNTANT", "HR", "SALES", "INVENTORY_MANAGER", "EMPLOYEE"] as const;
function isOrgAdmin(role: string) { return role === "ADMIN" || role === "SUPER_ADMIN"; }

export async function GET() {
  const actor = await getCurrentUser();
  if (!actor) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!isOrgAdmin(actor.role)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const users = await db.user.findMany({ where: { organizationId: actor.organizationId }, select: { id: true, name: true, email: true, role: true, active: true, mfaEnabledAt: true, createdAt: true }, orderBy: { createdAt: "asc" } });
  return NextResponse.json({ users, roles });
}

export async function POST(request: Request) {
  const actor = await getCurrentUser();
  if (!actor) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!isOrgAdmin(actor.role)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const name = readText(body.name, "Name", 2, 120);
  const email = readEmail(body.email);
  const password = readText(body.password, "Initial password", 12, 200);
  const role = body.role;
  if (name.error || email.error || password.error || typeof role !== "string" || !roles.includes(role as typeof roles[number])) return NextResponse.json({ error: name.error ?? email.error ?? password.error ?? "Choose a valid role" }, { status: 400 });
  if (role === "SUPER_ADMIN" && actor.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Only a super administrator can grant the super administrator role" }, { status: 403 });
  try {
    const user = await db.$transaction(async (tx) => {
      const created = await tx.user.create({ data: { organizationId: actor.organizationId, name: name.data, email: email.data.toLowerCase(), passwordHash: await hashPassword(password.data), role: role as typeof roles[number] }, select: { id: true, name: true, email: true, role: true, active: true, createdAt: true } });
      await writeAuditLog(tx, { organizationId: actor.organizationId, userId: actor.id, action: "CREATE", entity: "User", entityId: created.id, afterData: { email: created.email, role: created.role }, ipAddress: requestIp(request) });
      return created;
    });
    return NextResponse.json({ user }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "An account with this email already exists" }, { status: 409 });
    return NextResponse.json({ error: "Unable to create user" }, { status: 500 });
  }
}
