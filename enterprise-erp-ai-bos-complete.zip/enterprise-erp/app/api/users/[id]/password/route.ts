import { NextResponse } from "next/server";
import { getCurrentUser, hashPassword } from "@/lib/auth";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";
import { readObject, readText } from "@/lib/validation";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const actor = await getCurrentUser();
  if (!actor) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!["ADMIN", "SUPER_ADMIN"].includes(actor.role)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const password = readText(body.password, "Temporary password", 12, 200);
  if (password.error) return NextResponse.json({ error: password.error }, { status: 400 });

  const target = await db.user.findFirst({ where: { id, organizationId: actor.organizationId }, select: { id: true, email: true, role: true } });
  if (!target) return NextResponse.json({ error: "User not found" }, { status: 404 });
  if (target.role === "SUPER_ADMIN" && actor.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Only a super administrator can reset this account" }, { status: 403 });

  const passwordHash = await hashPassword(password.data);
  await db.$transaction(async (tx) => {
    const updated = await tx.user.updateMany({ where: { id: target.id, organizationId: actor.organizationId }, data: { passwordHash } });
    if (!updated.count) throw new Error("USER_NOT_FOUND");
    await tx.session.deleteMany({ where: { userId: target.id } });
    await writeAuditLog(tx, { organizationId: actor.organizationId, userId: actor.id, action: "UPDATE", entity: "UserPassword", entityId: target.id, afterData: { passwordChanged: true, sessionsRevoked: true }, ipAddress: requestIp(request) });
  });
  return NextResponse.json({ message: `Temporary password set for ${target.email}; existing sessions were revoked.` });
}
