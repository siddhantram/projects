import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const actor = await getCurrentUser();
  if (!actor) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (actor.role !== "ADMIN" && actor.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  if (id === actor.id) return NextResponse.json({ error: "Use Settings to change your own MFA after verifying your password and authenticator code" }, { status: 409 });

  const target = await db.user.findFirst({ where: { id, organizationId: actor.organizationId }, select: { id: true, email: true, role: true, mfaEnabledAt: true, mfaSecretEncrypted: true } });
  if (!target) return NextResponse.json({ error: "User not found" }, { status: 404 });
  if (target.role === "SUPER_ADMIN" && actor.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Only a super administrator can reset this account's MFA" }, { status: 403 });

  await db.$transaction(async (tx) => {
    await tx.user.updateMany({ where: { id: target.id, organizationId: actor.organizationId }, data: { mfaEnabledAt: null, mfaSecretEncrypted: null } });
    await tx.mfaRecoveryCode.deleteMany({ where: { userId: target.id } });
    await tx.session.deleteMany({ where: { userId: target.id } });
    await writeAuditLog(tx, { organizationId: actor.organizationId, userId: actor.id, action: "UPDATE", entity: "UserMfa", entityId: target.id, beforeData: { enabled: Boolean(target.mfaEnabledAt) }, afterData: { enabled: false, recoveryCodesRevoked: true, sessionsRevoked: true }, ipAddress: requestIp(request) });
  });
  return NextResponse.json({ message: `MFA reset for ${target.email}. They must sign in again and may enroll MFA again.` });
}
