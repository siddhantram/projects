import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { readObject } from "@/lib/validation";

const roles = ["SUPER_ADMIN", "ADMIN", "MANAGER", "ACCOUNTANT", "HR", "SALES", "INVENTORY_MANAGER", "EMPLOYEE"] as const;

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const actor = await getCurrentUser();
  if (!actor) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!["ADMIN", "SUPER_ADMIN"].includes(actor.role)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  if (id === actor.id && (body.active === false || (body.role && body.role !== actor.role))) return NextResponse.json({ error: "You cannot deactivate or change your own role" }, { status: 409 });
  const target = await db.user.findFirst({ where: { id, organizationId: actor.organizationId } });
  if (!target) return NextResponse.json({ error: "User not found" }, { status: 404 });
  if (target.role === "SUPER_ADMIN" && actor.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Only a super administrator can update this account" }, { status: 403 });
  if (body.role !== undefined && (typeof body.role !== "string" || !roles.includes(body.role as typeof roles[number]))) return NextResponse.json({ error: "Choose a valid role" }, { status: 400 });
  if (body.role === "SUPER_ADMIN" && actor.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Only a super administrator can grant the super administrator role" }, { status: 403 });
  if (body.active !== undefined && typeof body.active !== "boolean") return NextResponse.json({ error: "Active must be true or false" }, { status: 400 });
  const role = (body.role as typeof roles[number] | undefined) ?? target.role;
  const active = (body.active as boolean | undefined) ?? target.active;
  try {
    const user = await db.$transaction(async (tx) => {
      const current = await tx.user.findFirst({ where: { id: target.id, organizationId: actor.organizationId } });
      if (!current) throw new Error("USER_NOT_FOUND");
      if (current.role === "SUPER_ADMIN" && actor.role !== "SUPER_ADMIN") throw new Error("SUPER_ADMIN_PROTECTED");
      if (current.active && (current.role === "ADMIN" || current.role === "SUPER_ADMIN") && (!active || !["ADMIN", "SUPER_ADMIN"].includes(role))) {
        const admins = await tx.user.count({ where: { organizationId: actor.organizationId, active: true, role: { in: ["ADMIN", "SUPER_ADMIN"] }, id: { not: current.id } } });
        if (!admins) throw new Error("LAST_ADMIN");
      }
      const updated = await tx.user.update({ where: { id: current.id }, data: { role, active }, select: { id: true, name: true, email: true, role: true, active: true, createdAt: true } });
      if (!active) await tx.session.deleteMany({ where: { userId: current.id } });
      await writeAuditLog(tx, { organizationId: actor.organizationId, userId: actor.id, action: "UPDATE", entity: "User", entityId: current.id, beforeData: { role: current.role, active: current.active }, afterData: { role: updated.role, active: updated.active }, ipAddress: requestIp(request) });
      return updated;
    }, { isolationLevel: "Serializable" });
    return NextResponse.json({ user });
  } catch (error) {
    if (error instanceof Error && error.message === "LAST_ADMIN") return NextResponse.json({ error: "The workspace must keep at least one active administrator" }, { status: 409 });
    if (error instanceof Error && error.message === "SUPER_ADMIN_PROTECTED") return NextResponse.json({ error: "Only a super administrator can update this account" }, { status: 403 });
    if (error instanceof Error && error.message === "USER_NOT_FOUND") return NextResponse.json({ error: "User not found" }, { status: 404 });
    if (error instanceof Error && "code" in error && error.code === "P2034") return NextResponse.json({ error: "User access changed at the same time. Refresh and try again." }, { status: 409 });
    return NextResponse.json({ error: "Unable to update account" }, { status: 500 });
  }
}
