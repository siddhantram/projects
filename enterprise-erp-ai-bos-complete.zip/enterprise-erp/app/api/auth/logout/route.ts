import { NextResponse } from "next/server";
import { destroySession, getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { requestIp } from "@/lib/audit";

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (user) await db.auditLog.create({ data: { organizationId: user.organizationId, userId: user.id, action: "LOGOUT", entity: "User", entityId: user.id, ipAddress: requestIp(request) } });
  await destroySession();
  return NextResponse.json({ success: true });
}
