import { NextResponse } from "next/server";
import { getCurrentSessionTokenHash, getCurrentUser, hashPassword, verifyPassword } from "@/lib/auth";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";
import { readObject, readText } from "@/lib/validation";

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const currentPassword = readText(body.currentPassword, "Current password", 1, 200);
  const newPassword = readText(body.newPassword, "New password", 12, 200);
  if (currentPassword.error || newPassword.error) return NextResponse.json({ error: currentPassword.error ?? newPassword.error }, { status: 400 });
  if (currentPassword.data === newPassword.data) return NextResponse.json({ error: "Choose a new password that differs from your current password" }, { status: 400 });
  if (!await verifyPassword(currentPassword.data, user.passwordHash)) return NextResponse.json({ error: "Current password is incorrect" }, { status: 400 });

  const currentSessionHash = await getCurrentSessionTokenHash();
  if (!currentSessionHash) return NextResponse.json({ error: "Session expired. Sign in again." }, { status: 401 });
  const passwordHash = await hashPassword(newPassword.data);
  await db.$transaction(async (tx) => {
    await tx.user.update({ where: { id: user.id }, data: { passwordHash } });
    await tx.session.deleteMany({ where: { userId: user.id, tokenHash: { not: currentSessionHash } } });
    await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "UserPassword", entityId: user.id, afterData: { passwordChanged: true, otherSessionsRevoked: true }, ipAddress: requestIp(request) });
  });
  return NextResponse.json({ message: "Password updated. Other active sessions have been signed out." });
}
