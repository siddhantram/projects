import { NextResponse } from "next/server";
import { createSession, hashPassword } from "@/lib/auth";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";
import { readEmail, readObject, readText } from "@/lib/validation";

export async function POST(request: Request) {
  if (process.env.NODE_ENV === "production" && process.env.ALLOW_PUBLIC_REGISTRATION !== "true") {
    return NextResponse.json({ error: "Public registration is disabled" }, { status: 403 });
  }
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });

  const organizationName = readText(body.organizationName, "Company name", 2, 120);
  const name = readText(body.name, "Name", 2, 120);
  const email = readEmail(body.email);
  const password = readText(body.password, "Password", 10, 200);
  const error = organizationName.error ?? name.error ?? email.error ?? password.error;
  if (error) return NextResponse.json({ error }, { status: 400 });

  try {
    const user = await db.$transaction(async (tx) => {
      const organization = await tx.organization.create({ data: { name: organizationName.data } });
      await tx.account.createMany({ data: [
        { organizationId: organization.id, code: "1000", name: "Cash and bank", type: "ASSET" },
        { organizationId: organization.id, code: "1100", name: "Accounts receivable", type: "ASSET" },
        { organizationId: organization.id, code: "1200", name: "Inventory", type: "ASSET" },
        { organizationId: organization.id, code: "2000", name: "Accounts payable", type: "LIABILITY" },
        { organizationId: organization.id, code: "2100", name: "Tax payable", type: "LIABILITY" },
        { organizationId: organization.id, code: "3000", name: "Owner equity", type: "EQUITY" },
        { organizationId: organization.id, code: "4000", name: "Sales revenue", type: "REVENUE" },
        { organizationId: organization.id, code: "5000", name: "Operating expenses", type: "EXPENSE" },
        { organizationId: organization.id, code: "5100", name: "Cost of goods sold", type: "EXPENSE" },
      ] });
      const user = await tx.user.create({
        data: {
          organizationId: organization.id,
          name: name.data,
          email: email.data,
          passwordHash: await hashPassword(password.data),
          role: "ADMIN",
        },
      });
      await writeAuditLog(tx, { organizationId: organization.id, userId: user.id, action: "CREATE", entity: "Organization", entityId: organization.id, afterData: { name: organization.name, initialSetup: true }, ipAddress: requestIp(request) });
      await writeAuditLog(tx, { organizationId: organization.id, userId: user.id, action: "CREATE", entity: "User", entityId: user.id, afterData: { email: user.email, role: user.role }, ipAddress: requestIp(request) });
      return user;
    });
    await createSession(user.id);
    return NextResponse.json({ user: { id: user.id, name: user.name, email: user.email } }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "P2002") {
      return NextResponse.json({ error: "An account with this email already exists" }, { status: 409 });
    }
    console.error("Registration failed", error);
    return NextResponse.json({ error: "Unable to create your account" }, { status: 500 });
  }
}
