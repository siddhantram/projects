import { createHash } from "node:crypto";
import { NextResponse } from "next/server";
import { requestIp } from "@/lib/audit";
import { db } from "@/lib/db";
import { hashPassword } from "@/lib/auth";
import { readObject, readText } from "@/lib/validation";

export async function POST(request: Request) {
  const contentLength = Number(request.headers.get("content-length") ?? 0);
  if (contentLength > 4096) return NextResponse.json({ error: "Request is too large" }, { status: 413 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const token = readText(body.token, "Reset token", 32, 128);
  const password = readText(body.password, "Password", 12, 200);
  if (token.error || password.error) return NextResponse.json({ error: token.error ?? password.error }, { status: 400 });

  const tokenHash = createHash("sha256").update(token.data).digest("hex");
  const now = new Date();
  const resetToken = await db.passwordResetToken.findUnique({ where: { tokenHash }, include: { user: true } });
  if (!resetToken || resetToken.usedAt || resetToken.expiresAt <= now || !resetToken.user.active) {
    return NextResponse.json({ error: "This password reset link is invalid or expired. Request a new one." }, { status: 400 });
  }

  const passwordHash = await hashPassword(password.data);
  const changed = await db.$transaction(async (tx) => {
    const claimed = await tx.passwordResetToken.updateMany({ where: { id: resetToken.id, usedAt: null, expiresAt: { gt: now } }, data: { usedAt: now } });
    if (!claimed.count) return false;
    await tx.user.update({ where: { id: resetToken.userId }, data: { passwordHash } });
    await tx.passwordResetToken.deleteMany({ where: { userId: resetToken.userId, id: { not: resetToken.id } } });
    await tx.session.deleteMany({ where: { userId: resetToken.userId } });
    await tx.auditLog.create({ data: { organizationId: resetToken.user.organizationId, userId: resetToken.userId, action: "UPDATE", entity: "UserPassword", entityId: resetToken.userId, afterData: { passwordReset: true, allSessionsRevoked: true }, ipAddress: requestIp(request) } });
    return true;
  });
  if (!changed) return NextResponse.json({ error: "This password reset link is invalid or expired. Request a new one." }, { status: 400 });
  return NextResponse.json({ message: "Password updated. Sign in with your new password." });
}
