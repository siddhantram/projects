import { createHash } from "node:crypto";
import { NextResponse } from "next/server";
import { createSession, verifyPassword } from "@/lib/auth";
import { requestIp } from "@/lib/audit";
import { db } from "@/lib/db";
import { consumeRecoveryCode, decryptTotpSecret, verifyTotp } from "@/lib/mfa";
import { readEmail, readObject, readText } from "@/lib/validation";

export async function POST(request: Request) {
  const contentLength = Number(request.headers.get("content-length") ?? 0);
  if (contentLength > 4096) return NextResponse.json({ error: "Request is too large" }, { status: 413 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const email = readEmail(body.email);
  const password = readText(body.password, "Password", 1, 200);
  if (email.error || password.error) return NextResponse.json({ error: email.error ?? password.error }, { status: 400 });

  const now = new Date();
  const windowMs = 15 * 60 * 1000;
  const limit = 8;
  const ip = requestIp(request);
  const keys = [
    createHash("sha256").update(`account:${email.data}`).digest("hex"),
    ...(ip ? [createHash("sha256").update(`ip:${ip}`).digest("hex")] : []),
  ];
  let limited = false;
  try {
    limited = await db.$transaction(async (tx) => {
      await tx.rateLimitBucket.deleteMany({ where: { updatedAt: { lt: new Date(now.getTime() - 24 * 60 * 60 * 1000) } } });
      for (const key of keys) {
        const bucket = await tx.rateLimitBucket.findUnique({ where: { key } });
        if (bucket?.blockedUntil && bucket.blockedUntil > now) return true;
        if (!bucket || now.getTime() - bucket.windowStartedAt.getTime() >= windowMs) {
          await tx.rateLimitBucket.upsert({ where: { key }, create: { key, attempts: 1, windowStartedAt: now }, update: { attempts: 1, windowStartedAt: now, blockedUntil: null } });
          continue;
        }
        if (bucket.attempts >= limit) {
          await tx.rateLimitBucket.update({ where: { key }, data: { blockedUntil: new Date(now.getTime() + windowMs) } });
          return true;
        }
        await tx.rateLimitBucket.update({ where: { key }, data: { attempts: { increment: 1 } } });
      }
      return false;
    }, { isolationLevel: "Serializable" });
  } catch {
    return NextResponse.json({ error: "Unable to check sign-in limits. Please try again." }, { status: 503 });
  }
  if (limited) return NextResponse.json({ error: "Too many sign-in attempts. Try again in 15 minutes." }, { status: 429, headers: { "Retry-After": "900" } });

  const user = await db.user.findUnique({ where: { email: email.data } });
  if (!user || !user.active || !(await verifyPassword(password.data, user.passwordHash))) {
    return NextResponse.json({ error: "Email or password is incorrect" }, { status: 401 });
  }
  if (user.mfaEnabledAt) {
    const code = typeof body.mfaCode === "string" ? body.mfaCode.trim() : "";
    if (!code) return NextResponse.json({ mfaRequired: true });
    try {
      const validTotp = user.mfaSecretEncrypted ? verifyTotp(decryptTotpSecret(user.mfaSecretEncrypted), code) : false;
      if (!validTotp && !await consumeRecoveryCode(user.id, code)) {
        return NextResponse.json({ error: "Authenticator or recovery code is incorrect", mfaRequired: true }, { status: 401 });
      }
    } catch {
      return NextResponse.json({ error: "MFA verification is unavailable. Check server configuration." }, { status: 503 });
    }
  }
  await db.rateLimitBucket.deleteMany({ where: { key: { in: keys } } });
  await createSession(user.id);
  await db.auditLog.create({ data: { organizationId: user.organizationId, userId: user.id, action: "LOGIN", entity: "User", entityId: user.id, ipAddress: requestIp(request) } });
  return NextResponse.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
}
