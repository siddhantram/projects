import { createHash, randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import { requestIp } from "@/lib/audit";
import { db } from "@/lib/db";
import { sendPasswordResetEmail } from "@/lib/email";
import { readEmail, readObject } from "@/lib/validation";

const accepted = () => NextResponse.json({ message: "If an active account matches that email, password reset instructions will be sent." });

export async function POST(request: Request) {
  const contentLength = Number(request.headers.get("content-length") ?? 0);
  if (contentLength > 4096) return NextResponse.json({ error: "Request is too large" }, { status: 413 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const email = readEmail(body.email);
  if (email.error) return NextResponse.json({ error: email.error }, { status: 400 });

  if (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM || !process.env.APP_URL) {
    return NextResponse.json({ error: "Password recovery email is not configured. Set APP_URL, RESEND_API_KEY and EMAIL_FROM." }, { status: 503 });
  }

  const now = new Date();
  const windowMs = 60 * 60 * 1000;
  const keys = [
    createHash("sha256").update(`password-reset:account:${email.data}`).digest("hex"),
    ...(requestIp(request) ? [createHash("sha256").update(`password-reset:ip:${requestIp(request)}`).digest("hex")] : []),
  ];
  try {
    const limited = await db.$transaction(async (tx) => {
      await tx.rateLimitBucket.deleteMany({ where: { updatedAt: { lt: new Date(now.getTime() - 24 * windowMs) } } });
      for (const key of keys) {
        const bucket = await tx.rateLimitBucket.findUnique({ where: { key } });
        if (bucket?.blockedUntil && bucket.blockedUntil > now) return true;
        if (!bucket || now.getTime() - bucket.windowStartedAt.getTime() >= windowMs) {
          await tx.rateLimitBucket.upsert({ where: { key }, create: { key, attempts: 1, windowStartedAt: now }, update: { attempts: 1, windowStartedAt: now, blockedUntil: null } });
        } else if (bucket.attempts >= 5) {
          await tx.rateLimitBucket.update({ where: { key }, data: { blockedUntil: new Date(now.getTime() + windowMs) } });
          return true;
        } else {
          await tx.rateLimitBucket.update({ where: { key }, data: { attempts: { increment: 1 } } });
        }
      }
      return false;
    }, { isolationLevel: "Serializable" });
    if (limited) return accepted();

    const user = await db.user.findUnique({ where: { email: email.data }, select: { id: true, name: true, email: true, active: true } });
    if (!user?.active) return accepted();

    const token = randomBytes(32).toString("base64url");
    const tokenHash = createHash("sha256").update(token).digest("hex");
    await db.$transaction(async (tx) => {
      await tx.passwordResetToken.deleteMany({ where: { userId: user.id, usedAt: null } });
      await tx.passwordResetToken.create({ data: { tokenHash, userId: user.id, expiresAt: new Date(now.getTime() + 30 * 60 * 1000) } });
    });

    try {
      const appUrl = new URL(process.env.APP_URL);
      if (process.env.NODE_ENV === "production" && appUrl.protocol !== "https:") throw new Error("APP_URL must use HTTPS in production");
      const resetUrl = new URL("/reset-password", appUrl);
      resetUrl.searchParams.set("token", token);
      await sendPasswordResetEmail({ to: user.email, name: user.name, resetUrl: resetUrl.toString() });
    } catch (error) {
      await db.passwordResetToken.deleteMany({ where: { tokenHash } });
      throw error;
    }
    return accepted();
  } catch (error) {
    console.error("Password recovery request failed", error);
    return NextResponse.json({ error: "Unable to process password recovery right now. Please try again later." }, { status: 503 });
  }
}
