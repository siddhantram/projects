import { NextResponse } from "next/server";
import { getCurrentUser, verifyPassword } from "@/lib/auth";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";
import { createTotpSecret, consumeRecoveryCode, decryptTotpSecret, encryptTotpSecret, verifyTotp } from "@/lib/mfa";
import { readObject, readText } from "@/lib/validation";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  const recoveryCodesRemaining = user.mfaEnabledAt ? await db.mfaRecoveryCode.count({ where: { userId: user.id, usedAt: null } }) : 0;
  return NextResponse.json({ enabled: Boolean(user.mfaEnabledAt), recoveryCodesRemaining });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const password = readText(body.password, "Current password", 1, 200);
  if (password.error) return NextResponse.json({ error: password.error }, { status: 400 });
  if (!await verifyPassword(password.data, user.passwordHash)) return NextResponse.json({ error: "Current password is incorrect" }, { status: 400 });
  if (user.mfaEnabledAt) return NextResponse.json({ error: "Multi-factor authentication is already enabled" }, { status: 409 });

  try {
    const secret = createTotpSecret();
    const encrypted = encryptTotpSecret(secret);
    const saved = await db.$transaction(async (tx) => {
      const result = await tx.user.updateMany({ where: { id: user.id, mfaEnabledAt: null }, data: { mfaSecretEncrypted: encrypted } });
      if (!result.count) return false;
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "UserMfa", entityId: user.id, afterData: { setupStarted: true }, ipAddress: requestIp(request) });
      return true;
    });
    if (!saved) return NextResponse.json({ error: "MFA is already enabled; refresh and try again" }, { status: 409 });
    const label = encodeURIComponent(`Enterprise ERP:${user.email}`);
    const issuer = encodeURIComponent("Enterprise ERP");
    return NextResponse.json({ secret, otpauthUrl: `otpauth://totp/${label}?secret=${secret}&issuer=${issuer}&algorithm=SHA1&digits=6&period=30` });
  } catch (error) {
    console.error("MFA setup failed", error);
    return NextResponse.json({ error: "MFA encryption is unavailable. Check AUTH_ENCRYPTION_KEY." }, { status: 503 });
  }
}

export async function DELETE(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const password = readText(body.password, "Current password", 1, 200);
  const code = readText(body.code, "Authenticator or recovery code", 1, 64);
  if (password.error || code.error) return NextResponse.json({ error: password.error ?? code.error }, { status: 400 });
  if (!await verifyPassword(password.data, user.passwordHash)) return NextResponse.json({ error: "Current password is incorrect" }, { status: 400 });
  if (!user.mfaEnabledAt || !user.mfaSecretEncrypted) return NextResponse.json({ error: "Multi-factor authentication is not enabled" }, { status: 409 });

  let validTotp = false;
  try { validTotp = verifyTotp(decryptTotpSecret(user.mfaSecretEncrypted), code.data); }
  catch { return NextResponse.json({ error: "MFA verification is unavailable. Check AUTH_ENCRYPTION_KEY." }, { status: 503 }); }
  const disabled = await db.$transaction(async (tx) => {
    if (!validTotp && !await consumeRecoveryCode(user.id, code.data, tx)) return false;
    await tx.user.update({ where: { id: user.id }, data: { mfaEnabledAt: null, mfaSecretEncrypted: null } });
    await tx.mfaRecoveryCode.deleteMany({ where: { userId: user.id } });
    await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "UserMfa", entityId: user.id, afterData: { enabled: false }, ipAddress: requestIp(request) });
    return true;
  });
  if (!disabled) return NextResponse.json({ error: "Authenticator or recovery code is incorrect" }, { status: 400 });
  return NextResponse.json({ message: "Multi-factor authentication disabled." });
}
