import { createHash } from "node:crypto";
import { NextResponse } from "next/server";
import { getCurrentSessionTokenHash, getCurrentUser } from "@/lib/auth";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";
import { createRecoveryCodes, decryptTotpSecret, recoveryCodeHash, verifyTotp } from "@/lib/mfa";
import { readObject, readText } from "@/lib/validation";

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const code = readText(body.code, "Authenticator code", 6, 6);
  if (code.error || !/^\d{6}$/.test(code.data)) return NextResponse.json({ error: code.error ?? "Enter the six-digit authenticator code" }, { status: 400 });
  if (user.mfaEnabledAt) return NextResponse.json({ error: "Multi-factor authentication is already enabled" }, { status: 409 });
  if (!user.mfaSecretEncrypted) return NextResponse.json({ error: "Start MFA setup before confirming it" }, { status: 409 });

  const rateKey = createHash("sha256").update(`mfa-confirm:${user.id}`).digest("hex");
  const now = new Date();
  const limited = await db.$transaction(async (tx) => {
    const bucket = await tx.rateLimitBucket.findUnique({ where: { key: rateKey } });
    if (bucket?.blockedUntil && bucket.blockedUntil > now) return true;
    if (!bucket || now.getTime() - bucket.windowStartedAt.getTime() >= 15 * 60 * 1000) {
      await tx.rateLimitBucket.upsert({ where: { key: rateKey }, create: { key: rateKey, attempts: 1, windowStartedAt: now }, update: { attempts: 1, windowStartedAt: now, blockedUntil: null } });
    } else if (bucket.attempts >= 8) {
      await tx.rateLimitBucket.update({ where: { key: rateKey }, data: { blockedUntil: new Date(now.getTime() + 15 * 60 * 1000) } });
      return true;
    } else {
      await tx.rateLimitBucket.update({ where: { key: rateKey }, data: { attempts: { increment: 1 } } });
    }
    return false;
  });
  if (limited) return NextResponse.json({ error: "Too many authenticator attempts. Try again in 15 minutes." }, { status: 429, headers: { "Retry-After": "900" } });

  let valid = false;
  try { valid = verifyTotp(decryptTotpSecret(user.mfaSecretEncrypted), code.data); }
  catch { return NextResponse.json({ error: "MFA verification is unavailable. Check AUTH_ENCRYPTION_KEY." }, { status: 503 }); }
  if (!valid) return NextResponse.json({ error: "That authenticator code is incorrect. Check the code and try again." }, { status: 400 });
  const currentSessionHash = await getCurrentSessionTokenHash();
  if (!currentSessionHash) return NextResponse.json({ error: "Session expired. Sign in again." }, { status: 401 });

  const recoveryCodes = createRecoveryCodes();
  const enabledAt = new Date();
  const saved = await db.$transaction(async (tx) => {
    const changed = await tx.user.updateMany({ where: { id: user.id, mfaEnabledAt: null, mfaSecretEncrypted: user.mfaSecretEncrypted }, data: { mfaEnabledAt: enabledAt } });
    if (!changed.count) return false;
    await tx.mfaRecoveryCode.createMany({ data: recoveryCodes.map((value) => ({ userId: user.id, codeHash: recoveryCodeHash(value) })) });
    await tx.session.deleteMany({ where: { userId: user.id, tokenHash: { not: currentSessionHash } } });
    await tx.rateLimitBucket.deleteMany({ where: { key: rateKey } });
    await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "UserMfa", entityId: user.id, afterData: { enabled: true, recoveryCodesIssued: recoveryCodes.length, otherSessionsRevoked: true }, ipAddress: requestIp(request) });
    return true;
  });
  if (!saved) return NextResponse.json({ error: "MFA setup changed. Refresh the page and try again." }, { status: 409 });
  return NextResponse.json({ message: "MFA enabled. Save these recovery codes somewhere safe; each can only be used once.", recoveryCodes });
}
