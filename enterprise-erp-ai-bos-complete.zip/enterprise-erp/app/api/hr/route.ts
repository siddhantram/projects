import { randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { notifyRoles } from "@/lib/notifications";
import { readEmail, readObject, readOptionalText, readText } from "@/lib/validation";

function number(prefix: string) { return `${prefix}-${new Date().getFullYear()}-${randomBytes(3).toString("hex").toUpperCase()}`; }
function money(cents: number) { return `${Math.floor(cents / 100)}.${String(cents % 100).padStart(2, "0")}`; }
function dateOnly(value: unknown) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const date = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value ? date : null;
}
function organizationDate(timeZone: string) {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return new Date(Date.UTC(Number(values.year), Number(values.month) - 1, Number(values.day)));
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  const access = {
    employeesRead: hasPermission(user.role, "employees.read", user.organization.rolePermissions),
    employeesCreate: hasPermission(user.role, "employees.create", user.organization.rolePermissions),
    attendanceRead: hasPermission(user.role, "attendance.read", user.organization.rolePermissions),
    attendanceSelf: hasPermission(user.role, "attendance.self", user.organization.rolePermissions),
    leaveRead: hasPermission(user.role, "leave.read", user.organization.rolePermissions),
    leaveApprove: hasPermission(user.role, "leave.approve", user.organization.rolePermissions),
    leaveCreate: hasPermission(user.role, "leave.create", user.organization.rolePermissions),
    payrollRead: hasPermission(user.role, "payroll.read", user.organization.rolePermissions),
    payrollCreate: hasPermission(user.role, "payroll.create", user.organization.rolePermissions),
    payrollApprove: hasPermission(user.role, "payroll.approve", user.organization.rolePermissions),
    payrollPay: hasPermission(user.role, "payroll.pay", user.organization.rolePermissions),
  };
  if (!access.employeesRead) {
    if (!access.attendanceSelf && !access.attendanceRead && !access.leaveCreate && !access.leaveRead && !access.leaveApprove && !access.payrollRead) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const employee = await db.employee.findFirst({ where: { organizationId: user.organizationId, userId: user.id, active: true } });
    const [attendance, leaveRequests] = await Promise.all([
      access.attendanceRead
        ? db.attendance.findMany({ where: { organizationId: user.organizationId }, include: { employee: { select: { id: true, employeeCode: true, name: true } } }, orderBy: { workDate: "desc" }, take: 100 })
        : employee && access.attendanceSelf
          ? db.attendance.findMany({ where: { organizationId: user.organizationId, employeeId: employee.id }, include: { employee: { select: { id: true, employeeCode: true, name: true } } }, orderBy: { workDate: "desc" }, take: 30 })
          : Promise.resolve([]),
      access.leaveRead || access.leaveApprove
        ? db.leaveRequest.findMany({ where: { organizationId: user.organizationId }, include: { employee: { select: { id: true, employeeCode: true, name: true } } }, orderBy: { createdAt: "desc" }, take: 100 })
        : employee && access.leaveCreate
          ? db.leaveRequest.findMany({ where: { organizationId: user.organizationId, employeeId: employee.id }, include: { employee: { select: { id: true, employeeCode: true, name: true } } }, orderBy: { createdAt: "desc" }, take: 30 })
          : Promise.resolve([]),
    ]);
    const payrollRecords = access.payrollRead ? await db.payrollRecord.findMany({ where: { organizationId: user.organizationId }, include: { employee: { select: { id: true, employeeCode: true, name: true } } }, orderBy: { periodStart: "desc" }, take: 100 }) : [];
    return NextResponse.json({ employee, meEmployee: employee, attendance, leaveRequests, departments: [], employees: [], payrollRecords, access });
  }
  const [employees, departments, attendance, leaveRequests, payrollRecords, meEmployee, unlinkedUsers] = await Promise.all([
    db.employee.findMany({ where: { organizationId: user.organizationId }, include: { department: true }, orderBy: { name: "asc" } }),
    db.department.findMany({ where: { organizationId: user.organizationId }, orderBy: { name: "asc" } }),
    access.attendanceRead
      ? db.attendance.findMany({ where: { organizationId: user.organizationId }, include: { employee: { select: { id: true, employeeCode: true, name: true } } }, orderBy: { workDate: "desc" }, take: 100 })
      : access.attendanceSelf
        ? db.attendance.findMany({ where: { organizationId: user.organizationId, employee: { userId: user.id } }, include: { employee: { select: { id: true, employeeCode: true, name: true } } }, orderBy: { workDate: "desc" }, take: 30 })
        : Promise.resolve([]),
    access.leaveRead || access.leaveApprove
      ? db.leaveRequest.findMany({ where: { organizationId: user.organizationId }, include: { employee: { select: { id: true, employeeCode: true, name: true } } }, orderBy: { createdAt: "desc" }, take: 100 })
      : access.leaveCreate
        ? db.leaveRequest.findMany({ where: { organizationId: user.organizationId, employee: { userId: user.id } }, include: { employee: { select: { id: true, employeeCode: true, name: true } } }, orderBy: { createdAt: "desc" }, take: 30 })
        : Promise.resolve([]),
    access.payrollRead ? db.payrollRecord.findMany({ where: { organizationId: user.organizationId }, include: { employee: { select: { id: true, employeeCode: true, name: true } } }, orderBy: { periodStart: "desc" }, take: 100 }) : Promise.resolve([]),
    db.employee.findFirst({ where: { organizationId: user.organizationId, userId: user.id } }),
    db.user.findMany({ where: { organizationId: user.organizationId, active: true, employee: { is: null } }, select: { id: true, name: true, email: true }, orderBy: { name: "asc" } }),
  ]);
  const visibleEmployees = access.payrollRead ? employees : employees.map(({ baseSalary: _baseSalary, ...employee }) => ({ ...employee, baseSalary: null }));
  return NextResponse.json({ employees: visibleEmployees, departments, attendance, leaveRequests, payrollRecords, meEmployee, unlinkedUsers: access.employeesCreate ? unlinkedUsers : [], access });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });

  if (body.action === "department") {
    if (!hasPermission(user.role, "employees.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const name = readText(body.name, "Department name", 2, 100);
    const description = readOptionalText(body.description, "Description", 300);
    if (name.error || description.error) return NextResponse.json({ error: name.error ?? description.error }, { status: 400 });
    try {
      const department = await db.$transaction(async (tx) => {
        const created = await tx.department.create({ data: { organizationId: user.organizationId, name: name.data, description: description.data } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "Department", entityId: created.id, afterData: { name: created.name }, ipAddress: requestIp(request) });
        return created;
      });
      return NextResponse.json({ department }, { status: 201 });
    } catch (error) {
      if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "This department already exists" }, { status: 409 });
      return NextResponse.json({ error: "Unable to create department" }, { status: 500 });
    }
  }

  if (body.action === "employee") {
    if (!hasPermission(user.role, "employees.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const employeeCode = readText(body.employeeCode, "Employee ID", 2, 40);
    const name = readText(body.name, "Employee name", 2, 120);
    const email = body.email ? readEmail(body.email) : { data: null, error: null };
    const phone = readOptionalText(body.phone, "Phone", 40);
    const designation = readOptionalText(body.designation, "Designation", 100);
    const departmentId = body.departmentId ? readText(body.departmentId, "Department", 1, 100) : { data: null, error: null };
    const userId = body.userId ? readText(body.userId, "User", 1, 100) : { data: null, error: null };
    const baseSalary = Number(body.baseSalary ?? 0);
    const hireDate = body.hireDate ? dateOnly(body.hireDate) : null;
    const error = employeeCode.error ?? name.error ?? email.error ?? phone.error ?? designation.error ?? departmentId.error ?? userId.error;
    if (error || !Number.isFinite(baseSalary) || baseSalary < 0 || (body.hireDate && !hireDate)) return NextResponse.json({ error: error ?? "Salary or hire date is invalid" }, { status: 400 });
    if (baseSalary > 0 && !hasPermission(user.role, "payroll.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Payroll permission is required to set an employee salary" }, { status: 403 });
    if (departmentId.data && !(await db.department.findFirst({ where: { id: departmentId.data, organizationId: user.organizationId } }))) return NextResponse.json({ error: "Department not found" }, { status: 404 });
    if (userId.data && !(await db.user.findFirst({ where: { id: userId.data, organizationId: user.organizationId } }))) return NextResponse.json({ error: "User not found in this workspace" }, { status: 404 });
    try {
      const employee = await db.$transaction(async (tx) => {
        const created = await tx.employee.create({ data: { organizationId: user.organizationId, employeeCode: employeeCode.data, name: name.data, email: email.data?.toLowerCase() ?? null, phone: phone.data, designation: designation.data, departmentId: departmentId.data, userId: userId.data, baseSalary, hireDate } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "Employee", entityId: created.id, afterData: { employeeCode: created.employeeCode, name: created.name }, ipAddress: requestIp(request) });
        return created;
      });
      return NextResponse.json({ employee }, { status: 201 });
    } catch (error) {
      if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "This employee ID is already in use" }, { status: 409 });
      return NextResponse.json({ error: "Unable to create employee" }, { status: 500 });
    }
  }

  if (body.action === "clock-in" || body.action === "clock-out") {
    if (!hasPermission(user.role, "attendance.self", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const employee = await db.employee.findFirst({ where: { organizationId: user.organizationId, userId: user.id, active: true } });
    if (!employee) return NextResponse.json({ error: "Your employee profile is not linked to this account" }, { status: 404 });
    const workDate = organizationDate(user.organization.timezone);
    try {
      const result = await db.$transaction(async (tx) => {
        const existing = await tx.attendance.findUnique({ where: { organizationId_employeeId_workDate: { organizationId: user.organizationId, employeeId: employee.id, workDate } } });
        let record: NonNullable<typeof existing>;
        let auditAction: "CREATE" | "UPDATE";
        if (body.action === "clock-in") {
          if (existing?.checkIn) throw new Error("ALREADY_CLOCKED_IN");
          record = existing
            ? await tx.attendance.update({ where: { id: existing.id }, data: { checkIn: new Date() } })
            : await tx.attendance.create({ data: { organizationId: user.organizationId, employeeId: employee.id, workDate, checkIn: new Date(), status: "PRESENT" } });
          auditAction = existing ? "UPDATE" : "CREATE";
        } else {
          if (!existing?.checkIn || existing.checkOut) throw new Error("CLOCK_IN_REQUIRED");
          record = await tx.attendance.update({ where: { id: existing.id }, data: { checkOut: new Date() } });
          auditAction = "UPDATE";
        }
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: auditAction, entity: "Attendance", entityId: record.id, afterData: { employeeCode: employee.employeeCode, workDate: workDate.toISOString(), checkIn: record.checkIn?.toISOString() ?? null, checkOut: record.checkOut?.toISOString() ?? null }, ipAddress: requestIp(request) });
        return { record, created: !existing };
      }, { isolationLevel: "Serializable" });
      return NextResponse.json({ attendance: result.record }, { status: result.created ? 201 : 200 });
    } catch (error) {
      if (error instanceof Error && error.message === "ALREADY_CLOCKED_IN") return NextResponse.json({ error: "You have already clocked in today" }, { status: 409 });
      if (error instanceof Error && error.message === "CLOCK_IN_REQUIRED") return NextResponse.json({ error: "Clock in before clocking out" }, { status: 409 });
      if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "Attendance is already recorded" }, { status: 409 });
      if (error instanceof Error && "code" in error && error.code === "P2034") return NextResponse.json({ error: "Attendance changed during this request. Refresh and try again." }, { status: 409 });
      throw error;
    }
  }

  if (body.action === "leave") {
    if (!hasPermission(user.role, "leave.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const ownEmployee = await db.employee.findFirst({ where: { organizationId: user.organizationId, userId: user.id, active: true } });
    const employeeId = hasPermission(user.role, "employees.read", user.organization.rolePermissions) && body.employeeId ? readText(body.employeeId, "Employee", 1, 100) : { data: ownEmployee?.id ?? "", error: ownEmployee ? null : "Your employee profile is not linked to this account" };
    const startDate = dateOnly(body.startDate);
    const endDate = dateOnly(body.endDate);
    const reason = readOptionalText(body.reason, "Reason", 1000);
    const types = ["CASUAL", "SICK", "UNPAID", "OTHER"] as const;
    const type = body.type;
    if (employeeId.error || reason.error || !startDate || !endDate || endDate < startDate || (endDate.getTime() - startDate.getTime()) / 86_400_000 > 90 || !types.includes(type as typeof types[number])) return NextResponse.json({ error: employeeId.error ?? reason.error ?? "Provide a valid leave type and date range up to 90 days" }, { status: 400 });
    if (!await db.employee.findFirst({ where: { id: employeeId.data, organizationId: user.organizationId, active: true } })) return NextResponse.json({ error: "Employee not found" }, { status: 404 });
    const overlapping = await db.leaveRequest.findFirst({ where: { organizationId: user.organizationId, employeeId: employeeId.data, status: { not: "REJECTED" }, startDate: { lte: endDate }, endDate: { gte: startDate } } });
    if (overlapping) return NextResponse.json({ error: "This leave period overlaps an existing request" }, { status: 409 });
    const leave = await db.$transaction(async (tx) => {
      const created = await tx.leaveRequest.create({ data: { organizationId: user.organizationId, employeeId: employeeId.data, type: type as typeof types[number], startDate, endDate, reason: reason.data } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "LeaveRequest", entityId: created.id, afterData: { type: created.type, startDate: created.startDate.toISOString(), endDate: created.endDate.toISOString() }, ipAddress: requestIp(request) });
      await notifyRoles(tx, user.organizationId, ["HR", "ADMIN"], "Leave request submitted", `A leave request needs review from ${user.name}.`, "/hr");
      return created;
    });
    return NextResponse.json({ leaveRequest: leave }, { status: 201 });
  }

  if (body.action === "approve-leave" || body.action === "reject-leave") {
    if (!hasPermission(user.role, "leave.approve", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const id = readText(body.id, "Leave request", 1, 100);
    const reviewNote = readOptionalText(body.reviewNote, "Review note", 1000);
    if (id.error || reviewNote.error) return NextResponse.json({ error: id.error ?? reviewNote.error }, { status: 400 });
    const existing = await db.leaveRequest.findFirst({ where: { id: id.data, organizationId: user.organizationId } });
    if (!existing) return NextResponse.json({ error: "Leave request not found" }, { status: 404 });
    if (existing.status !== "PENDING") return NextResponse.json({ error: "This leave request has already been reviewed" }, { status: 409 });
    const status = body.action === "approve-leave" ? "APPROVED" : "REJECTED";
    const leaveRequest = await db.$transaction(async (tx) => {
      const updated = await tx.leaveRequest.update({ where: { id: existing.id }, data: { status, reviewedById: user.id, reviewNote: reviewNote.data } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: status === "APPROVED" ? "APPROVE" : "REJECT", entity: "LeaveRequest", entityId: existing.id, beforeData: { status: existing.status }, afterData: { status: updated.status }, ipAddress: requestIp(request) });
      return updated;
    });
    return NextResponse.json({ leaveRequest });
  }

  if (body.action === "payroll") {
    if (!hasPermission(user.role, "payroll.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const employeeId = readText(body.employeeId, "Employee", 1, 100);
    const periodStart = dateOnly(body.periodStart);
    const deductions = Number(body.deductions ?? 0);
    if (employeeId.error || !periodStart || periodStart.getUTCDate() !== 1 || !Number.isFinite(deductions) || deductions < 0) return NextResponse.json({ error: employeeId.error ?? "Choose the first day of a month and valid deductions" }, { status: 400 });
    const employee = await db.employee.findFirst({ where: { id: employeeId.data, organizationId: user.organizationId, active: true } });
    if (!employee) return NextResponse.json({ error: "Employee not found" }, { status: 404 });
    const grossCents = Math.round(Number(employee.baseSalary) * 100);
    const deductionCents = Math.round(deductions * 100);
    if (grossCents <= 0 || deductionCents > grossCents) return NextResponse.json({ error: "Deductions cannot exceed a positive base salary" }, { status: 400 });
    const periodEnd = new Date(Date.UTC(periodStart.getUTCFullYear(), periodStart.getUTCMonth() + 1, 0));
    try {
      const payroll = await db.$transaction(async (tx) => {
        const created = await tx.payrollRecord.create({ data: { organizationId: user.organizationId, employeeId: employee.id, periodStart, periodEnd, grossPay: money(grossCents), deductions: money(deductionCents), netPay: money(grossCents - deductionCents) } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "PayrollRecord", entityId: created.id, afterData: { employeeId: employee.id, periodStart: created.periodStart.toISOString(), netPay: Number(created.netPay) }, ipAddress: requestIp(request) });
        return created;
      });
      return NextResponse.json({ payroll }, { status: 201 });
    } catch (error) {
      if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "Payroll for this employee and month already exists" }, { status: 409 });
      return NextResponse.json({ error: "Unable to create payroll record" }, { status: 500 });
    }
  }

  if (body.action === "approve-payroll" || body.action === "pay-payroll") {
    const permission = body.action === "approve-payroll" ? "payroll.approve" : "payroll.pay";
    if (!hasPermission(user.role, permission, user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const id = readText(body.id, "Payroll record", 1, 100);
    if (id.error) return NextResponse.json({ error: id.error }, { status: 400 });
    const existing = await db.payrollRecord.findFirst({ where: { id: id.data, organizationId: user.organizationId } });
    if (!existing) return NextResponse.json({ error: "Payroll record not found" }, { status: 404 });
    if (body.action === "approve-payroll") {
      if (existing.status !== "DRAFT") return NextResponse.json({ error: "Only draft payroll can be approved" }, { status: 409 });
      const payroll = await db.$transaction(async (tx) => {
        const updated = await tx.payrollRecord.update({ where: { id: existing.id }, data: { status: "APPROVED" } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "APPROVE", entity: "PayrollRecord", entityId: existing.id, beforeData: { status: existing.status }, afterData: { status: updated.status }, ipAddress: requestIp(request) });
        return updated;
      });
      return NextResponse.json({ payroll });
    }
    if (existing.status !== "APPROVED") return NextResponse.json({ error: "Approve payroll before recording payment" }, { status: 409 });
    const accounts = await db.account.findMany({ where: { organizationId: user.organizationId, code: { in: ["1000", "5000"] }, active: true } });
    const bank = accounts.find((account) => account.code === "1000");
    const wages = accounts.find((account) => account.code === "5000");
    if (!bank || !wages) return NextResponse.json({ error: "Payroll accounts are not configured" }, { status: 500 });
    const payroll = await db.$transaction(async (tx) => {
      const entry = await tx.journalEntry.create({ data: { organizationId: user.organizationId, postedById: user.id, number: number("JE"), description: `Payroll for ${existing.periodStart.toISOString().slice(0, 7)}`, lines: { create: [ { accountId: wages.id, debit: existing.netPay, credit: "0" }, { accountId: bank.id, debit: "0", credit: existing.netPay } ] } } });
      const updated = await tx.payrollRecord.update({ where: { id: existing.id }, data: { status: "PAID", paidAt: new Date(), journalEntryId: entry.id } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "PayrollRecord", entityId: existing.id, beforeData: { status: existing.status }, afterData: { status: updated.status, netPay: Number(updated.netPay) }, ipAddress: requestIp(request) });
      return updated;
    });
    return NextResponse.json({ payroll });
  }

  return NextResponse.json({ error: "Unknown HR action" }, { status: 400 });
}
