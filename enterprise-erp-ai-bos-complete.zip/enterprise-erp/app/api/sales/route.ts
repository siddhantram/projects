import { randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { readEmail, readObject, readOptionalText, readText } from "@/lib/validation";
import { notifyRoles } from "@/lib/notifications";

function number(prefix: string) {
  return `${prefix}-${new Date().getFullYear()}-${randomBytes(3).toString("hex").toUpperCase()}`;
}

function money(cents: number) {
  return `${Math.floor(cents / 100)}.${String(cents % 100).padStart(2, "0")}`;
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "sales.read", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const where = { organizationId: user.organizationId };
  const [leads, quotations, orders, invoices, customers, products, warehouses] = await Promise.all([
    db.salesLead.findMany({ where, include: { customer: true }, orderBy: [{ nextFollowUpAt: "asc" }, { createdAt: "desc" }], take: 50 }),
    db.quotation.findMany({ where, include: { customer: true, lines: true, salesOrder: { select: { id: true, number: true } } }, orderBy: { createdAt: "desc" }, take: 50 }),
    db.salesOrder.findMany({ where, include: { customer: true, lines: true, quotation: { select: { number: true } }, invoice: { select: { id: true, number: true, status: true } } }, orderBy: { createdAt: "desc" }, take: 50 }),
    db.invoice.findMany({ where, include: { customer: true }, orderBy: { createdAt: "desc" }, take: 50 }),
    db.customer.findMany({ where: { organizationId: user.organizationId, active: true }, select: { id: true, name: true }, orderBy: { name: "asc" } }),
    db.product.findMany({ where: { organizationId: user.organizationId, active: true }, select: { id: true, sku: true, name: true, sellingPrice: true }, orderBy: { name: "asc" } }),
    db.warehouse.findMany({ where: { organizationId: user.organizationId }, select: { id: true, name: true }, orderBy: { name: "asc" } }),
  ]);
  return NextResponse.json({ leads, quotations, orders, invoices, customers, products, warehouses });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const action = body.action;

  if (action === "lead") {
    if (!hasPermission(user.role, "sales.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const name = readText(body.name, "Lead name", 2, 120);
    const email = body.email ? readEmail(body.email) : { data: null, error: null };
    const phone = readOptionalText(body.phone, "Phone", 40);
    const source = readOptionalText(body.source, "Source", 100);
    const notes = readOptionalText(body.notes, "Notes", 2000);
    const followUpValue = body.nextFollowUpAt;
    if (followUpValue !== undefined && followUpValue !== null && typeof followUpValue !== "string") return NextResponse.json({ error: "Enter a valid follow-up date" }, { status: 400 });
    const followUpText = typeof followUpValue === "string" ? followUpValue : "";
    const nextFollowUpAt = followUpText ? new Date(`${followUpText}T00:00:00.000Z`) : null;
    const validFollowUp = !followUpText || (/^\d{4}-\d{2}-\d{2}$/.test(followUpText) && nextFollowUpAt && Number.isFinite(nextFollowUpAt.getTime()) && nextFollowUpAt.toISOString().slice(0, 10) === followUpText);
    const error = name.error ?? email.error ?? phone.error ?? source.error ?? notes.error;
    if (!validFollowUp) return NextResponse.json({ error: "Enter a valid follow-up date" }, { status: 400 });
    if (error) return NextResponse.json({ error }, { status: 400 });
    const lead = await db.$transaction(async (tx) => {
      const created = await tx.salesLead.create({ data: { organizationId: user.organizationId, name: name.data, email: email.data, phone: phone.data, source: source.data, notes: notes.data, nextFollowUpAt, ownerId: user.id } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "SalesLead", entityId: created.id, afterData: { name: created.name, email: created.email, nextFollowUpAt: created.nextFollowUpAt?.toISOString() ?? null }, ipAddress: requestIp(request) });
      return created;
    });
    return NextResponse.json({ lead }, { status: 201 });
  }

  if (action === "lead-follow-up") {
    if (!hasPermission(user.role, "sales.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const id = readText(body.id, "Lead", 1, 100);
    const rawDate = body.nextFollowUpAt;
    if (id.error || (rawDate !== null && rawDate !== "" && typeof rawDate !== "string")) return NextResponse.json({ error: id.error ?? "Enter a valid follow-up date" }, { status: 400 });
    const dateText = typeof rawDate === "string" ? rawDate : "";
    const date = dateText ? new Date(`${dateText}T00:00:00.000Z`) : null;
    if (dateText && (!/^\d{4}-\d{2}-\d{2}$/.test(dateText) || !date || !Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== dateText)) return NextResponse.json({ error: "Enter a valid follow-up date" }, { status: 400 });
    try {
      const lead = await db.$transaction(async (tx) => {
        const current = await tx.salesLead.findFirst({ where: { id: id.data, organizationId: user.organizationId } });
        if (!current) throw new Error("LEAD_NOT_FOUND");
        if (current.status === "CONVERTED") throw new Error("LEAD_ALREADY_CONVERTED");
        const updated = await tx.salesLead.update({ where: { id: current.id }, data: { nextFollowUpAt: date } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "SalesLead", entityId: current.id, beforeData: { nextFollowUpAt: current.nextFollowUpAt?.toISOString() ?? null }, afterData: { nextFollowUpAt: updated.nextFollowUpAt?.toISOString() ?? null }, ipAddress: requestIp(request) });
        return updated;
      });
      return NextResponse.json({ lead });
    } catch (error) {
      if (error instanceof Error && error.message === "LEAD_NOT_FOUND") return NextResponse.json({ error: "Lead not found" }, { status: 404 });
      if (error instanceof Error && error.message === "LEAD_ALREADY_CONVERTED") return NextResponse.json({ error: "Converted leads cannot be rescheduled" }, { status: 409 });
      throw error;
    }
  }

  if (action === "lead-status") {
    if (!hasPermission(user.role, "sales.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const id = readText(body.id, "Lead", 1, 100);
    const status = body.status;
    const statuses = ["NEW", "CONTACTED", "QUALIFIED", "LOST"] as const;
    if (id.error || typeof status !== "string" || !statuses.includes(status as typeof statuses[number])) return NextResponse.json({ error: id.error ?? "Choose a valid lead status" }, { status: 400 });
    const transitions: Record<string, readonly string[]> = { NEW: ["CONTACTED", "QUALIFIED", "LOST"], CONTACTED: ["QUALIFIED", "LOST"], QUALIFIED: ["CONTACTED", "LOST"], LOST: ["NEW", "CONTACTED"] };
    try {
      const lead = await db.$transaction(async (tx) => {
        const current = await tx.salesLead.findFirst({ where: { id: id.data, organizationId: user.organizationId } });
        if (!current) throw new Error("LEAD_NOT_FOUND");
        if (current.status === "CONVERTED" || !transitions[current.status]?.includes(status)) throw new Error("LEAD_TRANSITION_INVALID");
        const updated = await tx.salesLead.update({ where: { id: current.id }, data: { status: status as typeof statuses[number] }, include: { customer: true } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "SalesLead", entityId: current.id, beforeData: { status: current.status }, afterData: { status: updated.status }, ipAddress: requestIp(request) });
        return updated;
      });
      return NextResponse.json({ lead });
    } catch (error) {
      if (error instanceof Error && error.message === "LEAD_NOT_FOUND") return NextResponse.json({ error: "Lead not found" }, { status: 404 });
      if (error instanceof Error && error.message === "LEAD_TRANSITION_INVALID") return NextResponse.json({ error: "That lead status change is not allowed" }, { status: 409 });
      throw error;
    }
  }

  if (action === "convert-lead") {
    if (!hasPermission(user.role, "sales.create", user.organization.rolePermissions) || !hasPermission(user.role, "customers.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const id = readText(body.id, "Lead", 1, 100);
    if (id.error) return NextResponse.json({ error: id.error }, { status: 400 });
    try {
      const lead = await db.$transaction(async (tx) => {
        const current = await tx.salesLead.findFirst({ where: { id: id.data, organizationId: user.organizationId }, include: { customer: true } });
        if (!current) throw new Error("LEAD_NOT_FOUND");
        if (current.status !== "QUALIFIED") throw new Error("LEAD_NOT_QUALIFIED");
        let customer = current.customer;
        if (!customer && current.email) customer = await tx.customer.findFirst({ where: { organizationId: user.organizationId, email: { equals: current.email, mode: "insensitive" } } });
        if (customer && !customer.active) throw new Error("CUSTOMER_ARCHIVED");
        let customerCreated = false;
        if (!customer) {
          customer = await tx.customer.create({ data: { organizationId: user.organizationId, name: current.name, email: current.email?.toLowerCase() ?? null, phone: current.phone, notes: current.notes } });
          customerCreated = true;
        }
        const converted = await tx.salesLead.update({ where: { id: current.id }, data: { status: "CONVERTED", customerId: customer.id, nextFollowUpAt: null }, include: { customer: true } });
        if (customerCreated) await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "Customer", entityId: customer.id, afterData: { name: customer.name, email: customer.email }, ipAddress: requestIp(request) });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "SalesLead", entityId: current.id, beforeData: { status: current.status, customerId: current.customerId, nextFollowUpAt: current.nextFollowUpAt?.toISOString() ?? null }, afterData: { status: converted.status, customerId: customer.id, nextFollowUpAt: null }, ipAddress: requestIp(request) });
        return converted;
      }, { isolationLevel: "Serializable" });
      return NextResponse.json({ lead });
    } catch (error) {
      if (error instanceof Error && error.message === "LEAD_NOT_FOUND") return NextResponse.json({ error: "Lead not found" }, { status: 404 });
      if (error instanceof Error && error.message === "LEAD_NOT_QUALIFIED") return NextResponse.json({ error: "Qualify the lead before converting it to a customer" }, { status: 409 });
      if (error instanceof Error && error.message === "CUSTOMER_ARCHIVED") return NextResponse.json({ error: "Restore the archived customer before converting this lead" }, { status: 409 });
      if (error instanceof Error && "code" in error && (error.code === "P2002" || error.code === "P2034")) return NextResponse.json({ error: "This lead or customer changed at the same time. Refresh and try again." }, { status: 409 });
      throw error;
    }
  }

  if (action === "quotation") {
    if (!hasPermission(user.role, "sales.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const customerId = readText(body.customerId, "Customer", 1, 100);
    const notes = readOptionalText(body.notes, "Notes", 2000);
    const validDays = Number(body.validDays ?? 30);
    const rawLines = Array.isArray(body.lines) ? body.lines : [];
    if (customerId.error || notes.error || !Number.isInteger(validDays) || validDays < 1 || validDays > 365 || rawLines.length < 1 || rawLines.length > 100) return NextResponse.json({ error: customerId.error ?? notes.error ?? (validDays < 1 || validDays > 365 || !Number.isInteger(validDays) ? "Quote validity must be between 1 and 365 days" : "A quote must contain between 1 and 100 items") }, { status: 400 });
    const parsedLines = rawLines.map((raw) => {
      const line = readObject(raw);
      if (!line) return null;
      const productId = readText(line.productId, "Product", 1, 100);
      const quantity = Number(line.quantity);
      const taxRate = Number(line.taxRate ?? 0);
      if (productId.error || !Number.isInteger(quantity) || quantity < 1 || quantity > 100000 || !Number.isFinite(taxRate) || taxRate < 0 || taxRate > 100) return null;
      return { productId: productId.data, quantity, taxRate };
    });
    if (parsedLines.some((line) => !line)) return NextResponse.json({ error: "Each item needs a valid product, quantity and tax rate" }, { status: 400 });
    const customer = await db.customer.findFirst({ where: { id: customerId.data, organizationId: user.organizationId, active: true } });
    if (!customer) return NextResponse.json({ error: "Customer not found in your workspace" }, { status: 404 });
    const productIds = [...new Set(parsedLines.map((line) => line!.productId))];
    const products = await db.product.findMany({ where: { id: { in: productIds }, organizationId: user.organizationId, active: true } });
    const productMap = new Map(products.map((product) => [product.id, product]));
    if (products.length !== productIds.length) return NextResponse.json({ error: "One or more products were not found in your workspace" }, { status: 404 });
    const lines = parsedLines.map((line) => {
      const item = line!;
      const product = productMap.get(item.productId)!;
      const unitCents = Math.round(Number(product.sellingPrice) * 100);
      const baseCents = unitCents * item.quantity;
      const taxCents = Math.round(baseCents * item.taxRate / 100);
      return { productId: product.id, description: product.name, quantity: item.quantity, unitPrice: money(unitCents), taxRate: money(Math.round(item.taxRate * 100)), lineTotal: money(baseCents + taxCents), baseCents, taxCents };
    });
    const subtotal = lines.reduce((sum, line) => sum + line.baseCents, 0);
    const taxAmount = lines.reduce((sum, line) => sum + line.taxCents, 0);
    const quote = await db.$transaction(async (tx) => {
      const created = await tx.quotation.create({ data: { organizationId: user.organizationId, customerId: customer.id, number: number("QT"), currency: user.organization.currency, subtotal: money(subtotal), taxAmount: money(taxAmount), total: money(subtotal + taxAmount), validUntil: new Date(Date.now() + validDays * 86_400_000), notes: notes.data, lines: { create: lines.map(({ baseCents: _base, taxCents: _tax, ...line }) => line) } }, include: { lines: true, customer: true } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "Quotation", entityId: created.id, afterData: { number: created.number, total: Number(created.total), validUntil: created.validUntil?.toISOString() ?? null }, ipAddress: requestIp(request) });
      return created;
    });
    return NextResponse.json({ quotation: quote }, { status: 201 });
  }

  if (action === "send-quotation" || action === "reject-quotation") {
    const permission = action === "send-quotation" ? "sales.create" : "sales.approve";
    if (!hasPermission(user.role, permission, user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const id = readText(body.id, "Quotation", 1, 100);
    if (id.error) return NextResponse.json({ error: id.error }, { status: 400 });
    const quotation = await db.quotation.findFirst({ where: { id: id.data, organizationId: user.organizationId } });
    if (!quotation) return NextResponse.json({ error: "Quotation not found" }, { status: 404 });
    const expected = action === "send-quotation" ? "DRAFT" : "SENT";
    if (quotation.status !== expected) return NextResponse.json({ error: action === "send-quotation" ? "Only draft quotations can be marked as sent" : "Only sent quotations can be rejected" }, { status: 409 });
    if (action === "send-quotation" && quotation.validUntil && quotation.validUntil <= new Date()) {
      try {
        const expired = await db.$transaction(async (tx) => {
          const changed = await tx.quotation.updateMany({ where: { id: quotation.id, organizationId: user.organizationId, status: "DRAFT", validUntil: { lte: new Date() } }, data: { status: "EXPIRED" } });
          if (!changed.count) throw new Error("QUOTE_STATE_CHANGED");
          const updated = await tx.quotation.findUniqueOrThrow({ where: { id: quotation.id } });
          await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "Quotation", entityId: quotation.id, beforeData: { status: quotation.status }, afterData: { status: updated.status }, ipAddress: requestIp(request) });
          return updated;
        });
        return NextResponse.json({ error: "This quotation has expired", quotation: expired }, { status: 409 });
      } catch (error) {
        if (error instanceof Error && error.message === "QUOTE_STATE_CHANGED") return NextResponse.json({ error: "Quotation changed during this request. Refresh and try again." }, { status: 409 });
        throw error;
      }
    }
    const status = action === "send-quotation" ? "SENT" : "REJECTED";
    try {
      const updated = await db.$transaction(async (tx) => {
        const changed = await tx.quotation.updateMany({ where: { id: quotation.id, organizationId: user.organizationId, status: expected }, data: { status } });
        if (!changed.count) throw new Error("QUOTE_STATE_CHANGED");
        const next = await tx.quotation.findUniqueOrThrow({ where: { id: quotation.id } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: action === "send-quotation" ? "UPDATE" : "REJECT", entity: "Quotation", entityId: quotation.id, beforeData: { status: quotation.status }, afterData: { status: next.status }, ipAddress: requestIp(request) });
        return next;
      });
      return NextResponse.json({ quotation: updated });
    } catch (error) {
      if (error instanceof Error && error.message === "QUOTE_STATE_CHANGED") return NextResponse.json({ error: "Quotation changed during this request. Refresh and try again." }, { status: 409 });
      throw error;
    }
  }

  if (action === "approve-quotation") {
    if (!hasPermission(user.role, "sales.approve", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const id = readText(body.id, "Quotation", 1, 100);
    if (id.error) return NextResponse.json({ error: id.error }, { status: 400 });
    try {
      const outcome = await db.$transaction(async (tx) => {
        const quotation = await tx.quotation.findFirst({ where: { id: id.data, organizationId: user.organizationId } });
        if (!quotation) throw new Error("QUOTE_NOT_FOUND");
        if (quotation.status !== "SENT") throw new Error("QUOTE_NOT_SENT");
        if (quotation.validUntil && quotation.validUntil <= new Date()) {
          const expired = await tx.quotation.update({ where: { id: quotation.id }, data: { status: "EXPIRED" } });
          await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "Quotation", entityId: quotation.id, beforeData: { status: quotation.status }, afterData: { status: expired.status }, ipAddress: requestIp(request) });
          return { expired: true as const, quotation: expired };
        }
        const approved = await tx.quotation.update({ where: { id: quotation.id }, data: { status: "APPROVED" } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "APPROVE", entity: "Quotation", entityId: quotation.id, beforeData: { status: quotation.status }, afterData: { status: approved.status }, ipAddress: requestIp(request) });
        return { expired: false as const, quotation: approved };
      }, { isolationLevel: "Serializable" });
      if (outcome.expired) return NextResponse.json({ error: "This quotation expired and cannot be approved", quotation: outcome.quotation }, { status: 409 });
      return NextResponse.json({ quotation: outcome.quotation });
    } catch (error) {
      if (error instanceof Error && error.message === "QUOTE_NOT_FOUND") return NextResponse.json({ error: "Quotation not found" }, { status: 404 });
      if (error instanceof Error && error.message === "QUOTE_NOT_SENT") return NextResponse.json({ error: "Only sent quotations can be approved" }, { status: 409 });
      if (error instanceof Error && "code" in error && error.code === "P2034") return NextResponse.json({ error: "Quotation changed during approval. Refresh and try again." }, { status: 409 });
      throw error;
    }
  }

  if (action === "convert-quotation") {
    if (!hasPermission(user.role, "sales.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const id = readText(body.id, "Quotation", 1, 100);
    if (id.error) return NextResponse.json({ error: id.error }, { status: 400 });
    try {
      const order = await db.$transaction(async (tx) => {
        const quote = await tx.quotation.findFirst({ where: { id: id.data, organizationId: user.organizationId }, include: { lines: true } });
        if (!quote) throw new Error("QUOTE_NOT_FOUND");
        if (quote.status !== "APPROVED") throw new Error("QUOTE_NOT_APPROVED");
        const created = await tx.salesOrder.create({ data: { organizationId: user.organizationId, customerId: quote.customerId, quotationId: quote.id, number: number("SO"), currency: quote.currency, subtotal: quote.subtotal, taxAmount: quote.taxAmount, total: quote.total, notes: quote.notes, lines: { create: quote.lines.map(({ id: _id, quotationId: _quoteId, ...line }) => line) } }, include: { lines: true, customer: true } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "SalesOrder", entityId: created.id, afterData: { number: created.number, sourceQuotation: quote.number, total: Number(created.total) }, ipAddress: requestIp(request) });
        return created;
      }, { isolationLevel: "Serializable" });
      return NextResponse.json({ order }, { status: 201 });
    } catch (error) {
      if (error instanceof Error && error.message === "QUOTE_NOT_FOUND") return NextResponse.json({ error: "Quotation not found" }, { status: 404 });
      if (error instanceof Error && error.message === "QUOTE_NOT_APPROVED") return NextResponse.json({ error: "Approve the quotation before converting it" }, { status: 409 });
      if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "This quotation has already been converted" }, { status: 409 });
      throw error;
    }
  }

  if (action === "cancel-order") {
    if (!hasPermission(user.role, "sales.approve", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const id = readText(body.id, "Sales order", 1, 100);
    if (id.error) return NextResponse.json({ error: id.error }, { status: 400 });
    try {
      const cancelled = await db.$transaction(async (tx) => {
        const order = await tx.salesOrder.findFirst({ where: { id: id.data, organizationId: user.organizationId }, include: { lines: true, invoice: { select: { id: true } } } });
        if (!order) throw new Error("ORDER_NOT_FOUND");
        if (!["DRAFT", "CONFIRMED", "PROCESSING"].includes(order.status) || order.invoice || order.lines.some((line) => line.fulfilledQuantity > 0)) throw new Error("ORDER_CANNOT_CANCEL");
        const changed = await tx.salesOrder.updateMany({ where: { id: order.id, organizationId: user.organizationId, status: order.status }, data: { status: "CANCELLED" } });
        if (!changed.count) throw new Error("ORDER_STATE_CHANGED");
        const updated = await tx.salesOrder.findUniqueOrThrow({ where: { id: order.id } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "SalesOrder", entityId: order.id, beforeData: { status: order.status }, afterData: { status: updated.status }, ipAddress: requestIp(request) });
        return updated;
      }, { isolationLevel: "Serializable" });
      return NextResponse.json({ order: cancelled });
    } catch (error) {
      if (error instanceof Error && error.message === "ORDER_NOT_FOUND") return NextResponse.json({ error: "Sales order not found" }, { status: 404 });
      if (error instanceof Error && error.message === "ORDER_CANNOT_CANCEL") return NextResponse.json({ error: "Only unfulfilled orders without an invoice can be cancelled" }, { status: 409 });
      if (error instanceof Error && error.message === "ORDER_STATE_CHANGED") return NextResponse.json({ error: "Order changed during cancellation. Refresh and try again." }, { status: 409 });
      if (error instanceof Error && "code" in error && error.code === "P2034") return NextResponse.json({ error: "Order changed during cancellation. Refresh and try again." }, { status: 409 });
      throw error;
    }
  }

  if (action === "fulfill") {
    if (!hasPermission(user.role, "sales.fulfill", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const orderId = readText(body.orderId, "Sales order", 1, 100);
    const warehouseId = readText(body.warehouseId, "Warehouse", 1, 100);
    const rawQuantities = readObject(body.quantities);
    if (orderId.error || warehouseId.error || !rawQuantities || !Object.keys(rawQuantities).length) return NextResponse.json({ error: orderId.error ?? warehouseId.error ?? "Enter fulfilled quantities" }, { status: 400 });
    try {
      const order = await db.$transaction(async (tx) => {
        const current = await tx.salesOrder.findFirst({ where: { id: orderId.data, organizationId: user.organizationId }, include: { lines: true } });
        if (!current) throw new Error("ORDER_NOT_FOUND");
        if (!["CONFIRMED", "PROCESSING"].includes(current.status)) throw new Error("ORDER_CLOSED");
        const warehouse = await tx.warehouse.findFirst({ where: { id: warehouseId.data, organizationId: user.organizationId } });
        if (!warehouse) throw new Error("WAREHOUSE_NOT_FOUND");
        const movements: { lineId: string; productId: string; quantity: number }[] = [];
        for (const [lineId, rawQuantity] of Object.entries(rawQuantities)) {
          const line = current.lines.find((item) => item.id === lineId);
          const quantity = Number(rawQuantity);
          if (!line || !line.productId || !Number.isInteger(quantity) || quantity < 1 || line.fulfilledQuantity + quantity > line.quantity) throw new Error("INVALID_FULFILLMENT");
          const balance = await tx.stockMovement.aggregate({ where: { organizationId: user.organizationId, productId: line.productId, warehouseId: warehouse.id }, _sum: { quantity: true } });
          if ((balance._sum.quantity ?? 0) < quantity) throw new Error("INSUFFICIENT_STOCK");
          movements.push({ lineId: line.id, productId: line.productId, quantity });
        }
        const productIds = [...new Set(movements.map((item) => item.productId))];
        const products = await tx.product.findMany({ where: { id: { in: productIds }, organizationId: user.organizationId }, select: { id: true, name: true, costPrice: true } });
        const productMap = new Map(products.map((product) => [product.id, product]));
        const costCents = movements.reduce((sum, item) => sum + Math.round(Number(productMap.get(item.productId)?.costPrice ?? 0) * 100) * item.quantity, 0);
        let costEntry: { id: string; number: string } | null = null;
        if (costCents > 0) {
          const accounts = await tx.account.findMany({ where: { organizationId: user.organizationId, code: { in: ["1200", "5100", "5000"] }, active: true } });
          const inventoryAccount = accounts.find((account) => account.code === "1200");
          const costAccount = accounts.find((account) => account.code === "5100") ?? accounts.find((account) => account.code === "5000");
          if (!inventoryAccount || !costAccount) throw new Error("COST_ACCOUNTS_MISSING");
          costEntry = await tx.journalEntry.create({ data: { organizationId: user.organizationId, postedById: user.id, number: number("JE"), description: `Cost of sales for ${current.number}`, lines: { create: [{ accountId: costAccount.id, debit: money(costCents), credit: "0" }, { accountId: inventoryAccount.id, debit: "0", credit: money(costCents) }] } }, select: { id: true, number: true } });
          await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "JournalEntry", entityId: costEntry.id, afterData: { number: costEntry.number, salesOrder: current.number, amount: costCents / 100 }, ipAddress: requestIp(request) });
        }
        for (const item of movements) {
          await tx.stockMovement.create({ data: { organizationId: user.organizationId, productId: item.productId, warehouseId: warehouse.id, type: "SALE", quantity: -item.quantity, reference: current.number, note: `Fulfilled sales order ${current.number}` } });
          await tx.salesOrderLine.update({ where: { id: item.lineId }, data: { fulfilledQuantity: { increment: item.quantity } } });
        }
        const allFulfilled = current.lines.every((line) => !line.productId || line.fulfilledQuantity + (movements.find((item) => item.lineId === line.id)?.quantity ?? 0) >= line.quantity);
        const updated = await tx.salesOrder.update({ where: { id: current.id }, data: { status: allFulfilled ? "SHIPPED" : "PROCESSING" }, include: { lines: true } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "SalesOrder", entityId: current.id, beforeData: { status: current.status }, afterData: { status: updated.status, warehouse: warehouse.name, quantities: movements, costJournal: costEntry?.number }, ipAddress: requestIp(request) });
        await notifyRoles(tx, user.organizationId, ["ADMIN", "MANAGER"], "Sales order fulfilled", `${current.number} was fulfilled from ${warehouse.name}.`, "/sales");
        return updated;
      }, { isolationLevel: "Serializable" });
      return NextResponse.json({ order });
    } catch (error) {
      if (error instanceof Error && error.message === "ORDER_NOT_FOUND") return NextResponse.json({ error: "Sales order not found" }, { status: 404 });
      if (error instanceof Error && error.message === "ORDER_CLOSED") return NextResponse.json({ error: "This order is no longer open for fulfillment" }, { status: 409 });
      if (error instanceof Error && error.message === "WAREHOUSE_NOT_FOUND") return NextResponse.json({ error: "Warehouse not found in your workspace" }, { status: 404 });
      if (error instanceof Error && error.message === "INVALID_FULFILLMENT") return NextResponse.json({ error: "Choose a stock product and valid quantity no greater than the remaining order quantity" }, { status: 400 });
      if (error instanceof Error && error.message === "INSUFFICIENT_STOCK") return NextResponse.json({ error: "There is not enough stock in the selected warehouse" }, { status: 409 });
      if (error instanceof Error && error.message === "COST_ACCOUNTS_MISSING") return NextResponse.json({ error: "Inventory and cost accounts are not configured" }, { status: 500 });
      if (error instanceof Error && "code" in error && error.code === "P2034") return NextResponse.json({ error: "Stock or order changed during fulfillment. Refresh and try again." }, { status: 409 });
      return NextResponse.json({ error: "Unable to fulfill sales order" }, { status: 500 });
    }
  }

  if (action === "invoice") {
    if (!hasPermission(user.role, "invoices.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const orderId = readText(body.orderId, "Sales order", 1, 100);
    const dueDays = Number(body.dueDays ?? 30);
    if (orderId.error || !Number.isInteger(dueDays) || dueDays < 0 || dueDays > 365) return NextResponse.json({ error: orderId.error ?? "Due days must be between 0 and 365" }, { status: 400 });
    const order = await db.salesOrder.findFirst({ where: { id: orderId.data, organizationId: user.organizationId }, include: { lines: true } });
    if (!order) return NextResponse.json({ error: "Sales order not found" }, { status: 404 });
    const dueAt = new Date(Date.now() + dueDays * 86_400_000);
    try {
      const invoice = await db.$transaction(async (tx) => {
        const currentOrder = await tx.salesOrder.findFirst({ where: { id: order.id, organizationId: user.organizationId }, select: { status: true } });
        if (!currentOrder) throw new Error("ORDER_NOT_FOUND");
        if (currentOrder.status === "CANCELLED") throw new Error("ORDER_CANCELLED");
        const existing = await tx.invoice.findFirst({ where: { organizationId: user.organizationId, salesOrderId: order.id } });
        if (existing) throw new Error("INVOICE_EXISTS");
        const invoiceNumber = number("INV");
        const ledgerAccounts = await tx.account.findMany({ where: { organizationId: user.organizationId, code: { in: ["1100", "4000", "2100"] }, active: true } });
        const accountByCode = new Map(ledgerAccounts.map((account) => [account.code, account]));
        const receivables = accountByCode.get("1100");
        const revenue = accountByCode.get("4000");
        const taxPayable = accountByCode.get("2100");
        if (!receivables || !revenue || !taxPayable) throw new Error("CHART_OF_ACCOUNTS_MISSING");
        const entry = await tx.journalEntry.create({ data: { organizationId: user.organizationId, postedById: user.id, number: number("JE"), description: `Sales invoice ${invoiceNumber}`, lines: { create: [
          { accountId: receivables.id, debit: order.total, credit: "0", memo: invoiceNumber },
          { accountId: revenue.id, debit: "0", credit: order.subtotal, memo: invoiceNumber },
          ...(Number(order.taxAmount) > 0 ? [{ accountId: taxPayable.id, debit: "0", credit: order.taxAmount, memo: invoiceNumber }] : []),
        ] } } });
        const created = await tx.invoice.create({ data: { organizationId: user.organizationId, customerId: order.customerId, salesOrderId: order.id, journalEntryId: entry.id, number: invoiceNumber, currency: order.currency, subtotal: order.subtotal, taxAmount: order.taxAmount, total: order.total, dueAt, status: "SENT", lines: { create: order.lines.map(({ id: _id, salesOrderId: _orderId, ...line }) => line) } }, include: { lines: true, customer: true } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "Invoice", entityId: created.id, afterData: { number: created.number, salesOrder: order.number, total: Number(created.total) }, ipAddress: requestIp(request) });
        return created;
      }, { isolationLevel: "Serializable" });
      return NextResponse.json({ invoice }, { status: 201 });
    } catch (error) {
      if (error instanceof Error && error.message === "ORDER_NOT_FOUND") return NextResponse.json({ error: "Sales order not found" }, { status: 404 });
      if (error instanceof Error && error.message === "ORDER_CANCELLED") return NextResponse.json({ error: "Cancelled sales orders cannot be invoiced" }, { status: 409 });
      if (error instanceof Error && error.message === "INVOICE_EXISTS") return NextResponse.json({ error: "This order already has an invoice" }, { status: 409 });
      if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "This order already has an invoice" }, { status: 409 });
      throw error;
    }
  }

  if (action === "payment") {
    if (!hasPermission(user.role, "payments.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const invoiceId = readText(body.invoiceId, "Invoice", 1, 100);
    const amount = Number(body.amount);
    const method = body.method;
    const methods = ["BANK_TRANSFER", "CASH", "CARD", "UPI", "CHEQUE", "OTHER"] as const;
    const reference = readOptionalText(body.reference, "Reference", 100);
    if (invoiceId.error || reference.error || !Number.isFinite(amount) || amount <= 0 || !methods.includes(method as typeof methods[number])) return NextResponse.json({ error: "Provide an invoice, positive payment amount and valid method" }, { status: 400 });
    const paymentMethod = method as typeof methods[number];
    try {
      const payment = await db.$transaction(async (tx) => {
        const invoice = await tx.invoice.findFirst({ where: { id: invoiceId.data, organizationId: user.organizationId } });
        if (!invoice) throw new Error("INVOICE_NOT_FOUND");
        if (["PAID", "CANCELLED"].includes(invoice.status)) throw new Error("INVOICE_CLOSED");
        const amountCents = Math.round(amount * 100);
        const outstandingCents = Math.round((Number(invoice.total) - Number(invoice.amountPaid)) * 100);
        if (amountCents > outstandingCents) throw new Error("OVERPAYMENT");
        const ledgerAccounts = await tx.account.findMany({ where: { organizationId: user.organizationId, code: { in: ["1000", "1100"] }, active: true } });
        const accountByCode = new Map(ledgerAccounts.map((account) => [account.code, account]));
        const cash = accountByCode.get("1000");
        const receivables = accountByCode.get("1100");
        if (!cash || !receivables) throw new Error("CHART_OF_ACCOUNTS_MISSING");
        const entry = await tx.journalEntry.create({ data: { organizationId: user.organizationId, postedById: user.id, number: number("JE"), description: `Payment for invoice ${invoice.number}`, lines: { create: [ { accountId: cash.id, debit: money(amountCents), credit: "0", memo: invoice.number }, { accountId: receivables.id, debit: "0", credit: money(amountCents), memo: invoice.number } ] } } });
        const paid = Number(invoice.amountPaid) + amountCents / 100;
        const updatedInvoice = await tx.invoice.update({ where: { id: invoice.id }, data: { amountPaid: money(Math.round(paid * 100)), status: Math.round(paid * 100) >= Math.round(Number(invoice.total) * 100) ? "PAID" : "PARTIALLY_PAID" } });
        const created = await tx.payment.create({ data: { organizationId: user.organizationId, customerId: invoice.customerId, invoiceId: invoice.id, journalEntryId: entry.id, number: number("PAY"), amount: money(amountCents), method: paymentMethod, reference: reference.data } });
        await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "Payment", entityId: created.id, afterData: { number: created.number, invoice: invoice.number, amount: amountCents / 100, status: updatedInvoice.status }, ipAddress: requestIp(request) });
        return created;
      }, { isolationLevel: "Serializable" });
      return NextResponse.json({ payment }, { status: 201 });
    } catch (error) {
      if (error instanceof Error && error.message === "INVOICE_NOT_FOUND") return NextResponse.json({ error: "Invoice not found" }, { status: 404 });
      if (error instanceof Error && error.message === "INVOICE_CLOSED") return NextResponse.json({ error: "This invoice cannot accept more payments" }, { status: 409 });
      if (error instanceof Error && error.message === "OVERPAYMENT") return NextResponse.json({ error: "Payment exceeds the amount due" }, { status: 409 });
      if (error instanceof Error && "code" in error && (error.code === "P2034" || error.code === "P2002")) return NextResponse.json({ error: "The invoice changed during this request. Refresh and try again." }, { status: 409 });
      throw error;
    }
  }

  return NextResponse.json({ error: "Unknown sales action" }, { status: 400 });
}
