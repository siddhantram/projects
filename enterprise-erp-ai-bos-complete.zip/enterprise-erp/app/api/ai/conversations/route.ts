import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
export async function GET(){
 const user=await getCurrentUser(); if(!user)return NextResponse.json({error:"Unauthenticated"},{status:401});
 const items=await db.aIConversation.findMany({where:{organizationId:user.organizationId,userId:user.id},include:{messages:{orderBy:{createdAt:"asc"},take:50}},orderBy:{updatedAt:"desc"},take:20});
 return NextResponse.json({conversations:items});
}
