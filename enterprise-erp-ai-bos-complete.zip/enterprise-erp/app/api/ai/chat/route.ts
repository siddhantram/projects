import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { generateAIResponse } from "@/lib/ai/client";
import { getBusinessContext } from "@/lib/ai/context";
import { searchKnowledge } from "@/lib/ai/rag";
import { SYSTEM_PROMPT } from "@/lib/ai/prompts";

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  const body = await request.json().catch(() => ({}));
  const message = typeof body.message === "string" ? body.message.trim() : "";
  if (!message || message.length > 4000) return NextResponse.json({ error: "Message is required and must be under 4000 characters." }, { status: 400 });

  const started = Date.now();
  const context = await getBusinessContext(user.organizationId);
  const knowledge = await searchKnowledge(user.organizationId, message, 5);
  const conversationId = typeof body.conversationId === "string" ? body.conversationId : undefined;

  const conversation = conversationId
    ? await db.aIConversation.findFirst({ where: { id: conversationId, organizationId: user.organizationId, userId: user.id } })
    : await db.aIConversation.create({ data: { organizationId:user.organizationId, userId:user.id, title:message.slice(0,80) } });
  if (!conversation) return NextResponse.json({ error:"Conversation not found" }, { status:404 });

  await db.aIMessage.create({ data:{ conversationId:conversation.id, role:"USER", content:message } });

  const knowledgeText = knowledge.map((x:any)=>`SOURCE: ${x.source}\n${x.content}`).join("\n\n");
  const prompt = `${SYSTEM_PROMPT}\n\nORGANIZATION ERP DATA:\n${JSON.stringify(context)}\n\nCOMPANY KNOWLEDGE:\n${knowledgeText || "No matching documents."}\n\nUSER QUESTION:\n${message}`;

  let answer = await generateAIResponse([{ role:"system", content:SYSTEM_PROMPT }, { role:"user", content:prompt }]);
  if (!answer) {
    answer = `AI provider is not configured yet. Here is a secure ERP data snapshot:\n\n• Customers: ${context.customers}\n• Leads: ${context.leads}\n• Active products: ${context.products}\n• Employees: ${context.employees}\n• Invoice value: ₹${context.invoices.total.toLocaleString("en-IN")}\n• Paid: ₹${context.invoices.paid.toLocaleString("en-IN")}\n• Expenses: ₹${context.expenses.total.toLocaleString("en-IN")}\n• Overdue invoices: ${context.overdueInvoices.count}\n\nAdd OPENAI_API_KEY to enable natural-language AI analysis.`;
  }

  await db.aIMessage.create({ data:{ conversationId:conversation.id, role:"ASSISTANT", content:answer } });
  await db.aIAgentRun.create({ data:{ organizationId:user.organizationId,userId:user.id,agentType:"BUSINESS",input:message,output:answer,durationMs:Date.now()-started } });
  return NextResponse.json({ conversationId:conversation.id, answer, sources:knowledge.map((x:any)=>x.source) });
}
