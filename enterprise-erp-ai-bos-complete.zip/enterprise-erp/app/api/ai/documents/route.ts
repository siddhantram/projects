import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { indexDocument } from "@/lib/ai/rag";

export async function GET() {
  const user=await getCurrentUser();
  if(!user) return NextResponse.json({error:"Unauthenticated"},{status:401});
  const documents=await db.aIDocument.findMany({where:{organizationId:user.organizationId},select:{id:true,name:true,mimeType:true,sizeBytes:true,status:true,createdAt:true},orderBy:{createdAt:"desc"}});
  return NextResponse.json({documents});
}

export async function POST(request: Request) {
  const user=await getCurrentUser();
  if(!user) return NextResponse.json({error:"Unauthenticated"},{status:401});
  const form=await request.formData();
  const file=form.get("file");
  if(!(file instanceof File)) return NextResponse.json({error:"File is required"},{status:400});
  if(file.size>10*1024*1024) return NextResponse.json({error:"Maximum file size is 10MB"},{status:400});
  const allowed=["text/plain","text/markdown","text/csv","application/json","application/pdf"];
  if(!allowed.includes(file.type)) return NextResponse.json({error:"Supported: TXT, MD, CSV, JSON, PDF"},{status:400});
  const bytes=await file.arrayBuffer();
  let text=new TextDecoder().decode(bytes);
  if(file.type==="application/pdf") text=`PDF uploaded: ${file.name}\n\nPDF text extraction requires the pdf-parse dependency. Install it and extend this endpoint for binary PDF extraction.`;
  const doc=await db.aIDocument.create({data:{organizationId:user.organizationId,uploadedById:user.id,name:file.name,mimeType:file.type,sizeBytes:file.size,status:"PROCESSING"}});
  try {
    await indexDocument(doc.id,user.organizationId,text);
    return NextResponse.json({document:{id:doc.id,name:doc.name,status:"READY"}});
  } catch(error) {
    await db.aIDocument.update({where:{id:doc.id},data:{status:"FAILED"}});
    return NextResponse.json({error:error instanceof Error?error.message:"Indexing failed"},{status:500});
  }
}
