import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { readObject, readOptionalText, readText } from "@/lib/validation";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "products.update", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const before = await db.product.findFirst({ where: { id, organizationId: user.organizationId } });
  if (!before) return NextResponse.json({ error: "Product not found" }, { status: 404 });
  const sku = body.sku === undefined ? { data: before.sku, error: null } : readText(body.sku, "SKU", 1, 80);
  const name = body.name === undefined ? { data: before.name, error: null } : readText(body.name, "Product name", 2, 160);
  const category = body.category === undefined ? { data: before.category, error: null } : readOptionalText(body.category, "Category", 100);
  const costPrice = body.costPrice === undefined ? Number(before.costPrice) : Number(body.costPrice);
  const sellingPrice = body.sellingPrice === undefined ? Number(before.sellingPrice) : Number(body.sellingPrice);
  const reorderLevel = body.reorderLevel === undefined ? before.reorderLevel : Number(body.reorderLevel);
  if (sku.error || name.error || category.error || !Number.isFinite(costPrice) || costPrice < 0 || !Number.isFinite(sellingPrice) || sellingPrice < 0 || !Number.isInteger(reorderLevel) || reorderLevel < 0 || (body.active !== undefined && typeof body.active !== "boolean")) return NextResponse.json({ error: sku.error ?? name.error ?? category.error ?? "Enter valid product values" }, { status: 400 });
  try {
    const product = await db.$transaction(async (tx) => {
      if (body.active === false) {
        const [openSalesLines, openPurchaseLine] = await Promise.all([
          tx.salesOrderLine.findMany({ where: { productId: id, salesOrder: { organizationId: user.organizationId, status: { in: ["CONFIRMED", "PROCESSING"] } } }, select: { quantity: true, fulfilledQuantity: true } }),
          tx.purchaseOrderLine.findFirst({ where: { productId: id, purchaseOrder: { organizationId: user.organizationId, status: { in: ["ORDERED", "PARTIALLY_RECEIVED"] } } } }),
        ]);
        if (openSalesLines.some((line) => line.fulfilledQuantity < line.quantity) || openPurchaseLine) throw new Error("PRODUCT_HAS_OPEN_ORDERS");
        const stock = await tx.stockMovement.aggregate({ where: { organizationId: user.organizationId, productId: id }, _sum: { quantity: true } });
        if ((stock._sum.quantity ?? 0) !== 0) throw new Error("PRODUCT_HAS_STOCK");
      }
      const updated = await tx.product.update({ where: { id: before.id }, data: { sku: sku.data, name: name.data, category: category.data, costPrice, sellingPrice, reorderLevel, ...(body.active === undefined ? {} : { active: body.active }) } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "Product", entityId: updated.id, beforeData: { sku: before.sku, name: before.name, active: before.active }, afterData: { sku: updated.sku, name: updated.name, active: updated.active, costPrice: Number(updated.costPrice), sellingPrice: Number(updated.sellingPrice) }, ipAddress: requestIp(request) });
      return updated;
    }, { isolationLevel: "Serializable" });
    return NextResponse.json({ product });
  } catch (error) {
    if (error instanceof Error && error.message === "PRODUCT_HAS_STOCK") return NextResponse.json({ error: "This product has a non-zero stock balance. Bring it to zero before archiving." }, { status: 409 });
    if (error instanceof Error && error.message === "PRODUCT_HAS_OPEN_ORDERS") return NextResponse.json({ error: "This product is used by an open sales or purchase order." }, { status: 409 });
    if (error instanceof Error && "code" in error && error.code === "P2034") return NextResponse.json({ error: "Product stock changed during this action. Refresh and try again." }, { status: 409 });
    if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "This SKU is already in use" }, { status: 409 });
    return NextResponse.json({ error: "Unable to update product" }, { status: 500 });
  }
}
