import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { readObject, readOptionalText, readText } from "@/lib/validation";

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "products.read", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const query = new URL(request.url).searchParams.get("q")?.trim() ?? "";
  const products = await db.product.findMany({
    where: { organizationId: user.organizationId, ...(query ? { OR: [{ name: { contains: query, mode: "insensitive" } }, { sku: { contains: query, mode: "insensitive" } }] } : {}) },
    include: { movements: { where: { organizationId: user.organizationId }, select: { quantity: true } } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ products: products.map(({ movements, ...product }) => ({ ...product, stock: movements.reduce((sum, movement) => sum + movement.quantity, 0) })) });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!hasPermission(user.role, "products.create", user.organization.rolePermissions)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const sku = readText(body.sku, "SKU", 1, 80);
  const name = readText(body.name, "Product name", 2, 160);
  const category = readOptionalText(body.category, "Category", 100);
  const costPrice = Number(body.costPrice ?? 0);
  const sellingPrice = Number(body.sellingPrice ?? 0);
  const reorderLevel = Number(body.reorderLevel ?? 0);
  const error = sku.error ?? name.error ?? category.error;
  if (error || !Number.isFinite(costPrice) || costPrice < 0 || !Number.isFinite(sellingPrice) || sellingPrice < 0 || !Number.isInteger(reorderLevel) || reorderLevel < 0) {
    return NextResponse.json({ error: error ?? "Prices and reorder level must be valid non-negative numbers" }, { status: 400 });
  }
  try {
    const product = await db.$transaction(async (tx) => {
      const created = await tx.product.create({ data: { organizationId: user.organizationId, sku: sku.data, name: name.data, category: category.data, costPrice, sellingPrice, reorderLevel } });
      await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "CREATE", entity: "Product", entityId: created.id, afterData: { sku: created.sku, name: created.name }, ipAddress: requestIp(request) });
      return created;
    });
    return NextResponse.json({ product }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "P2002") return NextResponse.json({ error: "This SKU already exists in your workspace" }, { status: 409 });
    return NextResponse.json({ error: "Unable to create product" }, { status: 500 });
  }
}
