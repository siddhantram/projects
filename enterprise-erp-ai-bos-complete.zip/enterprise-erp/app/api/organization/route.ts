import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { requestIp, writeAuditLog } from "@/lib/audit";
import { readObject, readOptionalText, readText } from "@/lib/validation";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!["ADMIN", "SUPER_ADMIN"].includes(user.role)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  return NextResponse.json({ organization: user.organization });
}

export async function PATCH(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (!["ADMIN", "SUPER_ADMIN"].includes(user.role)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  let body: Record<string, unknown> | null;
  try { body = readObject(await request.json()); } catch { body = null; }
  if (!body) return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  const name = readText(body.name, "Company name", 2, 120);
  const address = readOptionalText(body.address, "Address", 400);
  const taxId = readOptionalText(body.taxId, "GST/VAT number", 40);
  const currency = readText(body.currency, "Currency", 3, 3);
  const timezone = readText(body.timezone, "Timezone", 3, 80);
  const error = name.error ?? address.error ?? taxId.error ?? currency.error ?? timezone.error;
  let validTimezone = true;
  try { new Intl.DateTimeFormat("en", { timeZone: timezone.data }); } catch { validTimezone = false; }
  if (error || !/^[A-Z]{3}$/.test(currency.data) || !validTimezone) {
    return NextResponse.json({ error: error ?? "Choose a valid currency code and timezone" }, { status: 400 });
  }
  const beforeData = { name: user.organization.name, address: user.organization.address, taxId: user.organization.taxId, currency: user.organization.currency, timezone: user.organization.timezone };
  const organization = await db.$transaction(async (tx) => {
    const updated = await tx.organization.update({ where: { id: user.organizationId }, data: { name: name.data, address: address.data, taxId: taxId.data, currency: currency.data, timezone: timezone.data } });
    await writeAuditLog(tx, { organizationId: user.organizationId, userId: user.id, action: "UPDATE", entity: "Organization", entityId: user.organizationId, beforeData, afterData: { name: updated.name, address: updated.address, taxId: updated.taxId, currency: updated.currency, timezone: updated.timezone }, ipAddress: requestIp(request) });
    return updated;
  });
  return NextResponse.json({ organization });
}
