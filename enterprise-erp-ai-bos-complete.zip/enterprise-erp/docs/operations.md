# Operations runbook

## Deployment sequence

1. Provision PostgreSQL with automated backups and point-in-time recovery enabled. Keep database credentials in the deployment platform's secret store.
2. Deploy the application to a platform with HTTPS termination. Set `DATABASE_URL` as a secret and use Node.js 20.9 or newer.
3. Install the lockfile dependencies with `npm ci` and build with `npm run build`.
4. Before starting the new application version, apply reviewed database migrations with `npx prisma migrate deploy`.
5. Start the app with `npm start`. Use `GET /api/health` for the load balancer's readiness probe.
6. Monitor application errors, PostgreSQL health, disk capacity and backup completion from the hosting provider.

### Docker deployment

The repository includes `Dockerfile` and `compose.production.yaml` for a provider-neutral production image. Provision PostgreSQL separately (prefer a managed service), make `DATABASE_URL` reachable from the app container, and configure the remaining runtime secrets using `.env.example` as a checklist. Do not use the local Compose database credentials in a deployed environment.

Build and run reviewed migrations as a one-off release step, then start the app:

```sh
docker compose -f compose.production.yaml build app migrate
docker compose -f compose.production.yaml --profile migrate run --rm migrate
docker compose -f compose.production.yaml up -d app
```

The app binds to `127.0.0.1:3000` on the host so a TLS-terminating reverse proxy can route traffic to it. Configure the proxy and firewall, then use `/api/health` for readiness monitoring. Keep `.env` out of the image and source control. This setup builds and runs the application; wiring it to a specific hosting provider and configuring its secrets, TLS, database, off-site backup copies and alerts are environment-specific release tasks.

To run the optional scheduled backup container, build it and enable its Compose profile:

```sh
docker compose -f compose.production.yaml build backup
docker compose -f compose.production.yaml --profile backup up -d backup
```

The service takes an initial backup, then repeats every `BACKUP_INTERVAL_SECONDS` (default 86400, minimum 3600) and removes local dump files older than `BACKUP_RETENTION_DAYS` (default 30, minimum 1). Dumps live in the named `enterprise_erp_backups` volume, and the container health check becomes unhealthy if no recent dump exists. Inspect service logs and health in Docker. This local volume is not an off-site backup: sync it to encrypted storage in a separate account/region and configure provider alerts before relying on it for disaster recovery. Managed PostgreSQL backup/PITR remains preferred.

Do not run `prisma migrate dev` against production. It is a development command and can create or reset schema state interactively.

## Backup and restore

- Prefer encrypted automated PostgreSQL backups and point-in-time recovery in the database provider. The optional self-hosted Compose backup profile provides recurring local dumps but does not replace off-site backup.
- Keep backups in a separate account or region and define a retention period that meets the business recovery requirement. Configure monitoring/alerts on the backup service health and external copy job.
- The repository backup command writes a PostgreSQL custom-format dump to `BACKUP_DIR` (default `./backups`) and never includes credentials in the dump filename or process arguments. Run it from a trusted operations host with PostgreSQL client tools installed and `DATABASE_URL` provided through the environment or secret manager:

  ```sh
  npm run db:backup
  ```

- Test restore into a new, empty, isolated database before relying on a backup. Set `RESTORE_DATABASE_URL` to that disposable database; its name must start with `enterprise_erp_restore`. When `DATABASE_URL` is also set, the command refuses to restore into that same host, port and database. It refuses a target that already has user tables and does not drop or clean the target database:

  ```sh
  npm run db:restore-check -- ./backups/enterprise-erp-<timestamp>-<id>.dump
  ```

- The restore check validates the dump archive, restores it with `pg_restore`, and checks that the core organization and user tables can be queried. It leaves the restored database in place for inspection; remove it using the database provider's normal isolated-database procedure after review.
- Restrict backup access to the operations role. Never commit database dumps, credentials or `.env` files.

## Application security

- The app sets baseline browser security headers. The deployment must provide HTTPS; production HSTS is enabled in the Next.js configuration.
- Keep `DATABASE_URL` private, rotate credentials after exposure, and use a database role with only the privileges required by the app and migrations.
- Public registration is disabled by default in production. Temporarily set `ALLOW_PUBLIC_REGISTRATION=true` only for initial bootstrap, create the first administrator, then remove the setting and restart. Administrators can create later users from the Users and roles screen.
- Password recovery uses Resend. Set `APP_URL` to the canonical HTTPS application URL, `RESEND_API_KEY` to a restricted provider key, and `EMAIL_FROM` to a verified sender. Recovery messages use generic responses, request limits, hashed one-time tokens and a 30-minute expiry; completing a reset revokes all sessions for that user. Without these settings the request endpoint returns a configuration error and sends no reset link.
- TOTP MFA is optional per user. Set `AUTH_ENCRYPTION_KEY` to a secret 32-byte key encoded as 64 hexadecimal characters; generate one with `node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"` and keep it in the deployment secret store. Back it up securely: losing or rotating it without re-enrollment makes existing MFA secrets unreadable. Enrollment requires an authenticator app and confirmation code; recovery codes are displayed once. Enabling MFA revokes other sessions, and login requires a current TOTP or unused recovery code. A workspace administrator can reset another member's MFA from Users; that action revokes the member's sessions and is audited.
- The login endpoint uses database-backed throttling. Configure the reverse proxy to set a trusted `X-Real-IP` header; the application also limits attempts per normalized account email.
- Review user roles, configurable permission grants, MFA enrollment and audit history regularly.

## Release checks

- Review schema and SQL migration changes before deployment. Never replace an already-applied migration checksum. Before upgrading a database, compare its `_prisma_migrations` history with the checked-in migrations; if an earlier development baseline was applied, reconcile the actual database schema and migration history in staging before deploying.
- The GitHub Actions workflow runs dependency installation, Prisma client generation, TypeScript checks, lint and a production build on pushes and pull requests. Run approved dependency and security scans before release as well.
- Validate login, role-based navigation, server-rendered page access and action visibility, tenant separation, HR salary/payroll confidentiality and attendance/leave read scopes, customer CSV exports, sales-order cancellation guards (no fulfilled quantities or invoice), invoice/payment posting, stock movement and cross-warehouse transfer balances (including rejection of standalone transfer entries and manual purchase/sale movements), inventory CSV export, leave/payroll and backup restore in a staging environment.
- Configure an external uptime monitor and alert channel; the health endpoint does not send alerts itself.
