import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import type { Prisma } from "@/generated/prisma/client";
import { db } from "@/lib/db";

const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

export function createTotpSecret() {
  return encodeBase32(randomBytes(20));
}

export function encryptTotpSecret(secret: string) {
  const key = encryptionKey();
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const encrypted = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), encrypted]).toString("base64url");
}

export function decryptTotpSecret(payload: string) {
  const key = encryptionKey();
  const packed = Buffer.from(payload, "base64url");
  if (packed.length < 29) throw new Error("Stored MFA secret is invalid");
  const decipher = createDecipheriv("aes-256-gcm", key, packed.subarray(0, 12));
  decipher.setAuthTag(packed.subarray(12, 28));
  return Buffer.concat([decipher.update(packed.subarray(28)), decipher.final()]).toString("utf8");
}

export function verifyTotp(secret: string, value: string, now = Date.now()) {
  if (!/^\d{6}$/.test(value)) return false;
  const counter = Math.floor(now / 30_000);
  for (const drift of [-1, 0, 1]) {
    const bytes = Buffer.alloc(8);
    bytes.writeBigUInt64BE(BigInt(counter + drift));
    const digest = createHmac("sha1", decodeBase32(secret)).update(bytes).digest();
    const offset = digest[digest.length - 1] & 0x0f;
    const binary = ((digest[offset] & 0x7f) << 24) | ((digest[offset + 1] & 0xff) << 16) | ((digest[offset + 2] & 0xff) << 8) | (digest[offset + 3] & 0xff);
    const expected = Buffer.from(String(binary % 1_000_000).padStart(6, "0"));
    const actual = Buffer.from(value);
    if (timingSafeEqual(expected, actual)) return true;
  }
  return false;
}

export function createRecoveryCodes() {
  return Array.from({ length: 10 }, () => randomBytes(10).toString("hex").toUpperCase().match(/.{1,4}/g)!.join("-"));
}

export function recoveryCodeHash(value: string) {
  return createHash("sha256").update(value.replace(/[-\s]/g, "").toUpperCase()).digest("hex");
}

export async function consumeRecoveryCode(userId: string, value: string, tx: Prisma.TransactionClient = db) {
  const changed = await tx.mfaRecoveryCode.updateMany({ where: { userId, codeHash: recoveryCodeHash(value), usedAt: null }, data: { usedAt: new Date() } });
  return changed.count === 1;
}

function encryptionKey() {
  const value = process.env.AUTH_ENCRYPTION_KEY ?? "";
  if (!/^[0-9a-fA-F]{64}$/.test(value)) throw new Error("AUTH_ENCRYPTION_KEY must be 32 bytes encoded as 64 hexadecimal characters");
  return Buffer.from(value, "hex");
}

function encodeBase32(bytes: Buffer) {
  let bits = 0;
  let value = 0;
  let output = "";
  for (const byte of bytes) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      output += alphabet[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits) output += alphabet[(value << (5 - bits)) & 31];
  return output;
}

function decodeBase32(value: string) {
  let bits = 0;
  let buffer = 0;
  const output: number[] = [];
  for (const character of value.replace(/=+$/, "").toUpperCase()) {
    const index = alphabet.indexOf(character);
    if (index < 0) throw new Error("Stored MFA secret is invalid");
    buffer = (buffer << 5) | index;
    bits += 5;
    if (bits >= 8) {
      output.push((buffer >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(output);
}
