import type { RoleName, Prisma } from "@/generated/prisma/client";

export async function notifyRoles(
  tx: Prisma.TransactionClient,
  organizationId: string,
  roles: RoleName[],
  title: string,
  message: string,
  href?: string,
) {
  const recipients = await tx.user.findMany({ where: { organizationId, active: true, role: { in: roles } }, select: { id: true } });
  if (!recipients.length) return;
  await tx.notification.createMany({ data: recipients.map(({ id }) => ({ organizationId, userId: id, title, message, href })) });
}
