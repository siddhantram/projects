export type ValidationResult<T> = { data: T; error: string | null };

export function readObject(value: unknown): Record<string, unknown> | null {
  return typeof value === "object" && value !== null && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

export function readText(value: unknown, label: string, min = 1, max = 200): ValidationResult<string> {
  if (typeof value !== "string") return { data: "", error: `${label} is required` };
  const clean = value.trim();
  if (clean.length < min || clean.length > max) return { data: "", error: `${label} must be between ${min} and ${max} characters` };
  return { data: clean, error: null };
}

export function readEmail(value: unknown): ValidationResult<string> {
  const result = readText(value, "Email", 3, 254);
  if (result.error) return result;
  const email = result.data.toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { data: "", error: "Enter a valid email address" };
  return { data: email, error: null };
}

export function readOptionalText(value: unknown, label: string, max = 200): ValidationResult<string | null> {
  if (value === undefined || value === null || value === "") return { data: null, error: null };
  const result = readText(value, label, 0, max);
  return { data: result.error ? null : result.data, error: result.error };
}
