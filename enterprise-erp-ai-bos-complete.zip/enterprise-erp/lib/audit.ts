import type { AuditAction, Prisma } from "@/generated/prisma/client";

type AuditEntry = {
  organizationId: string;
  userId: string;
  action: AuditAction;
  entity: string;
  entityId?: string;
  beforeData?: Prisma.InputJsonObject;
  afterData?: Prisma.InputJsonObject;
  ipAddress?: string | null;
};

export function writeAuditLog(tx: Prisma.TransactionClient, entry: AuditEntry) {
  return tx.auditLog.create({ data: entry });
}

export function requestIp(request: Request) {
  return request.headers.get("x-real-ip")?.slice(0, 64) ?? null;
}
