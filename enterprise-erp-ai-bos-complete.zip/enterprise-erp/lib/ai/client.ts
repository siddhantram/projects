const OPENAI_URL = "https://api.openai.com/v1/chat/completions";
const EMBEDDING_URL = "https://api.openai.com/v1/embeddings";

function key() {
  return process.env.OPENAI_API_KEY;
}

export async function generateAIResponse(messages: Array<{role:"system"|"user"|"assistant"; content:string}>) {
  const apiKey = key();
  if (!apiKey) return null;
  const model = process.env.OPENAI_MODEL || "gpt-5-mini";
  const response = await fetch(OPENAI_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model, messages, temperature: 0.2 }),
    cache: "no-store",
  });
  if (!response.ok) throw new Error(`OpenAI request failed: ${response.status}`);
  const json = await response.json() as { choices?: Array<{ message?: { content?: string } }> };
  return json.choices?.[0]?.message?.content?.trim() ?? null;
}

export async function createEmbedding(input: string) {
  const apiKey = key();
  if (!apiKey) return null;
  const model = process.env.OPENAI_EMBEDDING_MODEL || "text-embedding-3-small";
  const response = await fetch(EMBEDDING_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model, input }),
    cache: "no-store",
  });
  if (!response.ok) throw new Error(`Embedding request failed: ${response.status}`);
  const json = await response.json() as { data?: Array<{ embedding?: number[] }> };
  return json.data?.[0]?.embedding ?? null;
}
