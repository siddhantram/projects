import { db } from "@/lib/db";

export async function getSalesSummary(organizationId: string) {
  const [orders, leads] = await Promise.all([
    db.salesOrder.aggregate({ where: { organizationId }, _sum: { total: true }, _count: { _all: true } }),
    db.salesLead.groupBy({ by: ["status"], where: { organizationId }, _count: { _all: true } }),
  ]);
  return { salesOrders: orders._count._all, salesValue: Number(orders._sum.total ?? 0), leadsByStatus: leads };
}

export async function getLowStockProducts(organizationId: string) {
  const products = await db.product.findMany({ where: { organizationId, active: true }, select: { id:true,name:true,sku:true,reorderLevel:true } });
  const result = [];
  for (const p of products) {
    const movements = await db.stockMovement.aggregate({ where: { organizationId, productId:p.id }, _sum:{ quantity:true } });
    const stock = movements._sum.quantity ?? 0;
    if (stock <= p.reorderLevel) result.push({ name:p.name, sku:p.sku, stock, reorderLevel:p.reorderLevel });
  }
  return result;
}
