import { db } from "@/lib/db";

export async function getBusinessContext(organizationId: string) {
  const [customers, leads, products, invoices, expenses, employees, overdue] = await Promise.all([
    db.customer.count({ where: { organizationId, active: true } }),
    db.salesLead.count({ where: { organizationId } }),
    db.product.count({ where: { organizationId, active: true } }),
    db.invoice.aggregate({ where: { organizationId }, _sum: { total: true, amountPaid: true }, _count: { _all: true } }),
    db.expense.aggregate({ where: { organizationId }, _sum: { amount: true }, _count: { _all: true } }),
    db.employee.count({ where: { organizationId, active: true } }),
    db.invoice.aggregate({
      where: { organizationId, dueAt: { lt: new Date() }, status: { in: ["SENT", "PARTIALLY_PAID", "OVERDUE"] } },
      _sum: { total: true, amountPaid: true }, _count: { _all: true }
    }),
  ]);
  return {
    customers, leads, products, employees,
    invoices: { count: invoices._count._all, total: Number(invoices._sum.total ?? 0), paid: Number(invoices._sum.amountPaid ?? 0) },
    expenses: { count: expenses._count._all, total: Number(expenses._sum.amount ?? 0) },
    overdueInvoices: { count: overdue._count._all, total: Number(overdue._sum.total ?? 0), paid: Number(overdue._sum.amountPaid ?? 0) },
  };
}
