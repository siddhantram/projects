import { db } from "@/lib/db";
import { randomUUID } from "node:crypto";
import { createEmbedding } from "@/lib/ai/client";

const chunkText = (text: string, size = 1200, overlap = 150) => {
  const clean = text.replace(/\u0000/g, "").replace(/\r/g, "").trim();
  const chunks: string[] = [];
  for (let start = 0; start < clean.length; start += size - overlap) {
    chunks.push(clean.slice(start, start + size));
    if (start + size >= clean.length) break;
  }
  return chunks;
};

export async function indexDocument(documentId: string, organizationId: string, text: string) {
  const chunks = chunkText(text);
  await db.aIDocumentChunk.deleteMany({ where: { documentId } });
  const embeddingReady = Boolean(process.env.OPENAI_API_KEY);
  for (let i = 0; i < chunks.length; i++) {
    const embedding = embeddingReady ? await createEmbedding(chunks[i]) : null;
    if (embedding) {
      const vector = `[${embedding.join(",")}]`;
      await db.$executeRawUnsafe(
        `INSERT INTO "AIDocumentChunk" ("id","documentId","chunkIndex","content","embedding","createdAt")
         VALUES ($1,$2,$3,$4,$5::vector,NOW())`,
        randomUUID(), documentId, i, chunks[i], vector
      );
    } else {
      await db.aIDocumentChunk.create({ data: { documentId, chunkIndex: i, content: chunks[i] } });
    }
  }
  await db.aIDocument.update({ where: { id: documentId }, data: { status: "READY", textContent: text.slice(0, 100000) } });
}

export async function searchKnowledge(organizationId: string, query: string, limit = 5) {
  const embedding = process.env.OPENAI_API_KEY ? await createEmbedding(query) : null;
  if (!embedding) {
    const docs = await db.aIDocumentChunk.findMany({
      where: { document: { organizationId, status: "READY" }, content: { contains: query.split(/\s+/)[0] || "", mode: "insensitive" } },
      include: { document: { select: { name: true } } }, take: limit,
    });
    return docs.map(d => ({ content: d.content, source: d.document.name }));
  }
  const vector = `[${embedding.join(",")}]`;
  const rows = await db.$queryRawUnsafe<Array<{content:string; source:string; distance:number}>>(
    `SELECT c."content", d."name" as source, c.embedding <=> $1::vector as distance
     FROM "AIDocumentChunk" c JOIN "AIDocument" d ON d.id=c."documentId"
     WHERE d."organizationId"=$2 AND d."status"='READY' AND c.embedding IS NOT NULL
     ORDER BY c.embedding <=> $1::vector LIMIT $3`,
    vector, organizationId, limit
  );
  return rows;
}
