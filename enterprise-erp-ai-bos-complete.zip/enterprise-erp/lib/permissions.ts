import type { RoleName } from "@/generated/prisma/client";

export const editableRoles = ["MANAGER", "ACCOUNTANT", "HR", "SALES", "INVENTORY_MANAGER", "EMPLOYEE"] as const satisfies readonly RoleName[];

export const permissionCatalog = [
  "customers.read", "customers.create", "customers.update", "customers.delete",
  "products.read", "products.create", "products.update",
  "inventory.read", "inventory.create",
  "sales.read", "sales.create", "sales.approve", "sales.fulfill",
  "invoices.read", "invoices.create", "payments.read", "payments.create",
  "purchases.read", "purchases.create", "purchases.update", "purchases.approve", "purchases.receive", "purchases.invoice", "purchases.pay",
  "finance.read", "finance.create", "reports.read", "audit.read",
  "employees.read", "employees.create", "attendance.self", "leave.create", "leave.approve",
  "attendance.read", "leave.read", "payroll.read", "payroll.create", "payroll.approve", "payroll.pay", "notifications.read",
] as const;

export type Permission = typeof permissionCatalog[number];

export const defaultPermissions: Record<RoleName, string[]> = {
  SUPER_ADMIN: ["*"],
  ADMIN: ["*"],
  MANAGER: ["customers.*", "products.*", "inventory.read", "sales.*", "sales.fulfill", "invoices.*", "payments.*", "purchases.read", "purchases.update", "finance.read", "reports.read", "audit.read", "notifications.read"],
  ACCOUNTANT: ["finance.*", "sales.read", "invoices.*", "payments.*", "purchases.read", "purchases.invoice", "purchases.pay", "customers.read", "products.read", "inventory.read", "reports.read"],
  HR: ["employees.*", "attendance.*", "leave.*", "payroll.*", "notifications.read", "audit.read"],
  SALES: ["customers.*", "sales.*", "sales.fulfill", "invoices.create", "invoices.read", "payments.create", "payments.read", "products.read", "inventory.read"],
  INVENTORY_MANAGER: ["products.*", "inventory.*", "purchases.*"],
  EMPLOYEE: ["customers.read", "products.read", "inventory.read", "attendance.self", "leave.create", "notifications.read"],
};

function matches(grants: string[], permission: string) {
  return grants.some((granted) => granted === "*" || granted === permission || (granted.endsWith(".*") && permission.startsWith(granted.slice(0, -1))));
}

export function effectivePermissions(role: RoleName, overrides?: unknown) {
  if (role === "ADMIN" || role === "SUPER_ADMIN") return ["*"];
  if (overrides && typeof overrides === "object" && !Array.isArray(overrides)) {
    const candidate = (overrides as Record<string, unknown>)[role];
    if (Array.isArray(candidate) && candidate.every((permission) => typeof permission === "string")) return candidate;
  }
  return defaultPermissions[role];
}

export function hasPermission(role: RoleName, permission: string, overrides?: unknown) {
  return matches(effectivePermissions(role, overrides), permission);
}
