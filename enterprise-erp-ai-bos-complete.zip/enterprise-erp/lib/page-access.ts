import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { hasPermission, type Permission } from "@/lib/permissions";

export async function requirePageUser() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

export async function requirePagePermission(permission: Permission) {
  const user = await requirePageUser();
  if (!hasPermission(user.role, permission, user.organization.rolePermissions)) redirect("/dashboard");
  return user;
}

export async function requirePageAnyPermission(permissions: Permission[]) {
  const user = await requirePageUser();
  if (!permissions.some((permission) => hasPermission(user.role, permission, user.organization.rolePermissions))) redirect("/dashboard");
  return user;
}

export async function requirePageAdmin() {
  const user = await requirePageUser();
  if (user.role !== "ADMIN" && user.role !== "SUPER_ADMIN") redirect("/dashboard");
  return user;
}
