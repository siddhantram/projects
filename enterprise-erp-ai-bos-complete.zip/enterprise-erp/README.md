# Enterprise ERP

Multi-tenant ERP application built with Next.js 16, TypeScript, PostgreSQL and Prisma ORM 7.

## Run locally

Requirements: Node.js 20.9 or newer and PostgreSQL. For local development, Docker Compose can run PostgreSQL for you.

1. Copy `.env.example` to `.env`.
2. Start the local database with `docker compose up -d postgres`, or provision PostgreSQL yourself and set `DATABASE_URL` in `.env`.
3. Install dependencies with `npm install`.
4. Apply all pending migrations with `npm run db:migrate`.
5. Start the app with `npm run dev` and open `http://localhost:3000`.

Use `npm run db:studio` to open Prisma Studio. The Compose database binds to localhost and uses development-only credentials; never reuse them outside local development. Its named volume persists between container restarts. For production, build and run the app using `Dockerfile` and `compose.production.yaml`; follow [the migration and deployment runbook](docs/operations.md) and apply reviewed migrations before starting the app.

The first registered account creates an organization and receives the `ADMIN` role. Passwords use scrypt hashes; sessions use random HTTP-only cookies whose digests are stored in PostgreSQL.

## Implemented

- Tenant-scoped organizations, accounts, settings, session authentication, workspace user administration and role permission checks.
- Tenant-configurable permission grants for non-administrator roles; administrator roles retain full workspace access. Dashboard navigation, server-rendered module pages, finance creation controls and organization settings follow those grants.
- Customer directory with search, pagination, filtered CSV export, edit and archive/restore while retaining transaction history; customer lifecycle timeline for leads, quotations, orders, invoices, payments and account changes; product catalog with edit/archive/restore and warehouses.
- Inventory movement ledger with stock balance checks, purchase receipt integration, audited atomic transfers between warehouses and per-location stock CSV export.
- Sales lead follow-up scheduling with overdue visibility and qualified-lead-to-customer conversion, expiring printable quotations with sent/approved/rejected states, order conversion, warehouse stock fulfilment, approval-controlled cancellation before fulfilment or invoicing, invoices and payments.
- Supplier records with permission-controlled editing and archive/restore, separately approved and placed purchase orders, cancellation before receipt, partial goods receipts, supplier invoices, payment tracking and accounts payable posting. Archived suppliers remain in historical records and must be restored before new orders or invoices.
- Double-entry journal posting (including manual balanced entries), tenant-specific chart-of-accounts additions, expense capture, account ledger drilldown, income statement, balance sheet, classified cash-flow statement and cash-position snapshot.
- Date-filtered finance summaries for revenue, expenses, profit and cash-account movement, with period CSV export.
- HR employee and department records, attendance self-service, leave review and payroll posting; employee salary and payroll, attendance, and leave listings require their respective read grants.
- Admin temporary-password reset and signed-in password change with audit entries and session revocation.
- Email-based self-service password recovery using expiring, single-use reset links; reset revokes every active session.
- Optional TOTP multi-factor authentication with encrypted secrets, one-time recovery codes, audited enrollment and login enforcement.
- Tenant-scoped audit history with date, action and record-type filters, paginated review and CSV export; per-user notification inbox.
- Month-filtered accounting analytics (up to 36 months), invoice status exposure, activity counts and a current low-stock snapshot with the total alert count and top-20 product list.
- Spreadsheet-friendly CSV export for monthly finance, invoice exposure and low-stock analytics.
- Database-backed login throttling, baseline security headers and a database readiness endpoint.
- GitHub Actions CI workflow for dependency installation, Prisma client generation, TypeScript checks, lint, production build and production container build.
- PostgreSQL custom-format backup and isolated restore verification commands, plus an optional scheduled Docker backup service with local retention and health reporting; backups are excluded from source control.

Business APIs derive the tenant from the authenticated session and do not accept a tenant ID from the browser.

## Remaining work

The application remains a development foundation rather than a production-complete ERP. Broader customer lifecycle workflows, provider-specific automated deployment and off-site backup/restore alerting remain outstanding. The optional backup service stores local dumps and reports stale backups through its container health check; configure encrypted off-site copies and provider alerts before relying on it for disaster recovery. See [the operations runbook](docs/operations.md) before deploying. Apply pending forward migrations to existing databases before using their features. Configure the email recovery and MFA variables from `.env.example` before enabling those features. Do not replace an already-applied migration file.
