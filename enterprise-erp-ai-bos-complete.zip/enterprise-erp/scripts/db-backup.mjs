import { createWriteStream } from "node:fs";
import { mkdir, rm } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { randomUUID } from "node:crypto";
import { pipeline } from "node:stream/promises";
import { spawn } from "node:child_process";
import { connectionFromUrl } from "./postgres-connection.mjs";

const connection = connectionFromUrl(process.env.DATABASE_URL, "DATABASE_URL");
const directory = resolve(process.env.BACKUP_DIR || "backups");
const timestamp = new Date().toISOString().replaceAll(":", "-");
const target = resolve(directory, `enterprise-erp-${timestamp}-${randomUUID()}.dump`);
const partial = `${target}.partial`;
await mkdir(dirname(target), { recursive: true });

const child = spawn("pg_dump", ["--format=custom", "--no-owner", "--no-acl", "--dbname", connection.database], {
  env: connection.env,
  stdio: ["ignore", "pipe", "pipe"],
});
let stderr = "";
child.stderr.setEncoding("utf8");
child.stderr.on("data", (chunk) => { stderr = (stderr + chunk).slice(-12000); });
const output = createWriteStream(partial, { flags: "wx", mode: 0o600 });

try {
  await Promise.all([
    pipeline(child.stdout, output),
    new Promise((resolveExit, rejectExit) => {
      child.on("error", (error) => rejectExit(new Error(`Unable to start pg_dump: ${error.message}`)));
      child.on("close", (code) => code === 0 ? resolveExit() : rejectExit(new Error(`pg_dump failed with exit code ${code}${stderr.trim() ? `: ${stderr.trim()}` : "."}`)));
    }),
  ]);
  const { rename } = await import("node:fs/promises");
  await rename(partial, target);
  console.log(`Backup created: ${target}`);
} catch (error) {
  child.kill();
  output.destroy();
  await rm(partial, { force: true });
  throw error;
}
