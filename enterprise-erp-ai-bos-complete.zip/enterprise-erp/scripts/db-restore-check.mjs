import { resolve } from "node:path";
import { access, stat } from "node:fs/promises";
import { assertIsolatedRestoreTarget, connectionFromUrl, run, runForOutput } from "./postgres-connection.mjs";

const backupFile = process.argv[2];
if (!backupFile) throw new Error("Usage: npm run db:restore-check -- <backup-file>");
const backupPath = resolve(backupFile);
await access(backupPath);
if ((await stat(backupPath)).size === 0) throw new Error("Backup file is empty.");
const target = assertIsolatedRestoreTarget(process.env.RESTORE_DATABASE_URL, process.env.DATABASE_URL);

await run("pg_restore", ["--list", backupPath]);
const existingTables = await runForOutput("psql", ["--no-psqlrc", "--set", "ON_ERROR_STOP=1", "--tuples-only", "--no-align", "--dbname", target.database, "--command", "SELECT count(*) FROM pg_tables WHERE schemaname NOT IN ('pg_catalog', 'information_schema');"], target.env);
if (existingTables !== "0") throw new Error("Restore target is not empty. Create a new disposable database and retry.");
await run("pg_restore", ["--exit-on-error", "--no-owner", "--no-acl", "--dbname", target.database, backupPath], target.env);
await run("psql", ["--no-psqlrc", "--set", "ON_ERROR_STOP=1", "--quiet", "--dbname", target.database, "--command", 'SELECT 1 FROM public."Organization" LIMIT 1; SELECT 1 FROM public."User" LIMIT 1;'], target.env);
const source = process.env.DATABASE_URL ? connectionFromUrl(process.env.DATABASE_URL, "DATABASE_URL") : null;
console.log(`Restore verification succeeded in isolated database ${target.database}${source ? ` on ${target.host}:${target.port}` : ""}. The target database was left intact for inspection.`);
