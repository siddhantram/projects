#!/bin/sh
set -eu

interval="${BACKUP_INTERVAL_SECONDS:-86400}"
retention="${BACKUP_RETENTION_DAYS:-30}"

case "$interval" in ''|*[!0-9]*) echo "BACKUP_INTERVAL_SECONDS must be an integer." >&2; exit 1 ;; esac
case "$retention" in ''|*[!0-9]*) echo "BACKUP_RETENTION_DAYS must be an integer." >&2; exit 1 ;; esac
[ "$interval" -ge 3600 ] || { echo "BACKUP_INTERVAL_SECONDS must be at least 3600." >&2; exit 1; }
[ "$retention" -ge 1 ] || { echo "BACKUP_RETENTION_DAYS must be at least 1." >&2; exit 1; }

mkdir -p "${BACKUP_DIR:-/backups}"
while :; do
  echo "Starting PostgreSQL backup at $(date -u +%Y-%m-%dT%H:%M:%SZ)."
  if node /app/scripts/db-backup.mjs; then
    echo "PostgreSQL backup completed. Removing local dumps older than ${retention} days."
    find "${BACKUP_DIR:-/backups}" -type f -name 'enterprise-erp-*.dump' -mtime "+$retention" -delete
  else
    echo "PostgreSQL backup failed; existing dumps were retained." >&2
  fi
  sleep "$interval"
done
