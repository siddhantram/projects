import { spawn } from "node:child_process";
import { loadEnvConfig } from "@next/env";

loadEnvConfig(process.cwd());

export function connectionFromUrl(value, variableName) {
  if (!value) throw new Error(`${variableName} is required.`);
  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error(`${variableName} must be a valid PostgreSQL connection URL.`);
  }
  if (!["postgres:", "postgresql:"].includes(url.protocol) || !url.hostname || !url.username || !url.pathname || url.pathname === "/") {
    throw new Error(`${variableName} must include a PostgreSQL host, user and database name.`);
  }
  const database = decodeURIComponent(url.pathname.slice(1));
  if (database.includes("/")) throw new Error(`${variableName} has an invalid database name.`);
  const env = { ...process.env, PGHOST: url.hostname, PGPORT: url.port || "5432", PGUSER: decodeURIComponent(url.username), PGDATABASE: database };
  if (url.password) env.PGPASSWORD = decodeURIComponent(url.password);
  const sslmode = url.searchParams.get("sslmode");
  if (sslmode && ["disable", "allow", "prefer", "require", "verify-ca", "verify-full"].includes(sslmode)) env.PGSSLMODE = sslmode;
  return { database, env, host: url.hostname, port: url.port || "5432" };
}

export function run(command, args, env = process.env) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { env, stdio: ["ignore", "ignore", "pipe"] });
    let stderr = "";
    child.stderr.setEncoding("utf8");
    child.stderr.on("data", (chunk) => { stderr = (stderr + chunk).slice(-12000); });
    child.on("error", (error) => reject(new Error(`Unable to start ${command}: ${error.message}`)));
    child.on("close", (code) => code === 0 ? resolve(stderr.trim()) : reject(new Error(`${command} failed with exit code ${code}${stderr.trim() ? `: ${stderr.trim()}` : "."}`)));
  });
}

export function runForOutput(command, args, env = process.env) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { env, stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk) => { stdout = (stdout + chunk).slice(-12000); });
    child.stderr.on("data", (chunk) => { stderr = (stderr + chunk).slice(-12000); });
    child.on("error", (error) => reject(new Error(`Unable to start ${command}: ${error.message}`)));
    child.on("close", (code) => code === 0 ? resolve(stdout.trim()) : reject(new Error(`${command} failed with exit code ${code}${stderr.trim() ? `: ${stderr.trim()}` : "."}`)));
  });
}

export function assertIsolatedRestoreTarget(restoreUrl, sourceUrl) {
  const target = connectionFromUrl(restoreUrl, "RESTORE_DATABASE_URL");
  if (!target.database.toLowerCase().startsWith("enterprise_erp_restore")) {
    throw new Error('RESTORE_DATABASE_URL must point to a disposable database whose name starts with "enterprise_erp_restore".');
  }
  if (sourceUrl) {
    const source = connectionFromUrl(sourceUrl, "DATABASE_URL");
    if (target.host === source.host && target.port === source.port && target.database === source.database) {
      throw new Error("The restore target must be a different database from DATABASE_URL.");
    }
  }
  return target;
}
