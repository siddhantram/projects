import { NextResponse } from "next/server";
import { getAIProvider } from "@/lib/ai/provider";
import { runMockAI } from "@/lib/ai/mock";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const message = typeof body?.message === "string" ? body.message : "";

    if (!message.trim()) {
      return NextResponse.json(
        { success: false, error: "Message is required." },
        { status: 400 }
      );
    }

    const provider = getAIProvider();

    // Free development mode: no API key or paid provider required.
    if (provider === "mock") {
      const result = await runMockAI({ message });
      return NextResponse.json({
        success: true,
        provider: "mock",
        ...result,
      });
    }

    // Keep the real provider path explicit. Existing OpenAI implementation
    // can be wired here when the project has an API key.
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json(
        {
          success: false,
          error:
            "AI_PROVIDER=openai but OPENAI_API_KEY is missing. Set AI_PROVIDER=mock for free local development.",
        },
        { status: 503 }
      );
    }

    return NextResponse.json(
      {
        success: false,
        error:
          "OpenAI provider is configured but requires the project's existing OpenAI client implementation.",
      },
      { status: 501 }
    );
  } catch {
    return NextResponse.json(
      { success: false, error: "Unable to process AI request." },
      { status: 500 }
    );
  }
}
