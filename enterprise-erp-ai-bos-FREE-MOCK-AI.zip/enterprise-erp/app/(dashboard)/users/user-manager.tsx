"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";

type Role = "SUPER_ADMIN" | "ADMIN" | "MANAGER" | "ACCOUNTANT" | "HR" | "SALES" | "INVENTORY_MANAGER" | "EMPLOYEE";
type User = { id: string; name: string; email: string; role: Role; active: boolean; mfaEnabledAt: string | null; createdAt: string };
const labels: Record<Role, string> = { SUPER_ADMIN: "Super admin", ADMIN: "Admin", MANAGER: "Manager", ACCOUNTANT: "Accountant", HR: "HR", SALES: "Sales", INVENTORY_MANAGER: "Inventory manager", EMPLOYEE: "Employee" };

export default function UserManager({ actorId, canManageSuperAdmins }: { actorId: string; canManageSuperAdmins: boolean }) {
  const [users, setUsers] = useState<User[]>([]);
  const [open, setOpen] = useState(false);
  const [resetUser, setResetUser] = useState<User | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/users"); const result = await response.json();
      if (response.ok) setUsers(result.users); else setError(result.error ?? "Unable to load users");
    } catch { setError("Unable to load users"); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      const response = await fetch("/api/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.fromEntries(new FormData(event.currentTarget).entries())) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to create account"); return; }
      setOpen(false); await load();
    } catch { setError("Network error. Please try again."); }
    finally { setBusy(false); }
  }

  async function update(user: User, changes: Partial<Pick<User, "role" | "active">>) {
    setError("");
    try {
      const response = await fetch(`/api/users/${user.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(changes) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to update account"); return; }
      setUsers((current) => current.map((item) => item.id === user.id ? result.user : item));
    } catch { setError("Network error. Please try again."); }
  }

  async function resetPassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!resetUser) return;
    setBusy(true); setError("");
    try {
      const form = new FormData(event.currentTarget);
      const response = await fetch(`/api/users/${resetUser.id}/password`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password: form.get("password") }) });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to reset password"); return; }
      setResetUser(null);
    } catch { setError("Network error. Please try again."); }
    finally { setBusy(false); }
  }

  async function resetMfa(user: User) {
    if (!window.confirm(`Reset multi-factor authentication for ${user.name}? Their active sessions and recovery codes will be revoked.`)) return;
    setError(""); setNotice("");
    try {
      const response = await fetch(`/api/users/${user.id}/mfa`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) { setError(result.error ?? "Unable to reset MFA"); return; }
      setNotice(result.message ?? "MFA reset.");
      await load();
    } catch { setError("Network error. Please try again."); }
  }

  return <>
    {error && <div className="inline-error" role="alert">{error}</div>}
    {notice && <p className="form-success" role="status">{notice}</p>}
    <div className="toolbar"><span className="result-count">{users.length} workspace accounts</span><button className="button button-primary" onClick={() => { setError(""); setOpen(true); }}>Add user</button></div>
    <section className="panel data-panel">
      <div className="table-wrap">
        <table>
          <thead><tr><th>USER</th><th>ROLE</th><th>STATUS</th><th>MFA</th><th>CREATED</th><th>ACCESS</th></tr></thead>
          <tbody>
            {users.map((user) => {
              const isSelf = user.id === actorId;
              const canEdit = !isSelf && (user.role !== "SUPER_ADMIN" || canManageSuperAdmins);
              return (
                <tr key={user.id}>
                  <td><div className="customer-cell"><span className="customer-avatar">{user.name.slice(0, 1).toUpperCase()}</span><span>{user.name}<small>{user.email}</small></span></div></td>
                  <td><select className="inline-select" aria-label={`Role for ${user.name}`} value={user.role} disabled={!canEdit} onChange={(event) => void update(user, { role: event.target.value as Role })}>{Object.entries(labels).filter(([role]) => role !== "SUPER_ADMIN" || canManageSuperAdmins || role === user.role).map(([role, label]) => <option key={role} value={role}>{label}</option>)}</select></td>
                  <td><span className={`badge ${user.active ? "badge-green" : "badge-neutral"}`}>{user.active ? "Active" : "Inactive"}</span></td>
                  <td>{user.mfaEnabledAt ? <><span className="badge badge-green">Enabled</span> {canEdit && <button className="text-link" onClick={() => void resetMfa(user)}>Reset MFA</button>}</> : <span className="badge badge-neutral">Off</span>}</td>
                  <td>{new Intl.DateTimeFormat("en-IN", { dateStyle: "medium" }).format(new Date(user.createdAt))}</td>
                  <td>{!isSelf && canEdit && <><button className="text-link" onClick={() => { setError(""); setResetUser(user); }}>Set password</button> <button className={user.active ? "danger-action" : "text-link"} onClick={() => void update(user, { active: !user.active })}>{user.active ? "Deactivate" : "Reactivate"}</button></>}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {users.length === 0 && <div className="empty-state"><strong>No workspace users</strong></div>}
      </div>
    </section>
    {open && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setOpen(false); }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="user-modal-title"><div className="modal-heading"><div><div className="eyebrow">WORKSPACE ACCESS</div><h2 id="user-modal-title">Create account</h2></div><button className="icon-button" aria-label="Close" onClick={() => setOpen(false)}>×</button></div><form className="auth-form" onSubmit={create}><label>Full name<input name="name" minLength={2} maxLength={120} required /></label><label>Email<input name="email" type="email" required /></label><label>Initial password<input name="password" type="password" minLength={12} autoComplete="new-password" required /><small className="field-hint">Use at least 12 characters and share it securely with the new user.</small></label><label>Role<select name="role" defaultValue="EMPLOYEE">{Object.entries(labels).filter(([role]) => role !== "SUPER_ADMIN" || canManageSuperAdmins).map(([role, label]) => <option key={role} value={role}>{label}</option>)}</select></label>{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => setOpen(false)}>Cancel</button><button disabled={busy} className="button button-primary">{busy ? "Creating…" : "Create account"}</button></div></form></section></div>}
    {resetUser && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setResetUser(null); }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="reset-password-title"><div className="modal-heading"><div><div className="eyebrow">ACCOUNT SECURITY</div><h2 id="reset-password-title">Set temporary password</h2><p>{resetUser.name} · {resetUser.email}</p></div><button className="icon-button" aria-label="Close" onClick={() => setResetUser(null)}>×</button></div><form className="auth-form" onSubmit={resetPassword}><label>Temporary password<input name="password" type="password" minLength={12} maxLength={200} autoComplete="new-password" required /><small className="field-hint">At least 12 characters. Existing sessions will be signed out; share it securely.</small></label>{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => setResetUser(null)}>Cancel</button><button disabled={busy} className="button button-primary">{busy ? "Updating..." : "Set password"}</button></div></form></section></div>}
  </>;
}
