import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { hasPermission, type Permission } from "@/lib/permissions";
import SignOutButton from "@/app/ui/sign-out-button";

type NavigationItem = { href: string; label: string; icon: string; permission?: Permission; anyPermission?: Permission[]; adminOnly?: boolean };

const navigation: NavigationItem[] = [
  { href: "/dashboard", label: "Overview", icon: "O" },
  { href: "/ai", label: "AI Copilot", icon: "AI" },
  { href: "/customers", label: "Customers", icon: "C", permission: "customers.read" },
  { href: "/products", label: "Products", icon: "P", permission: "products.read" },
  { href: "/inventory", label: "Inventory", icon: "I", permission: "inventory.read" },
  { href: "/sales", label: "Sales", icon: "S", permission: "sales.read" },
  { href: "/purchases", label: "Purchases", icon: "B", permission: "purchases.read" },
  { href: "/finance", label: "Finance", icon: "F", permission: "finance.read" },
  { href: "/analytics", label: "Reports", icon: "R", permission: "reports.read" },
  { href: "/projects", label: "Projects", icon: "P", permission: "sales.read" },
  { href: "/tasks", label: "Tasks", icon: "T", permission: "customers.read" },
  { href: "/automations", label: "Automations", icon: "A", permission: "audit.read" },
  { href: "/hr", label: "People", icon: "H", anyPermission: ["employees.read", "attendance.self", "attendance.read", "leave.create", "leave.read", "leave.approve", "payroll.read"] },
  { href: "/notifications", label: "Notifications", icon: "N", permission: "notifications.read" },
  { href: "/audit", label: "Audit history", icon: "A", permission: "audit.read" },
  { href: "/users", label: "Users and roles", icon: "U", adminOnly: true },
  { href: "/permissions", label: "Role permissions", icon: "R", adminOnly: true },
  { href: "/settings", label: "Settings", icon: "*" },
];

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const unreadCount = hasPermission(user.role, "notifications.read", user.organization.rolePermissions)
    ? await db.notification.count({ where: { organizationId: user.organizationId, userId: user.id, readAt: null } })
    : 0;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <Link className="sidebar-brand" href="/dashboard"><span className="brand-mark">E</span><span>Enterprise<span className="brand-muted">ERP</span></span></Link>
        <div className="workspace-switch"><span className="workspace-avatar">{user.organization.name.slice(0, 1).toUpperCase()}</span><span className="workspace-name">{user.organization.name}<small>Business workspace</small></span><span className="workspace-caret">v</span></div>
        <div className="nav-caption">WORKSPACE</div>
        <nav className="side-nav">{navigation.filter((item) => (!item.permission || hasPermission(user.role, item.permission, user.organization.rolePermissions)) && (!item.anyPermission || item.anyPermission.some((permission) => hasPermission(user.role, permission, user.organization.rolePermissions))) && (!item.adminOnly || ["ADMIN", "SUPER_ADMIN"].includes(user.role))).map((item) => <Link key={item.href} href={item.href} className="nav-link"><span className="nav-icon">{item.icon}</span>{item.label}</Link>)}</nav>
        <div className="sidebar-bottom"><div className="user-card"><div className="user-avatar">{user.name.slice(0, 1).toUpperCase()}</div><div className="user-info">{user.name}<small>{user.role.replaceAll("_", " ")}</small></div><SignOutButton /></div><div className="sidebar-version">ENTERPRISE ERP <span>v0.1</span></div></div>
      </aside>
      <div className="main-area"><header className="topbar"><div className="breadcrumb"><span>Workspace</span><span className="crumb-divider">/</span><strong>Business overview</strong></div><div className="topbar-actions"><span className="status-pill"><span className="status-dot" /> All systems operational</span><Link className="icon-button notification-trigger" href="/notifications" aria-label={`Notifications${unreadCount ? `, ${unreadCount} unread` : ""}`}>N{unreadCount > 0 && <span>{unreadCount > 9 ? "9+" : unreadCount}</span>}</Link><div className="topbar-avatar">{user.name.slice(0, 1).toUpperCase()}</div></div></header><main className="page-content">{children}</main></div>
    </div>
  );
}
