# Free AI Development Mode

This project can run without paid OpenAI API credits.

Set:

AI_PROVIDER="mock"

The `/api/ai/chat` endpoint returns deterministic development responses and
simulated tool-call intents. PostgreSQL, Prisma, Redis/BullMQ, ERP modules,
authentication, RAG data structures and other application code can be tested
without an OpenAI API key.

When you later have API access, set:

AI_PROVIDER="openai"
OPENAI_API_KEY="..."

The mock provider is for development/testing; it is not a replacement for a
real LLM in production.
