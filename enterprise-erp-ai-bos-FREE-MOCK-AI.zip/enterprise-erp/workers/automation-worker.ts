import {Worker} from "bullmq"; import IORedis from "ioredis"; import {executeAutomation} from "@/lib/automation/engine";
const connection=new IORedis(process.env.REDIS_URL||"redis://127.0.0.1:6379",{maxRetriesPerRequest:null});
const worker=new Worker("enterprise-erp-automation",async job=>{await executeAutomation(String(job.data.executionId));},{connection,concurrency:5});
worker.on("completed",job=>console.log(`[automation] completed ${job.id}`)); worker.on("failed",(job,err)=>console.error(`[automation] failed ${job?.id}`,err));
console.log("Enterprise ERP automation worker running");
process.on("SIGTERM",async()=>{await worker.close();await connection.quit();process.exit(0)});
