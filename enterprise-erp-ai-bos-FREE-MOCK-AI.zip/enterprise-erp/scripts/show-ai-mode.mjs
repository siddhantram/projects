const provider = process.env.AI_PROVIDER || "mock";
console.log(`AI provider: ${provider}`);
console.log(provider === "mock"
  ? "Free Mock AI mode: no OpenAI API key or paid credits required."
  : "OpenAI mode: an API key/billing-enabled API account is required.");
