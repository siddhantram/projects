import { Queue } from "bullmq";
import IORedis from "ioredis";
const connection=new IORedis(process.env.REDIS_URL||"redis://127.0.0.1:6379",{maxRetriesPerRequest:null});
export const automationQueue=new Queue("enterprise-erp-automation",{connection});
export async function enqueueAutomation(executionId:string){await automationQueue.add("execute",{executionId},{removeOnComplete:1000,removeOnFail:1000});}
