import { runBusinessAgent } from "./business-agent";
export const runSalesAgent=(user:any,message:string)=>runBusinessAgent(user,`Act as Sales Agent. Focus on leads, customers, sales orders, quotations and revenue. ${message}`);
