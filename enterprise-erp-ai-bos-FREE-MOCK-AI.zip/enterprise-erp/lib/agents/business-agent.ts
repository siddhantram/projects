import { db } from "@/lib/db";
import { getBusinessContext } from "@/lib/ai/context";
import { searchKnowledge } from "@/lib/ai/rag";
import { AI_TOOLS, executeAITool } from "@/lib/ai/tools";
import { chatWithTools } from "@/lib/ai/client";
const SYSTEM=`You are the Enterprise ERP AI Business Agent. You are tenant-isolated. Never invent ERP facts. Use tools for live data and clearly state uncertainty. You may execute write actions only when the user's request explicitly asks for them and the tool authorization permits it. Keep financial amounts precise.`;
export async function runBusinessAgent(user:any,message:string,conversationId?:string){
 const context=await getBusinessContext(user.organizationId); const knowledge=await searchKnowledge(user.organizationId,message,5);
 const base=[{role:"system",content:`${SYSTEM}\nERP SNAPSHOT:${JSON.stringify(context)}\nKNOWLEDGE:${knowledge.map((x:any)=>x.content).join("\n---\n")||"none"}`},{role:"user",content:message}];
 if(!process.env.OPENAI_API_KEY)return {answer:`AI is not configured. ERP snapshot: ${JSON.stringify(context)}`,toolCalls:[]};
 const messages:any[]=base; const toolCalls=[];
 for(let i=0;i<5;i++){
   const result=await chatWithTools(messages,AI_TOOLS as any); const msg=result?.choices?.[0]?.message; if(!msg)break; messages.push(msg);
   if(!msg.tool_calls?.length) return {answer:msg.content||"No answer generated.",toolCalls};
   for(const call of msg.tool_calls){let parsed:any={};try{parsed=JSON.parse(call.function.arguments||"{}")}catch{};try{const output=await executeAITool(call.function.name,parsed,user);toolCalls.push({name:call.function.name,output});messages.push({role:"tool",tool_call_id:call.id,content:JSON.stringify(output)});}catch(e){const error=e instanceof Error?e.message:"Tool failed";toolCalls.push({name:call.function.name,error});messages.push({role:"tool",tool_call_id:call.id,content:JSON.stringify({error})});}}
 }
 return {answer:"The agent reached its tool-call safety limit. Please retry with a narrower request.",toolCalls};
}
