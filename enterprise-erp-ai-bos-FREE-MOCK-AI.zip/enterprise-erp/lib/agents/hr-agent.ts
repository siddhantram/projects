import { runBusinessAgent } from "./business-agent";
export const runHRAgent=(user:any,message:string)=>runBusinessAgent(user,`Act as HR Agent. Focus on employees, attendance, leave and payroll. ${message}`);
