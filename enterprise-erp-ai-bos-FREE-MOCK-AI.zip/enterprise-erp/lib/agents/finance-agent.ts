import { runBusinessAgent } from "./business-agent";
export const runFinanceAgent=(user:any,message:string)=>runBusinessAgent(user,`Act as Finance Agent. Focus on invoices, payments, expenses, receivables, payables and profit. ${message}`);
