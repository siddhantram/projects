export type AIProviderName = "mock" | "openai";

export function getAIProvider(): AIProviderName {
  const provider = (process.env.AI_PROVIDER || "mock").toLowerCase();
  return provider === "openai" ? "openai" : "mock";
}

export function isRealAIEnabled(): boolean {
  return getAIProvider() === "openai" && Boolean(process.env.OPENAI_API_KEY);
}
