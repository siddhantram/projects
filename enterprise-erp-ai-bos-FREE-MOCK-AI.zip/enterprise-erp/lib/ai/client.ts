const CHAT_URL = "https://api.openai.com/v1/chat/completions";
const EMBEDDING_URL = "https://api.openai.com/v1/embeddings";
function key(){ return process.env.OPENAI_API_KEY; }
export async function chatWithTools(messages:unknown[], tools?:unknown[]){
 const apiKey=key(); if(!apiKey)return null;
 const response=await fetch(CHAT_URL,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${apiKey}`},body:JSON.stringify({model:process.env.OPENAI_MODEL||"gpt-5-mini",messages,tools,tool_choice:tools?.length?"auto":undefined,temperature:0.2}),cache:"no-store"});
 if(!response.ok)throw new Error(`OpenAI request failed: ${response.status}`); return await response.json();
}
export async function generateAIResponse(messages:Array<{role:"system"|"user"|"assistant";content:string}>){const j=await chatWithTools(messages);return j?.choices?.[0]?.message?.content?.trim()??null;}
export async function createEmbedding(input:string){const apiKey=key();if(!apiKey)return null;const r=await fetch(EMBEDDING_URL,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${apiKey}`},body:JSON.stringify({model:process.env.OPENAI_EMBEDDING_MODEL||"text-embedding-3-small",input}),cache:"no-store"});if(!r.ok)throw new Error(`Embedding request failed: ${r.status}`);const j=await r.json();return j.data?.[0]?.embedding??null;}
