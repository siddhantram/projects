import { db } from "@/lib/db";
import { hasPermission } from "@/lib/permissions";
import { randomBytes } from "node:crypto";

type UserContext = { id:string; organizationId:string; role:any; organization:{rolePermissions:any} };

export const AI_TOOLS = [
  { type:"function", function:{ name:"get_sales_summary", description:"Get sales orders, value and lead status summary for the organization.", parameters:{type:"object",properties:{},additionalProperties:false} } },
  { type:"function", function:{ name:"get_low_stock", description:"Find active products at or below reorder level.", parameters:{type:"object",properties:{},additionalProperties:false} } },
  { type:"function", function:{ name:"get_employee_attendance", description:"Get attendance summary for employees in the organization.", parameters:{type:"object",properties:{days:{type:"number",minimum:1,maximum:90}},required:["days"],additionalProperties:false} } },
  { type:"function", function:{ name:"create_customer", description:"Create a customer in the current organization.", parameters:{type:"object",properties:{name:{type:"string"},email:{type:"string"},phone:{type:"string"},company:{type:"string"}},required:["name"],additionalProperties:false} } },
  { type:"function", function:{ name:"create_task", description:"Create a task in the current organization.", parameters:{type:"object",properties:{title:{type:"string"},description:{type:"string"},priority:{type:"string",enum:["LOW","MEDIUM","HIGH","URGENT"]},dueDate:{type:"string"}},required:["title"],additionalProperties:false} } },
  { type:"function", function:{ name:"create_invoice", description:"Create a draft invoice with one or more lines for a customer.", parameters:{type:"object",properties:{customerId:{type:"string"},dueDate:{type:"string"},lines:{type:"array",items:{type:"object",properties:{description:{type:"string"},quantity:{type:"number"},unitPrice:{type:"number"}},required:["description","quantity","unitPrice"],additionalProperties:false}}},required:["customerId","lines"],additionalProperties:false} } },
  { type:"function", function:{ name:"create_notification", description:"Create an in-app notification for a user or all users in the organization.", parameters:{type:"object",properties:{title:{type:"string"},message:{type:"string"},userId:{type:"string"}},required:["title","message"],additionalProperties:false} } },
] as const;

function can(user:UserContext, permission:string){ return hasPermission(user.role, permission, user.organization.rolePermissions); }

export async function executeAITool(name:string,args:Record<string,unknown>,user:UserContext){
  if(name === "get_sales_summary"){
    if(!can(user,"sales.read")) throw new Error("Permission denied");
    const [orders,leads] = await Promise.all([
      db.salesOrder.aggregate({where:{organizationId:user.organizationId},_sum:{total:true},_count:{_all:true}}),
      db.salesLead.groupBy({by:["status"],where:{organizationId:user.organizationId},_count:{_all:true}})
    ]);
    return {salesOrders:orders._count._all,salesValue:Number(orders._sum.total??0),leadsByStatus:leads};
  }
  if(name === "get_low_stock"){
    if(!can(user,"inventory.read")) throw new Error("Permission denied");
    const products=await db.product.findMany({where:{organizationId:user.organizationId,active:true},select:{id:true,name:true,sku:true,reorderLevel:true}});
    const result=[]; for(const p of products){const x=await db.stockMovement.aggregate({where:{organizationId:user.organizationId,productId:p.id},_sum:{quantity:true}});const stock=x._sum.quantity??0;if(stock<=p.reorderLevel)result.push({...p,stock});} return result;
  }
  if(name === "get_employee_attendance"){
    if(!can(user,"attendance.read")) throw new Error("Permission denied");
    const days=Math.min(90,Math.max(1,Number(args.days)||30)); const from=new Date(Date.now()-days*86400000);
    const rows=await db.attendance.groupBy({by:["employeeId","status"],where:{organizationId:user.organizationId,workDate:{gte:from}},_count:{_all:true}});
    return rows;
  }
  if(name === "create_customer"){
    if(!can(user,"customers.create")) throw new Error("Permission denied");
    const name=String(args.name||"").trim(); if(name.length<2) throw new Error("Customer name is required");
    const customer=await db.customer.create({data:{organizationId:user.organizationId,name,email:args.email?String(args.email):undefined,phone:args.phone?String(args.phone):undefined,company:args.company?String(args.company):undefined}}); return {id:customer.id,name:customer.name};
  }
  if(name === "create_task"){
    if(!can(user,"tasks.create")) throw new Error("Permission denied");
    const title=String(args.title||"").trim(); if(title.length<2) throw new Error("Task title is required");
    const priority=["LOW","MEDIUM","HIGH","URGENT"].includes(String(args.priority))?String(args.priority):"MEDIUM";
    const due=args.dueDate?new Date(String(args.dueDate)):undefined;
    const task=await db.task.create({data:{organizationId:user.organizationId,title,description:args.description?String(args.description):undefined,priority:priority as any,dueDate:due&&Number.isFinite(due.getTime())?due:undefined}}); return {id:task.id,title:task.title,status:task.status};
  }
  if(name === "create_invoice"){
    if(!can(user,"invoices.create")) throw new Error("Permission denied");
    const customer=await db.customer.findFirst({where:{id:String(args.customerId),organizationId:user.organizationId,active:true}}); if(!customer) throw new Error("Customer not found");
    const raw=Array.isArray(args.lines)?args.lines:[]; if(!raw.length) throw new Error("At least one invoice line is required");
    const lines=raw.map((x:any)=>{const q=Number(x.quantity),p=Number(x.unitPrice);if(!x.description||!Number.isFinite(q)||q<=0||!Number.isFinite(p)||p<0)throw new Error("Invalid invoice line");return {description:String(x.description),quantity:Math.floor(q),unitPrice:p,lineTotal:q*p};});
    const subtotal=lines.reduce((s,x)=>s+x.lineTotal,0); const number=`INV-${new Date().getFullYear()}-${randomBytes(3).toString("hex").toUpperCase()}`;
    const invoice=await db.invoice.create({data:{organizationId:user.organizationId,customerId:customer.id,number,status:"DRAFT",subtotal,taxAmount:0,total:subtotal,dueAt:args.dueDate?new Date(String(args.dueDate)):undefined,lines:{create:lines.map(x=>({...x,unitPrice:x.unitPrice.toFixed(2),lineTotal:x.lineTotal.toFixed(2)}))}}}); return {id:invoice.id,number:invoice.number,total:Number(invoice.total),status:invoice.status};
  }
  if(name === "create_notification"){
    if(!can(user,"notifications.read")) throw new Error("Permission denied");
    const title=String(args.title||"").trim(),message=String(args.message||"").trim(); if(!title||!message)throw new Error("Title and message are required");
    if(args.userId){const target=await db.user.findFirst({where:{id:String(args.userId),organizationId:user.organizationId}});if(!target)throw new Error("User not found");}
    const n=await db.notification.create({data:{organizationId:user.organizationId,userId:args.userId?String(args.userId):undefined,title,message}});return {id:n.id};
  }
  throw new Error(`Unknown AI tool: ${name}`);
}
