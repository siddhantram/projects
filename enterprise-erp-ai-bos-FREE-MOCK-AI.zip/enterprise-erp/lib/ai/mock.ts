export type MockAIResult = {
  answer: string;
  provider: "mock";
  toolCalls: Array<{ name: string; arguments: Record<string, unknown> }>;
};

export async function runMockAI(input: {
  message: string;
  context?: string;
}): Promise<MockAIResult> {
  const message = input.message.trim().toLowerCase();

  if (message.includes("low stock") || message.includes("low-stock")) {
    return {
      provider: "mock",
      answer:
        "Mock AI: Low-stock analysis is ready. Connect the Inventory tool to return live product quantities. No paid API is required for this development mode.",
      toolCalls: [{ name: "get_low_stock", arguments: {} }],
    };
  }

  if (message.includes("sales") || message.includes("revenue")) {
    return {
      provider: "mock",
      answer:
        "Mock AI: Sales analysis is ready. In free development mode, the ERP tool layer can be executed without calling a paid LLM API.",
      toolCalls: [{ name: "get_sales_summary", arguments: {} }],
    };
  }

  if (message.includes("attendance") || message.includes("employee")) {
    return {
      provider: "mock",
      answer:
        "Mock AI: HR analysis is ready. Connect the attendance tool to retrieve live ERP data.",
      toolCalls: [{ name: "get_employee_attendance", arguments: {} }],
    };
  }

  return {
    provider: "mock",
    answer:
      `Mock AI is active. I received: "${input.message}". ` +
      "Your ERP can be developed and tested without paid OpenAI API credits. " +
      "Set AI_PROVIDER=openai later when you have API billing enabled.",
    toolCalls: [],
  };
}
