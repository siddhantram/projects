# Marketlane — multi-vendor marketplace platform

Marketlane is a full-stack marketplace implementation built with Next.js App Router, TypeScript, PostgreSQL, Prisma, cookie sessions, role-based authorization, Redis/BullMQ jobs, and optional Razorpay/Stripe payment providers. It extends the original starter with customer shopping, vendor operations, admin operations, payment verification, shipment records, commission/payout ledgers, refunds/disputes, audit logs, password reset, and deployment scaffolding.

> **Production-readiness note:** This is an expanded marketplace codebase, not a certified or fully audited production service. This environment could not install dependencies because npm registry DNS/network access failed, so Prisma validation, TypeScript typecheck, tests, lint, and Next build have **not** completed. Configure provider credentials, run the checks below, review the generated migration, and obtain a security/payment review before processing real orders. Real vendor bank transfers are not initiated automatically: an admin must send the transfer externally and enter its reference before marking a payout paid.

## Included features

### Phase 1 — customer shopping
- Product search, category/brand filters, price range, sorting and pagination.
- Product pages with size/colour/SKU/stock variants.
- Authenticated cart, quantity updates, removal, wishlist and saved products.
- Address book, checkout form, order history, order detail, shipment tracking, cancellation of eligible unpaid orders, refund requests and disputes.

### Phase 2 — vendor operations
- Vendor product create/edit/archive, variant creation, Cloudinary image uploads, stock overview and low-stock alerts.
- Vendor-filtered order line items, shipment status/tracking events, sales/revenue/commission reporting and payout ledger/history.
- Payout requests; paid-order balances only are eligible. The current payout workflow intentionally supports paying the full available ledger balance per request to avoid incorrectly marking partial ledger rows as paid.

### Phase 3 — admin operations
- Vendor approval/rejection/suspension, verification flag and commission settings.
- User roles, product moderation, categories/brands, global orders, refund/dispute review, payout request approval, platform settings, reports and audit trail.

### Phase 4 — marketplace backend
- Razorpay Orders API + checkout signature verification + signed webhook processing.
- Stripe Checkout Session API + signed webhook processing.
- Transactional order creation, idempotency key support, conditional stock decrement, 30-minute pending-payment stock reservations, auto-expiry worker, vendor-specific child orders (`VendorOrder`), commission/payout ledger grouping, shipping records, and refund API calls for Razorpay/Stripe.
- Note: split settlement to vendors is **not** automatically performed through Razorpay Route/Stripe Connect. Payout requests are ledger/manual-transfer workflows and need a separate connected-account/settlement integration if automated split payments are required.

### Phase 5 — engineering foundations
- Redis-backed rate limiting (process-local fallback only in development), BullMQ jobs, SMTP email worker, password reset, security headers, Docker setup, CI workflow, health endpoint and commission unit tests.
- Monitoring/alerting and automated off-site database backups still need to be connected to your hosting provider. The included CI workflow must pass in a network-enabled environment before treating the code as verified.

## Requirements

- Node.js 22 LTS recommended (Node 20.19+ may work with the installed Next.js version).
- npm and Docker Desktop, or a PostgreSQL 16 database.
- For durable jobs/rate limiting: Redis 7.
- Optional provider accounts: Razorpay, Stripe, Cloudinary, and an SMTP email provider.

## Local setup (Windows)

1. Extract the ZIP and open Command Prompt/PowerShell in the `Multi-Vendor E-commerce` folder.
2. Copy environment settings:

   ```bat
   copy .env.example .env
   ```

3. Start PostgreSQL and Redis:

   ```bash
   docker compose up -d postgres redis
   ```

4. Install dependencies and prepare the database:

   ```bash
   npm install
   npx prisma generate
   npx prisma migrate dev --name marketplace_init
   npm run db:seed
   ```

5. Start the web app:

   ```bash
   npm run dev
   ```

6. In a second terminal, start the BullMQ worker (requires Redis):

   ```bash
   npm run worker
   ```

Open `http://localhost:3000`.

### Demo accounts

Seed password for both accounts: `DemoPass123!`

- Admin: `admin@marketplace.local`
- Vendor: `vendor@marketplace.local`

Change or remove demo credentials and seed data before any shared/public deployment. The seeded vendor is approved and has sample products.

## Payment setup

Payment providers are disabled until you configure server-side environment variables in `.env`:

- Razorpay: `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`.
- Stripe: `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`.
- Set `APP_URL` to the exact public origin.
- Register webhooks to `/api/payments/webhooks/razorpay` and `/api/payments/webhooks/stripe`.
- Keep all secret keys server-side. Never paste them into chat or commit them to source control.
- Use provider test/sandbox credentials and test successful, failed, duplicate, delayed, and refunded payment events before enabling live keys.

## Images and email jobs

- Set `CLOUDINARY_CLOUD_NAME` and `CLOUDINARY_UPLOAD_PRESET`. Configure the unsigned preset to restrict image formats, size, and upload folder. The upload endpoint enforces image MIME types and a 5 MB limit.
- Set `REDIS_URL` for BullMQ and distributed rate limiting.
- Configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, optional SMTP credentials, and `MAIL_FROM` to deliver password reset and order-paid emails. Run `npm run worker` as a separate long-lived process.
- In production, the worker and web service both need the same `DATABASE_URL`, `REDIS_URL`, and email settings.

## Key pages

- `/` — storefront
- `/shop` — search, filters, sort and pagination
- `/products/<slug>` — product detail and variants
- `/cart`, `/wishlist`, `/account` — customer shopping/account
- `/orders/<id>` — order and shipment details
- `/login`, `/register`, `/forgot-password`, `/reset-password` — account flows
- `/vendor` and `/vendor/products` — vendor overview and management
- `/admin` and `/admin/operations` — admin overview and operations

## Important API routes

| Route | Purpose |
|---|---|
| `GET /api/products` | Search/filter/sort/paginate active products |
| `GET /api/products/meta` | Category and brand filters |
| `GET/POST/PATCH/DELETE /api/cart` | Customer cart |
| `GET/POST/DELETE /api/wishlist` | Customer wishlist |
| `GET/POST/PATCH/DELETE /api/addresses` | Customer address book |
| `GET/POST /api/orders` | Order history and transactional checkout |
| `GET/PATCH /api/orders/:id` | Order detail and eligible unpaid-order cancellation |
| `POST /api/payments/create` | Create Razorpay/Stripe payment session |
| `POST /api/payments/verify` | Verify Razorpay checkout signature |
| `POST /api/payments/webhooks/:provider` | Verify signed provider webhooks |
| `GET/POST /api/vendor/products` | Vendor product management |
| `/api/vendor/products/:id/variants` | Variant management |
| `GET/PATCH /api/vendor/orders` | Vendor-specific order lines and shipment status |
| `GET/POST /api/vendor/payouts` | Vendor ledger and payout requests |
| `/api/admin/vendors`, `/api/admin/users`, `/api/admin/products` | Admin account/product moderation |
| `/api/admin/orders`, `/api/admin/refunds`, `/api/admin/disputes` | Marketplace operations |
| `/api/admin/payouts`, `/api/admin/reports`, `/api/admin/audit`, `/api/admin/settings` | Finance and governance |
| `/api/account/password/forgot`, `/api/account/password/reset` | Password reset flow |
| `/api/health` | Database health check |

## Verification commands

Run these locally after installing dependencies and configuring the database:

```bash
npx prisma validate
npx prisma generate
npm run typecheck
npm run lint
npm test
npx prisma db push
npm run db:seed
npx playwright install chromium
npm run test:e2e
npm run build
```

The CI workflow runs these checks on push and pull request. `npm run build` requires Prisma generation and the configured schema. For production, generate and commit your Prisma migration from a controlled development environment, then use `npx prisma migrate deploy` during deployment.

## Deployment and operations

- Build the app container with `docker build -t marketlane .` after a successful local build.
- Run the Next.js web process and BullMQ worker as separate services. Set secrets in your hosting provider's secret manager, not in the image.
- Use HTTPS, a strong random `JWT_SECRET`, production PostgreSQL, private Redis, least-privilege database credentials, provider webhook secrets, and restrictive Cloudinary upload settings.
- The app exposes `/api/health` and `/api/health/ready`, writes structured server-error logs to stdout/stderr, and includes a CI workflow. Connect these logs and readiness checks to your hosting provider's monitoring/alerting service.
- Back up PostgreSQL with `scripts/backup-postgres.sh` (Linux/macOS) or `scripts/backup-postgres.ps1` (Windows PowerShell); both require `DATABASE_URL` and prune local backups older than the configured retention window. Restore helpers `scripts/restore-postgres.sh` and `.ps1` are included and require explicit destructive confirmation. Configure off-site encrypted storage and schedule backups with your hosting scheduler, then run restore drills. The scripts do not automatically upload backups off-site.
- Review tax, shipping, returns, consumer-protection, privacy and local payment compliance requirements for your actual business before going live.
