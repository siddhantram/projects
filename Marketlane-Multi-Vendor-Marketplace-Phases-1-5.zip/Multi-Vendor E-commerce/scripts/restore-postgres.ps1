param([Parameter(Mandatory=$true)][string]$BackupFile, [switch]$ConfirmDestructiveRestore)
if (-not $env:DATABASE_URL) { throw "Set DATABASE_URL before restoring." }
if (-not $ConfirmDestructiveRestore) { throw "This restore can overwrite data. Re-run with -ConfirmDestructiveRestore after verifying the target database." }
if (-not (Test-Path $BackupFile)) { throw "Backup file not found: $BackupFile" }
pg_restore --clean --if-exists --no-owner --dbname=$env:DATABASE_URL $BackupFile
if ($LASTEXITCODE -ne 0) { throw "pg_restore failed with exit code $LASTEXITCODE" }
Write-Output "Restore completed from $BackupFile"
