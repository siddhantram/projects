#!/usr/bin/env sh
set -eu
: "${DATABASE_URL:?Set DATABASE_URL before running the backup}"
BACKUP_DIR="${BACKUP_DIR:-./backups}"
RETENTION_DAYS="${RETENTION_DAYS:-14}"
mkdir -p "$BACKUP_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
FILE="$BACKUP_DIR/marketlane-$STAMP.dump"
pg_dump "$DATABASE_URL" --format=custom --no-owner --file="$FILE"
find "$BACKUP_DIR" -type f -name 'marketlane-*.dump' -mtime "+$RETENTION_DAYS" -delete
printf 'Backup created: %s\n' "$FILE"
