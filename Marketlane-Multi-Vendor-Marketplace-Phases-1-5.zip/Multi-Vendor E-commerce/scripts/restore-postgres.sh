#!/usr/bin/env sh
set -eu
: "${DATABASE_URL:?Set DATABASE_URL before restoring}"
: "${BACKUP_FILE:?Set BACKUP_FILE to the .dump file to restore}"
if [ "${CONFIRM_DESTRUCTIVE_RESTORE:-}" != "YES" ]; then
  echo "Refusing to restore without CONFIRM_DESTRUCTIVE_RESTORE=YES. This can overwrite database data." >&2
  exit 2
fi
pg_restore --clean --if-exists --no-owner --dbname="$DATABASE_URL" "$BACKUP_FILE"
echo "Restore completed from $BACKUP_FILE"
