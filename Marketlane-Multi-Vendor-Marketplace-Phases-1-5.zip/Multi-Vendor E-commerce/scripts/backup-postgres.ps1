param([string]$BackupDir = ".\backups", [int]$RetentionDays = 14)
if (-not $env:DATABASE_URL) { throw "Set DATABASE_URL before running the backup." }
New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
$stamp = (Get-Date).ToUniversalTime().ToString("yyyyMMddTHHmmssZ")
$file = Join-Path $BackupDir "marketlane-$stamp.dump"
pg_dump $env:DATABASE_URL --format=custom --no-owner --file=$file
if ($LASTEXITCODE -ne 0) { throw "pg_dump failed with exit code $LASTEXITCODE" }
Get-ChildItem $BackupDir -Filter "marketlane-*.dump" -File | Where-Object { $_.LastWriteTimeUtc -lt (Get-Date).ToUniversalTime().AddDays(-$RetentionDays) } | Remove-Item -Force
Write-Output "Backup created: $file"
