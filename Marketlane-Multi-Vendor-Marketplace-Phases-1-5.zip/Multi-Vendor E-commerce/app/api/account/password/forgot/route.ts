import { NextResponse } from "next/server";
import { randomBytes, createHash } from "node:crypto";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { rateLimit } from "@/lib/security/rate-limit";
import { enqueueJob } from "@/lib/queue";
import { serverError } from "@/lib/http";

export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0] || "unknown";
    const rl = await rateLimit(`password-reset:${ip}`, 5, 3600);
    if (!rl.allowed) return NextResponse.json({ error: "Too many requests. Try again later." }, { status: 429 });
    const parsed = z.object({ email: z.email() }).safeParse(await req.json().catch(() => null));
    if (!parsed.success) return NextResponse.json({ message: "If the account exists, reset instructions will be sent." });
    const user = await prisma.user.findUnique({ where: { email: parsed.data.email.toLowerCase() } });
    if (user && !user.isSuspended) {
      const token = randomBytes(32).toString("hex");
      const tokenHash = createHash("sha256").update(token).digest("hex");
      await prisma.passwordResetToken.updateMany({ where: { userId: user.id, usedAt: null }, data: { usedAt: new Date() } });
      await prisma.passwordResetToken.create({ data: { userId: user.id, tokenHash, expiresAt: new Date(Date.now() + 30 * 60 * 1000) } });
      const resetUrl = `${process.env.APP_URL}/reset-password?token=${token}`;
      await enqueueJob("password-reset-email", { email: user.email, name: user.name, resetUrl });
      if (process.env.NODE_ENV !== "production") return NextResponse.json({ message: "Development reset token created.", developmentResetUrl: resetUrl });
    }
    return NextResponse.json({ message: "If the account exists, reset instructions will be sent." });
  } catch (e) { return serverError(e); }
}
