import { NextResponse } from "next/server";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { requireRole, AuthError } from "@/lib/auth";
import { errorResponse, serverError } from "@/lib/http";
import { calculateCommission } from "@/lib/marketplace/commission";
import { rateLimit } from "@/lib/security/rate-limit";

const addressSchema = z.object({ recipient: z.string().min(2), line1: z.string().min(3), line2: z.string().optional(), city: z.string().min(2), state: z.string().min(2), postalCode: z.string().min(3), country: z.string().default("India"), phone: z.string().min(8) });
export async function GET() {
  try {
    const user = await requireRole("CUSTOMER", "ADMIN", "SUPPORT", "VENDOR");
    const orders = await prisma.order.findMany({
      where: user.role === "CUSTOMER" ? { userId: user.id } : user.role === "VENDOR" ? { items: { some: { vendorId: user.vendorId || "__missing_vendor__" } } } : {},
      include: { items: { include: { product: true, variant: true, vendor: { select: { storeName: true } } } }, payment: true, shipments: { orderBy: { createdAt: "desc" } } },
      orderBy: { createdAt: "desc" }, take: 100
    });
    return NextResponse.json({ orders });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
export async function POST(request: Request) {
  let idempotencyKey: string | undefined;
  let checkoutUserId: string | undefined;
  try {
    const user = await requireRole("CUSTOMER");
    const checkoutLimit = await rateLimit(`checkout:${user.id}`, 10, 60);
    if (!checkoutLimit.allowed) return errorResponse("Too many checkout attempts. Please wait a minute.", 429);
    checkoutUserId = user.id;
    idempotencyKey = request.headers.get("Idempotency-Key")?.trim();
    if (idempotencyKey && (idempotencyKey.length < 8 || idempotencyKey.length > 200)) return errorResponse("Idempotency-Key must be 8–200 characters.");
    if (idempotencyKey) {
      const prior = await prisma.idempotencyKey.findUnique({ where: { key: idempotencyKey } });
      if (prior) {
        if (prior.userId !== user.id) return errorResponse("Idempotency key already belongs to another user.", 409);
        if (prior.orderId) { const existing = await prisma.order.findUnique({ where: { id: prior.orderId }, include: { items: true, payment: true } }); if (existing) return NextResponse.json({ order: existing, idempotentReplay: true }); }
      }
    }
    const parsed = z.object({ shippingAddress: addressSchema }).safeParse(await request.json());
    if (!parsed.success) return errorResponse(parsed.error.issues[0]?.message ?? "Invalid shipping address.");
    const cart = await prisma.cart.findUnique({ where: { userId: user.id }, include: { items: { include: { variant: true, product: { include: { vendor: true } } } } } });
    if (!cart?.items.length) return errorResponse("Your cart is empty.");
    const order = await prisma.$transaction(async tx => {
      let subtotal = new Prisma.Decimal(0);
      const lines = cart.items.map(item => {
        if (item.product.status !== "ACTIVE" || item.product.vendor.status !== "APPROVED" || item.product.stock < item.quantity || (item.variant && item.variant.stock < item.quantity)) throw new Error(`Insufficient stock for ${item.product.name}.`);
        const unitPrice = item.variant?.price ?? item.product.price;
        const lineTotal = unitPrice.mul(item.quantity);
        subtotal = subtotal.add(lineTotal);
        const commission = calculateCommission(lineTotal, item.product.vendor.commissionBps);
        return { productId: item.productId, variantId: item.variantId, vendorId: item.product.vendorId, productName: item.product.name + (item.variant ? ` — ${item.variant.name}` : ""), quantity: item.quantity, unitPrice, commissionAmount: commission, vendorNetAmount: lineTotal.sub(commission), gross: lineTotal };
      });
      const created = await tx.order.create({
        data: {
          orderNumber: `MV-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
          userId: user.id, subtotal, total: subtotal, shippingAddress: parsed.data.shippingAddress,
          items: { create: lines.map(({ gross, ...line }) => line) },
          payment: { create: { amount: subtotal, status: "PENDING", provider: "MANUAL" } }
        }, include: { items: true }
      });
      for (const item of cart.items) {
        const changed = await tx.product.updateMany({ where: { id: item.productId, status: "ACTIVE", vendor: { status: "APPROVED" }, stock: { gte: item.quantity } }, data: { stock: { decrement: item.quantity } } });
        if (changed.count !== 1) throw new Error(`Insufficient stock for ${item.product.name}.`);
        if (item.variantId) {
          const variantChanged = await tx.productVariant.updateMany({ where: { id: item.variantId, productId: item.productId, stock: { gte: item.quantity } }, data: { stock: { decrement: item.quantity } } });
          if (variantChanged.count !== 1) throw new Error(`Insufficient stock for ${item.product.name}.`);
        }
        await tx.stockReservation.create({ data: { orderId: created.id, productId: item.productId, variantId: item.variantId, quantity: item.quantity, expiresAt: new Date(Date.now() + 30 * 60 * 1000) } });
      }
      if (idempotencyKey) await tx.idempotencyKey.create({ data: { key: idempotencyKey, userId: user.id, orderId: created.id, response: { orderId: created.id } } });
      const grouped = new Map<string, { gross: Prisma.Decimal; commission: Prisma.Decimal; net: Prisma.Decimal }>();
      for (const line of lines) {
        const old = grouped.get(line.vendorId) ?? { gross: new Prisma.Decimal(0), commission: new Prisma.Decimal(0), net: new Prisma.Decimal(0) };
        old.gross = old.gross.add(line.gross); old.commission = old.commission.add(line.commissionAmount); old.net = old.net.add(line.vendorNetAmount); grouped.set(line.vendorId, old);
      }
      for (const [vendorId, amounts] of grouped) {
        const vendorOrder = await tx.vendorOrder.create({data:{orderId:created.id,vendorId,vendorOrderNumber:`${created.orderNumber}-${vendorId.slice(-6).toUpperCase()}`,status:"PENDING",subtotal:amounts.gross,commission:amounts.commission,vendorNet:amounts.net}});
        await tx.orderItem.updateMany({where:{orderId:created.id,vendorId},data:{vendorOrderId:vendorOrder.id}});
        await tx.vendorPayout.create({ data: { vendorId, orderId: created.id, vendorOrderId:vendorOrder.id, grossAmount: amounts.gross, commission: amounts.commission, netAmount: amounts.net } });
      }
      await tx.cartItem.deleteMany({ where: { cartId: cart.id } });
      return created;
    });
    return NextResponse.json({ order }, { status: 201 });
  } catch (e) {
    if (e instanceof AuthError) return errorResponse(e.message, e.status);
    if (e instanceof Error && (e as Error & { code?: string }).code === "P2002" && idempotencyKey && checkoutUserId) {
      const prior = await prisma.idempotencyKey.findUnique({ where: { key: idempotencyKey } });
      if (prior?.userId === checkoutUserId && prior.orderId) {
        const existing = await prisma.order.findUnique({ where: { id: prior.orderId }, include: { items: true, payment: true } });
        if (existing) return NextResponse.json({ order: existing, idempotentReplay: true });
      }
      return errorResponse("A request with this idempotency key already exists.", 409);
    }
    if (e instanceof Error && e.message.startsWith("Insufficient stock")) return errorResponse(e.message, 409);
    return serverError(e);
  }
}
