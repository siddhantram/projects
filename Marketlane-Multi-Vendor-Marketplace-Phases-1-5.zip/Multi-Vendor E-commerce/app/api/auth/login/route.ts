import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { createSession, setSessionCookie } from "@/lib/auth";
import { errorResponse, serverError } from "@/lib/http";
import { rateLimit } from "@/lib/security/rate-limit";

const schema = z.object({ email: z.email(), password: z.string().min(1) });
export async function POST(request: Request) {
  try {
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0] || "unknown";
    const rl = await rateLimit(`login:${ip}`, 10, 60);
    if (!rl.allowed) return errorResponse("Too many login attempts. Please wait a minute.", 429);
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return errorResponse("Enter a valid email and password.");
    const email = parsed.data.email.toLowerCase();
    const user = await prisma.user.findUnique({ where: { email }, include: { vendor: true } });
    if (!user || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) return errorResponse("Invalid email or password.", 401);
    if (user.isSuspended) return errorResponse("This account has been suspended. Contact marketplace support.", 403);
    const token = await createSession({ id: user.id, email: user.email, name: user.name, role: user.role, vendorId: user.vendor?.id, sessionVersion: user.sessionVersion });
    await setSessionCookie(token);
    return NextResponse.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role, vendorStatus: user.vendor?.status } });
  } catch (e) { return serverError(e); }
}
