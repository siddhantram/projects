import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { createSession, setSessionCookie } from "@/lib/auth";
import { errorResponse, serverError } from "@/lib/http";
import { rateLimit } from "@/lib/security/rate-limit";

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.email().transform(v => v.toLowerCase()),
  password: z.string().min(8).max(100),
  role: z.enum(["CUSTOMER", "VENDOR"]).default("CUSTOMER"),
  storeName: z.string().trim().min(2).max(80).optional()
});

export async function POST(request: Request) {
  try {
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0] || "unknown";
    const rl = await rateLimit(`register:${ip}`, 5, 3600);
    if (!rl.allowed) return errorResponse("Too many registration attempts. Try again later.", 429);
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return errorResponse(parsed.error.issues[0]?.message ?? "Invalid input.");
    const data = parsed.data;
    if (data.role === "VENDOR" && !data.storeName) return errorResponse("Store name is required for vendor registration.");
    const existing = await prisma.user.findUnique({ where: { email: data.email } });
    if (existing) return errorResponse("An account with this email already exists.", 409);
    const user = await prisma.user.create({
      data: {
        name: data.name, email: data.email, passwordHash: await bcrypt.hash(data.password, 12), role: data.role,
        ...(data.role === "VENDOR" ? { vendor: { create: { storeName: data.storeName!, slug: `${data.storeName!.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}-${Date.now().toString(36)}` } } } : {})
      },
      include: { vendor: true }
    });
    const token = await createSession({ id: user.id, email: user.email, name: user.name, role: user.role, vendorId: user.vendor?.id, sessionVersion: user.sessionVersion });
    await setSessionCookie(token);
    return NextResponse.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role, vendorStatus: user.vendor?.status } }, { status: 201 });
  } catch (e) { return serverError(e); }
}
