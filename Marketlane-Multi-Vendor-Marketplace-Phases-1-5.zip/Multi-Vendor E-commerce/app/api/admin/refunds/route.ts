import { NextResponse } from "next/server";
import { Buffer } from "node:buffer";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { AuthError, requireRole } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { errorResponse, serverError } from "@/lib/http";

export async function GET() {
  try {
    await requireRole("ADMIN", "SUPPORT");
    const refunds = await prisma.refund.findMany({ include: { order: { select: { orderNumber: true, user: { select: { name: true, email: true } }, payment: true } }, }, orderBy: { createdAt: "desc" }, take: 500 });
    return NextResponse.json({ refunds });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}

export async function PATCH(req: Request) {
  try {
    const actor = await requireRole("ADMIN");
    const parsed = z.object({ id: z.string(), status: z.enum(["APPROVED", "REJECTED", "PROCESSING", "COMPLETED", "FAILED"]) }).safeParse(await req.json());
    if (!parsed.success) return errorResponse("Invalid refund decision");
    const current = await prisma.refund.findUnique({ where: { id: parsed.data.id }, include: { order: { include: { payment: true } } } });
    if (!current) return errorResponse("Refund not found", 404);
    if (current.status === "COMPLETED") return errorResponse("Refund has already been completed", 409);
    if (current.status === "REJECTED" && parsed.data.status === "COMPLETED") return errorResponse("A rejected refund cannot be completed", 409);

    let providerRef = current.providerRef ?? undefined;
    let providerCompleted = false;
    let providerFailed = false;
    if (parsed.data.status === "COMPLETED") {
      const payment = current.order.payment;
      if (!payment || payment.status !== "PAID") return errorResponse("Only a paid payment can be refunded", 409);
      if (payment.provider === "RAZORPAY") {
        const key = process.env.RAZORPAY_KEY_ID, secret = process.env.RAZORPAY_KEY_SECRET;
        if (!key || !secret || !payment.providerRef) return errorResponse("Razorpay refund is not configured or payment reference is missing", 503);
        const auth = `Basic ${Buffer.from(`${key}:${secret}`).toString("base64")}`;
        const response = current.providerRef
          ? await fetch(`https://api.razorpay.com/v1/refunds/${current.providerRef}`, { headers: { Authorization: auth } })
          : await fetch(`https://api.razorpay.com/v1/payments/${payment.providerRef}/refund`, { method: "POST", headers: { Authorization: auth, "Content-Type": "application/json", "X-Idempotency-Key": `marketlane-refund-${current.id}` }, body: JSON.stringify({ amount: Math.round(Number(current.amount) * 100), notes: { orderId: current.orderId, refundId: current.id } }) });
        const result = await response.json();
        if (!response.ok) return errorResponse("Razorpay refund could not be confirmed; review the provider dashboard before retrying", 502);
        providerRef = result.id;
        providerCompleted = result.status === "processed";
        providerFailed = result.status === "failed";
      } else if (payment.provider === "STRIPE") {
        const secret = process.env.STRIPE_SECRET_KEY;
        if (!secret || !payment.providerRef) return errorResponse("Stripe refund is not configured or payment reference is missing", 503);
        const response = current.providerRef
          ? await fetch(`https://api.stripe.com/v1/refunds/${current.providerRef}`, { headers: { Authorization: `Bearer ${secret}` } })
          : await fetch("https://api.stripe.com/v1/refunds", { method: "POST", headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/x-www-form-urlencoded", "Idempotency-Key": `marketlane-refund-${current.id}` }, body: new URLSearchParams({ payment_intent: payment.providerRef, amount: String(Math.round(Number(current.amount) * 100)) }) });
        const result = await response.json();
        if (!response.ok) return errorResponse("Stripe refund could not be confirmed; review the provider dashboard before retrying", 502);
        providerRef = result.id;
        providerCompleted = result.status === "succeeded";
        providerFailed = result.status === "failed";
      } else return errorResponse("Cannot automatically refund this payment provider", 409);
    }

    const nextStatus = parsed.data.status === "COMPLETED" ? (providerCompleted ? "COMPLETED" : providerFailed ? "FAILED" : "PROCESSING") : parsed.data.status;
    const refund = await prisma.refund.update({ where: { id: current.id }, data: { status: nextStatus, providerRef, processedAt: ["COMPLETED", "FAILED", "REJECTED"].includes(nextStatus) ? new Date() : undefined } });
    if (refund.status === "COMPLETED") {
      const total = await prisma.refund.aggregate({ where: { orderId: refund.orderId, status: "COMPLETED" }, _sum: { amount: true } });
      if (Number(total._sum.amount || 0) >= Number(current.order.total)) {
        await prisma.payment.update({ where: { orderId: refund.orderId }, data: { status: "REFUNDED" } });
        await prisma.order.update({ where: { id: refund.orderId }, data: { status: "REFUNDED" } });
      }
    }
    await audit(actor.id, "REFUND_STATUS_UPDATED", "Refund", refund.id, { status: refund.status });
    return NextResponse.json({ refund, providerConfirmed: providerCompleted });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
