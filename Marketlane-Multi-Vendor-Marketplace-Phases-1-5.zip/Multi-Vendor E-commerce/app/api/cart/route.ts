import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole, AuthError } from "@/lib/auth";
import { errorResponse, serverError } from "@/lib/http";

export async function GET() {
  try {
    const user = await requireRole("CUSTOMER");
    const cart = await prisma.cart.findUnique({ where: { userId: user.id }, include: { items: { include: { product: { include: { vendor: { select: { storeName: true } } } }, variant: true } } } });
    return NextResponse.json({ cart: cart ?? { items: [] } });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
const schema = z.object({ productId: z.string().min(1), variantId: z.string().optional(), quantity: z.number().int().min(1).max(50).default(1) });
export async function POST(request: Request) {
  try {
    const user = await requireRole("CUSTOMER");
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return errorResponse("Provide a valid product and quantity.");
    const { productId, quantity } = parsed.data;
    const product = await prisma.product.findFirst({ where: { id: productId, status: "ACTIVE", vendor: { status: "APPROVED" } } });
    if (!product) return errorResponse("Product is unavailable.", 404);
    const variant = parsed.data.variantId ? await prisma.productVariant.findFirst({ where: { id: parsed.data.variantId, productId } }) : null;
    if (parsed.data.variantId && !variant) return errorResponse("Selected variant was not found.", 404);
    if (Math.min(product.stock, variant?.stock ?? product.stock) < quantity) return errorResponse("Not enough stock available.", 409);
    const cart = await prisma.cart.upsert({ where: { userId: user.id }, create: { userId: user.id }, update: {} });
    const existing = await prisma.cartItem.findFirst({ where: { cartId: cart.id, productId, variantId: variant?.id ?? null } });
    const nextQuantity = (existing?.quantity ?? 0) + quantity;
    if (nextQuantity > Math.min(product.stock, variant?.stock ?? product.stock)) return errorResponse("Requested quantity exceeds available stock.", 409);
    const item = existing ? await prisma.cartItem.update({ where: { id: existing.id }, data: { quantity: nextQuantity } }) : await prisma.cartItem.create({ data: { cartId: cart.id, productId, variantId: variant?.id, quantity } });
    return NextResponse.json({ item }, { status: 201 });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
export async function DELETE(request: Request) {
  try {
    const user = await requireRole("CUSTOMER");
    const url = new URL(request.url);
    const itemId = url.searchParams.get("itemId");
    if (!itemId) return errorResponse("itemId is required.");
    const item = await prisma.cartItem.findFirst({ where: { id: itemId, cart: { userId: user.id } } });
    if (!item) return errorResponse("Cart item not found.", 404);
    await prisma.cartItem.delete({ where: { id: item.id } });
    return NextResponse.json({ message: "Item removed." });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}

export async function PATCH(request: Request) {
  try {
    const user = await requireRole("CUSTOMER");
    const parsed = z.object({ itemId: z.string().min(1), quantity: z.number().int().min(1).max(50) }).safeParse(await request.json());
    if (!parsed.success) return errorResponse("Provide a valid cart item and quantity.");
    const item = await prisma.cartItem.findFirst({ where: { id: parsed.data.itemId, cart: { userId: user.id } }, include: { product: true, variant: true } });
    if (!item) return errorResponse("Cart item not found.", 404);
    if (Math.min(item.product.stock, item.variant?.stock ?? item.product.stock) < parsed.data.quantity) return errorResponse("Requested quantity exceeds available stock.", 409);
    const updated = await prisma.cartItem.update({ where: { id: item.id }, data: { quantity: parsed.data.quantity } });
    return NextResponse.json({ item: updated });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
