import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole, AuthError } from "@/lib/auth";
import { errorResponse, serverError } from "@/lib/http";
import { audit } from "@/lib/audit";

type Context = { params: Promise<{ id: string }> };
export async function GET(_request: Request, { params }: Context) {
  try {
    const { id } = await params;
    const product = await prisma.product.findFirst({ where: { OR: [{ id }, { slug: id }], status: "ACTIVE", vendor: { status: "APPROVED" } }, include: { vendor: { select: { id: true, storeName: true, slug: true } }, category: true, brand: true, variants: true, reviews: { include: { user: { select: { name: true } } }, orderBy: { createdAt: "desc" }, take: 20 } } });
    if (!product) return errorResponse("Product not found.", 404);
    return NextResponse.json({ product });
  } catch (e) { return serverError(e); }
}
const schema = z.object({ name: z.string().trim().min(2).max(160).optional(), description: z.string().trim().min(10).max(5000).optional(), price: z.number().positive().optional(), compareAt: z.number().positive().nullable().optional(), stock: z.number().int().min(0).optional(), sku: z.string().trim().min(2).max(80).optional(), categoryId: z.string().nullable().optional(), brandId: z.string().nullable().optional(), status: z.enum(["DRAFT", "ACTIVE", "ARCHIVED"]).optional(), imageUrl: z.url().nullable().optional() });
export async function PATCH(request: Request, { params }: Context) {
  try {
    const user = await requireRole("VENDOR", "ADMIN");
    const { id } = await params;
    const product = await prisma.product.findUnique({ where: { id } });
    if (!product) return errorResponse("Product not found.", 404);
    if (user.role === "VENDOR" && product.vendorId !== user.vendorId) return errorResponse("You cannot modify another vendor's product.", 403);
    if (user.role === "VENDOR") { const vendor = await prisma.vendor.findUnique({where:{id:user.vendorId}}); if (vendor?.status !== "APPROVED") return errorResponse("Only approved vendors can edit products.", 403); }
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success || Object.keys(parsed.data || {}).length === 0) return errorResponse("Provide valid fields to update.");
    if (parsed.data.stock !== undefined) { const variants = await prisma.productVariant.aggregate({where:{productId:id},_sum:{stock:true}}); if (parsed.data.stock < Number(variants._sum.stock||0)) return errorResponse("Product stock cannot be lower than the combined variant stock.",409); }
    const updated = await prisma.product.update({ where: { id }, data: { ...parsed.data, ...(parsed.data.name ? { slug: `${parsed.data.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}-${crypto.randomUUID().slice(0,8)}` } : {}) } });
    await audit(user.id,"PRODUCT_UPDATED","Product",updated.id,{fields:Object.keys(parsed.data)});
    return NextResponse.json({ product: updated });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
export async function DELETE(_request: Request, { params }: Context) {
  try {
    const user = await requireRole("VENDOR", "ADMIN");
    const { id } = await params;
    const product = await prisma.product.findUnique({ where: { id } });
    if (!product) return errorResponse("Product not found.", 404);
    if (user.role === "VENDOR" && product.vendorId !== user.vendorId) return errorResponse("You cannot delete another vendor's product.", 403);
    if (user.role === "VENDOR") { const vendor = await prisma.vendor.findUnique({where:{id:user.vendorId}}); if (vendor?.status !== "APPROVED") return errorResponse("Only approved vendors can archive products.", 403); }
    await prisma.product.update({ where: { id }, data: { status: "ARCHIVED" } });
    await audit(user.id,"PRODUCT_ARCHIVED","Product",id);
    return NextResponse.json({ message: "Product archived." });
  } catch (e) { if (e instanceof AuthError) return errorResponse(e.message, e.status); return serverError(e); }
}
