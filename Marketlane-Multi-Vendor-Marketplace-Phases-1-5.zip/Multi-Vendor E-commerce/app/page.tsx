import Link from "next/link";
import { prisma } from "@/lib/db";

function money(value: { toString(): string }) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(Number(value.toString()));
}

export default async function Home() {
  let products: Array<{ id: string; slug: string; imageUrl: string | null; name: string; price: { toString(): string }; vendor: { storeName: string } }> = [];
  let dbReady = true;
  try {
    products = await prisma.product.findMany({ where: { status: "ACTIVE", vendor: { status: "APPROVED" } }, include: { vendor: { select: { storeName: true } } }, orderBy: { createdAt: "desc" }, take: 8 });
  } catch {
    dbReady = false;
  }
  return (
    <>
      <header className="site-header">
        <Link href="/" className="brand">market<span>lane.</span></Link>
        <nav className="nav"><Link href="/shop">Shop all</Link><a href="#categories">Categories</a><a href="#vendors">Sell on Marketlane</a></nav>
        <div className="header-actions"><Link className="pill" href="/wishlist">Wishlist ♡</Link><Link className="pill" href="/cart">Cart</Link><Link className="pill" href="/account">Account</Link><Link className="pill dark" href="/register">Join free ↗</Link></div>
      </header>
      <main>
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow">Good finds. Independent minds.</div>
            <h1>Find your next<br/>favourite thing.</h1>
            <p>A thoughtful marketplace for everyday essentials, clever design, and independent sellers worth knowing.</p>
            <Link className="hero-cta" href="/shop">Explore the marketplace&nbsp; ↗</Link>
          </div>
          <div className="hero-art" aria-label="Abstract warm-toned product still life" role="img"><div className="orbit"/><div className="orb"/><div className="hero-tag">Small brands. Big ideas. ✳</div></div>
        </section>
        <div className="trust"><span>✳ <strong>Independent sellers</strong></span><span>✓ Secure account sessions</span><span>↗ One easy checkout</span><span>♡ Discover something new</span></div>
        {!dbReady && <section className="section"><div className="notice"><strong>Database is not connected yet.</strong> Start PostgreSQL and run the setup commands in README.md to load demo products.</div></section>}
        <section className="section" id="categories">
          <div className="section-head"><div><h2>Browse by mood</h2><p>A little inspiration for whatever you need next.</p></div><a className="text-link" href="#shop">Shop everything ↗</a></div>
          <div className="categories">
            <a className="category" href="#shop"><div className="emoji">⌂</div><h3>Home & living</h3><p>Make your space yours</p></a>
            <a className="category" href="#shop"><div className="emoji">✳</div><h3>Everyday carry</h3><p>Good things to take along</p></a>
            <a className="category" href="#shop"><div className="emoji">◉</div><h3>Tech & gadgets</h3><p>Useful by design</p></a>
            <a className="category" href="#shop"><div className="emoji">♡</div><h3>Gifts & finds</h3><p>For them, or for you</p></a>
          </div>
        </section>
        <section className="section" id="shop">
          <div className="section-head"><div><h2>Picked for you</h2><p>Fresh finds from independent sellers.</p></div><Link className="text-link" href="/shop">Browse all products ↗</Link></div>
          {products.length ? <div className="products">{products.map(product => <article className="product-card" key={product.id}>
            <Link href={`/products/${product.slug}`}><div className="product-image">{product.imageUrl ? <img src={product.imageUrl} alt={product.name}/> : <span style={{fontSize:50}}>✳</span>}</div></Link>
            <div className="product-info"><div className="vendor-label">{("vendor" in product && product.vendor) ? product.vendor.storeName : "Independent seller"}</div><Link href={`/products/${product.slug}`}><h3>{product.name}</h3></Link><div className="price-row"><span>{money(product.price)}</span><Link className="add-button" href={`/products/${product.slug}`} aria-label={`View ${product.name}`}>↗</Link></div></div>
          </article>)}</div> : <div className="notice">Demo products will appear here after you run the database seed command.</div>}
        </section>
        <section className="section" id="vendors"><div className="banner"><div><h2>Your store belongs here.</h2><p>Meet customers, manage your products, and grow with a marketplace built for independent sellers.</p></div><Link href="/register?role=VENDOR" className="pill dark">Become a seller ↗</Link></div></section>
      </main>
      <footer className="footer"><div><div className="brand" style={{color:"white"}}>market<span>lane.</span></div><small>Thoughtful shopping starts here.</small></div><small>© {new Date().getFullYear()} Marketlane Marketplace · Demo project</small></footer>
    </>
  );
}
