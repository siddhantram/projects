import test from "node:test";
import assert from "node:assert/strict";
import { PrismaClient } from "@prisma/client";

test("PostgreSQL connection is available for integration tests", { skip: !process.env.DATABASE_URL }, async () => {
  const prisma = new PrismaClient();
  try {
    const rows = await prisma.$queryRaw<Array<{ value: number }>>`SELECT 1 AS value`;
    assert.equal(Number(rows[0]?.value), 1);
  } finally {
    await prisma.$disconnect();
  }
});
