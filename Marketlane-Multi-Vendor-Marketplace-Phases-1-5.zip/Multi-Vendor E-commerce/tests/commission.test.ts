import test from "node:test";
import assert from "node:assert/strict";
import { Prisma } from "@prisma/client";
import { calculateCommission } from "../lib/marketplace/commission";

test("commission uses basis points and rounds to cents", () => {
  assert.equal(calculateCommission(new Prisma.Decimal("100.00"), 1000).toFixed(2), "10.00");
  assert.equal(calculateCommission(new Prisma.Decimal("19.99"), 750).toFixed(2), "1.50");
  assert.equal(calculateCommission(new Prisma.Decimal("50.00"), 0).toFixed(2), "0.00");
});

test("invalid commission basis points are rejected", () => {
  assert.throws(() => calculateCommission(new Prisma.Decimal("10"), -1));
  assert.throws(() => calculateCommission(new Prisma.Decimal("10"), 10_001));
  assert.throws(() => calculateCommission(new Prisma.Decimal("10"), 1.5));
});
