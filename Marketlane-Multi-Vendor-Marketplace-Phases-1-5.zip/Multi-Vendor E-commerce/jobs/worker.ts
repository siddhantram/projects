import { Queue, Worker } from "bullmq";
import Redis from "ioredis";
import nodemailer from "nodemailer";
import { prisma } from "@/lib/db";
if (!process.env.REDIS_URL) throw new Error("REDIS_URL is required to run the worker");
const connection = new Redis(process.env.REDIS_URL, { maxRetriesPerRequest: null });
const transporter = process.env.SMTP_HOST ? nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:process.env.SMTP_SECURE==="true",auth:process.env.SMTP_USER?{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD}:undefined}) : null;
const queue = new Queue("marketlane-jobs", { connection });
void queue.upsertJobScheduler("expire-stock-reservations", { every: 60_000 }, { name: "expire-stock-reservations" }).catch(error => console.error("Could not schedule reservation expiry", error));
const worker = new Worker("marketlane-jobs", async job => {
  if (job.name === "expire-stock-reservations") {
    const expiredOrders = await prisma.order.findMany({
      where: { status: "PENDING", payment: { is: { status: { in: ["PENDING", "FAILED"] } } }, reservations: { some: { releasedAt: null, expiresAt: { lt: new Date() } } } },
      include: { items: true }, take: 250, orderBy: { createdAt: "asc" }
    });
    let cancelled = 0;
    for (const order of expiredOrders) {
      const wasCancelled = await prisma.$transaction(async tx => {
        const claimed = await tx.order.updateMany({ where: { id: order.id, status: "PENDING", payment: { is: { status: { in: ["PENDING", "FAILED"] } } } }, data: { status: "CANCELLED" } });
        if (claimed.count !== 1) return false;
        for (const item of order.items) {
          await tx.product.update({ where: { id: item.productId }, data: { stock: { increment: item.quantity } } });
          if (item.variantId) await tx.productVariant.update({ where: { id: item.variantId }, data: { stock: { increment: item.quantity } } });
        }
        await tx.orderItem.updateMany({ where: { orderId: order.id }, data: { status: "CANCELLED" } });
        await tx.vendorOrder.updateMany({ where: { orderId: order.id }, data: { status: "CANCELLED" } });
        await tx.stockReservation.updateMany({ where: { orderId: order.id, releasedAt: null }, data: { releasedAt: new Date() } });
        return true;
      });
      if (wasCancelled) cancelled += 1;
    }
    return { cancelledOrders: cancelled };
  }
  if (job.name === "password-reset-email" || job.name === "order-paid-email" || job.name === "shipment-updated-email") {
    if (!transporter || !process.env.MAIL_FROM) { if (process.env.NODE_ENV === "production") throw new Error("SMTP_HOST and MAIL_FROM are required for email jobs"); console.info("Email job skipped in development", job.name); return; }
    if (job.name === "password-reset-email") {
      const {email,name,resetUrl}=job.data as {email:string;name:string;resetUrl:string};
      await transporter.sendMail({from:process.env.MAIL_FROM,to:email,subject:"Reset your Marketlane password",text:`Hi ${name},\n\nUse this one-time link within 30 minutes: ${resetUrl}\n\nIf you did not request this, ignore this email.`});
    } else if (job.name === "order-paid-email") {
      const {orderId}=job.data as {orderId:string};const order=await prisma.order.findUnique({where:{id:orderId},include:{user:true}});if(order)await transporter.sendMail({from:process.env.MAIL_FROM,to:order.user.email,subject:`Payment confirmed: ${order.orderNumber}`,text:`Hi ${order.user.name}, your payment for order ${order.orderNumber} has been confirmed.`});
    } else {
      const {email,name,orderNumber,status,trackingNumber}=job.data as {email:string;name:string;orderNumber:string;status:string;trackingNumber?:string};
      await transporter.sendMail({from:process.env.MAIL_FROM,to:email,subject:`Shipment update: ${orderNumber}`,text:`Hi ${name}, your order ${orderNumber} is now ${status}.${trackingNumber?` Tracking number: ${trackingNumber}.`:""}`});
    }
  }
}, {connection,concurrency:5});
worker.on("failed",(job,error)=>console.error("Background job failed",job?.id,error));
console.info("Marketlane BullMQ worker started");
