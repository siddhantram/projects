import { NextResponse } from "next/server";

export function errorResponse(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}
export function serverError(error: unknown) {
  const value = error instanceof Error ? { name: error.name, message: error.message, stack: process.env.NODE_ENV === "production" ? undefined : error.stack } : { message: String(error) };
  console.error(JSON.stringify({ level: "error", timestamp: new Date().toISOString(), ...value }));
  return errorResponse("An unexpected server error occurred.", 500);
}
