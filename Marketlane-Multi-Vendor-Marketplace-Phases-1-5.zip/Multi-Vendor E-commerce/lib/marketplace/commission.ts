import { Prisma } from "@prisma/client";
/** Calculate a marketplace commission using basis points (100 bps = 1%), rounded to cents. */
export function calculateCommission(gross: Prisma.Decimal, commissionBps: number): Prisma.Decimal {
  if (!Number.isInteger(commissionBps) || commissionBps < 0 || commissionBps > 10_000) throw new Error("commissionBps must be an integer from 0 to 10000");
  return gross.mul(commissionBps).div(10_000).toDecimalPlaces(2, Prisma.Decimal.ROUND_HALF_UP);
}
