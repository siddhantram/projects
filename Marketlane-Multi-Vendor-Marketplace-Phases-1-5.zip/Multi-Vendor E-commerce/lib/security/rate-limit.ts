import Redis from "ioredis";
type Bucket = { count: number; resetAt: number };
const localBuckets = new Map<string, Bucket>();
let redis: Redis | undefined;

/** Uses Redis/Upstash when configured. The process-local fallback is development-only. */
export async function rateLimit(key: string, limit = 60, windowSeconds = 60) {
  if (process.env.REDIS_URL) {
    redis ??= new Redis(process.env.REDIS_URL, { maxRetriesPerRequest: 1, enableReadyCheck: true, lazyConnect: true });
    if (redis.status === "wait") await redis.connect();
    const redisKey = `marketlane:rl:${key}`;
    const count = await redis.incr(redisKey);
    if (count === 1) await redis.expire(redisKey, windowSeconds);
    const ttl = await redis.ttl(redisKey);
    return { allowed: count <= limit, remaining: Math.max(0, limit - count), resetAt: Date.now() + Math.max(1, ttl) * 1000 };
  }
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (url && token) {
    const redisKey = `marketlane:rl:${key}`;
    const response = await fetch(`${url}/pipeline`, { method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }, body: JSON.stringify([["INCR", redisKey], ["EXPIRE", redisKey, windowSeconds, "NX"], ["TTL", redisKey]]) });
    if (!response.ok) throw new Error("Rate-limit store unavailable");
    const result = await response.json() as Array<{ result?: number }>;
    const count = Number(result[0]?.result ?? 1); const ttl = Number(result[2]?.result ?? windowSeconds);
    return { allowed: count <= limit, remaining: Math.max(0, limit - count), resetAt: Date.now() + Math.max(1, ttl) * 1000 };
  }
  if (process.env.NODE_ENV === "production") throw new Error("Configure Redis for distributed production rate limiting.");
  const now = Date.now(); const old = localBuckets.get(key); const bucket = !old || old.resetAt <= now ? { count: 0, resetAt: now + windowSeconds * 1000 } : old;
  bucket.count += 1; localBuckets.set(key, bucket);
  if (localBuckets.size > 10_000) for (const [k, v] of localBuckets) if (v.resetAt <= now) localBuckets.delete(k);
  return { allowed: bucket.count <= limit, remaining: Math.max(0, limit - bucket.count), resetAt: bucket.resetAt };
}
