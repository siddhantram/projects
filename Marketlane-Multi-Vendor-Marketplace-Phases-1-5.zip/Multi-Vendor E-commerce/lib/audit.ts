import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
export async function audit(actorId: string | undefined, action: string, entityType: string, entityId?: string, metadata?: unknown) {
  try { await prisma.auditLog.create({ data: { actorId, action, entityType, entityId, ...(metadata === undefined ? {} : { metadata: metadata as Prisma.InputJsonValue }) } }); }
  catch (error) { console.error("audit-log-write-failed", error); }
}
