import { Queue } from "bullmq";
import Redis from "ioredis";
let connection: Redis | undefined;
let queue: Queue | undefined;
function getQueue() {
  if (!process.env.REDIS_URL) return null;
  connection ??= new Redis(process.env.REDIS_URL, { maxRetriesPerRequest: null, enableReadyCheck: true });
  queue ??= new Queue("marketlane-jobs", { connection });
  return queue;
}
export async function enqueueJob(name: string, payload: Record<string, unknown>) {
  const q = getQueue();
  if (!q) {
    if (process.env.NODE_ENV === "production") throw new Error("Configure REDIS_URL for durable BullMQ background jobs.");
    console.info(`[job:dev-inline] ${name}`, payload);
    return { queued: false, mode: "development-inline" as const };
  }
  const identity = name === "order-paid-email" ? payload.orderId : name === "shipment-updated-email" ? `${payload.orderNumber ?? "order"}-${payload.status ?? "update"}` : crypto.randomUUID();
  const jobId = `${name}-${String(identity).replace(/[^a-zA-Z0-9_-]/g, "-")}`;
  const job = await q.add(name, payload, { jobId, attempts: 5, backoff: { type: "exponential", delay: 1000 }, removeOnComplete: 1000, removeOnFail: 5000 });
  return { queued: true, jobId: job.id };
}
