import { test, expect } from "@playwright/test";

test("storefront loads and exposes marketplace navigation", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: /find your next/i })).toBeVisible();
  await expect(page.getByRole("link", { name: /shop all/i })).toBeVisible();
  await expect(page.getByRole("link", { name: /cart/i })).toBeVisible();
});

test("shop page exposes search, filters and pagination controls", async ({ page }) => {
  await page.goto("/shop");
  await expect(page.getByRole("heading", { name: /shop independent brands/i })).toBeVisible();
  await expect(page.getByPlaceholder(/search products/i)).toBeVisible();
  await expect(page.getByRole("button", { name: /next/i })).toBeVisible();
});

test("login page links to password recovery", async ({ page }) => {
  await page.goto("/login");
  await expect(page.getByRole("heading", { name: /log in to marketlane/i })).toBeVisible();
  await expect(page.getByRole("link", { name: /forgot password/i })).toBeVisible();
});
