import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash("DemoPass123!", 12);
  const admin = await prisma.user.upsert({
    where: { email: "admin@marketplace.local" },
    update: {},
    create: { name: "Marketplace Admin", email: "admin@marketplace.local", passwordHash, role: "ADMIN" }
  });
  const vendorUser = await prisma.user.upsert({
    where: { email: "vendor@marketplace.local" },
    update: { role: "VENDOR" },
    create: { name: "Demo Vendor", email: "vendor@marketplace.local", passwordHash, role: "VENDOR",
      vendor: { create: { storeName: "Northstar Goods", slug: "northstar-goods", description: "Everyday essentials, thoughtfully selected.", status: "APPROVED", isVerified: true, commissionBps: 1000 } } }
  });
  const vendor = await prisma.vendor.findUniqueOrThrow({ where: { userId: vendorUser.id } });
  const category = await prisma.category.upsert({ where: { slug: "accessories" }, update: {}, create: { name: "Accessories", slug: "accessories" } });
  const brand = await prisma.brand.upsert({ where: { slug: "northstar" }, update: {}, create: { name: "Northstar", slug: "northstar" } });
  const products = [
    { name: "Everyday Canvas Tote", slug: "everyday-canvas-tote", description: "A sturdy, roomy canvas tote for everyday errands, work, and weekend plans.", price: 799, sku: "NS-TOTE-001", stock: 45, imageUrl: "https://images.unsplash.com/photo-1544816155-12df9643f363?w=900" },
    { name: "Minimal Desk Lamp", slug: "minimal-desk-lamp", description: "A clean-lined desk lamp with warm light for focused work and calm evenings.", price: 1899, sku: "NS-LAMP-001", stock: 18, imageUrl: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=900" },
    { name: "Travel Bottle Set", slug: "travel-bottle-set", description: "Reusable travel bottles that keep your daily essentials organized on the go.", price: 549, sku: "NS-TRAVEL-001", stock: 60, imageUrl: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=900" },
    { name: "Wireless Headphones", slug: "wireless-headphones", description: "Comfortable over-ear headphones for calls, playlists, and long commutes.", price: 3499, sku: "NS-AUDIO-001", stock: 12, imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=900" }
  ];
  for (const p of products) await prisma.product.upsert({ where: { sku: p.sku }, update: { brandId: brand.id }, create: { ...p, price: p.price, vendorId: vendor.id, categoryId: category.id, brandId: brand.id, status: "ACTIVE" } });
  const tote = await prisma.product.findUniqueOrThrow({ where: { sku: "NS-TOTE-001" } });
  await prisma.productVariant.upsert({ where: { sku: "NS-TOTE-SAND-S" }, update: {}, create: { productId: tote.id, name: "Sand canvas", size: "Small", color: "Sand", sku: "NS-TOTE-SAND-S", stock: 15 } });
  await prisma.productVariant.upsert({ where: { sku: "NS-TOTE-SAND-L" }, update: {}, create: { productId: tote.id, name: "Sand canvas", size: "Large", color: "Sand", sku: "NS-TOTE-SAND-L", stock: 20 } });
  console.log(`Seeded admin ${admin.email}, vendor ${vendorUser.email}, and ${products.length} products.`);
}
main().finally(() => prisma.$disconnect());
