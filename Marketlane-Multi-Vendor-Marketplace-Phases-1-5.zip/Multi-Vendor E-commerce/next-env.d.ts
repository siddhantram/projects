/// <reference types="next" />
/// <reference types="next/image-types/global" />

// Next.js generates additional route type references during `next dev` / `next build`.
// Keeping this base file independent of .next lets `tsc --noEmit` run before the first build.
